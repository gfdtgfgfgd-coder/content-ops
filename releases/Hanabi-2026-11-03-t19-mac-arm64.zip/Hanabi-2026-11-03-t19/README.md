# Hanabi T19 轻量版

源码与 content-ops 生成资源。运行前配置 `tmp/gateway.env`，服务仅监听 127.0.0.1:6187。
