# 市场调研知识结构

2026-10-26：在现有档案上重组，不删除历史证据。

- 唯一主入口：`references/ai-market-research/SKILL.md`，负责调研、比价、写作、子 Skill 路由与更新归属。
- `sites/{c-api,b-api,mirror,makenow,overseas}/SKILL.md`：每站一份，记录价格、功能、运营模式。
- `models/<family>/SKILL.md`：每个模型系列一份；版本、规格、模式和币种留在各自 `references/prices.md` / `prices.json`。
- `catalog.json` 与 `references/model-skills.md`：可供报告流程定位系列。
- 原始 official/、报告、竞品、关键词、原表、快照和脚本均保留。第三方托管不是原厂价，单独留作支撑资料。

现有数据拆为 53 个系列、2,846 条原厂规格与计费记录，另有 1,213 条托管或通用费用记录；共 4,059 条原始记录全部保留。重组不是重新核验所有现价，记录保持其原始采集日期。网站公开资料于 10 月 26 日补读；MakeNow 登录后套餐仍标 10 月 21 日的快照日期。

用户本次确认：B 端 ¥1 到账 $1 站内额度；Coding Plan 额度与单价 1:1；Codex 模型表价格还需乘 2。没有新增内部代理或退款政策，后续按提供的材料补充。这些口径放在对应网站与 catalog 的确认字段中，不覆盖到其他网站。

迁移工具：`scripts/restructure-market-knowledge.mjs --root <knowledge-root> --snapshots <public-snapshots> --backup <backup-dir> --codex-multiplier 2`。先备份完整市场目录，原子写新文件。已有 version=1 的目录不会被重建，保护用户后续编辑。

报告的 marketBaseline 加载主入口、五站 Skill、模型目录及用户原稿风格样本，再由本地读取工具按系列读价格，不一次装入全部 JSON。新采集的我方站点资料进入对应 sites/…/references/updates 并更新证据索引；不会静默把单次网页替换为已确认政策。竞品、成品报告、关键词继续各自归档。

知识页首先显示基础 Skill 与五站，模型按文本、图像、视频、语音、其它五类折叠；支撑资料不显示为列表入口，仍可从 Skill 链接或搜索读取。搜索、分类、分类改名、批量移动/删除和工作流附加文档仍保留。Skill YAML 只供机器读取，阅读区不显示。

验证：59 份市场 Skill 通过 Skill Creator 格式校验；全部原始记录 ID、字段、金额和日期保持一致；新增 Skill 内部链接均可解析；首次迁移时 78 项回归测试通过；简化导航后 11 项相关测试通过。通过隔离实例实际验证主 Skill→网站、模型→完整价目、搜索与分组，再迁移正式档案。正式资料条目内容在部署前后做哈希核对。

2026-10-26 界面修订：市场调研改为普通筛选标签，左侧首页入口改名“花火工坊”，移除重复栏标题。
