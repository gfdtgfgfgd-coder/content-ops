# 批量平台预览雏形

入口：制花 / 燃放预览。主页面只读取已归档资料、已完成成品及本机排版草稿；不发送 AI 请求、不改原作、不对外发布。

- `preview-batch-model.mjs` 复用 `resourceInventory` 和 `previewItemFromJob`；与全应用使用同一成品和资料口径。
- `preview-batch-ui.mjs` 提供批量选篇、平台切换、并排阅读、图片翻页、原视频播放、单篇放大、飞书文档目录和人工看过标记。
- `preview-batch.css` 区分小红书笔记、B 站投稿信息、抖音竖屏作品与飞书只读文档结构。是本机模拟，不保证平台未来改版后的像素一致性。
- 标记按平台、标题、正文、媒体版本计算；内容修改后自动失效。初始化必须等待资料与成品两个列表都准备好再清理旧选择，避免刷新时丢失成品。
- 原排版、PNG/ZIP/HTML/Word 导出功能仍在「排版与导出」工具中。存下的草稿与批量预览联动，不复制一套作品。
- 资料库批量调配、制花和预览中的内容修改请求带确切资源 ID 到可编辑对话草稿，用户补充并发送后才启动任务。

## 参考入口与观察范围

- 小红书创作服务平台：https://creator.xiaohongshu.com/publish/publish 。本次公开读取落在登录页；内容结构结合其官方分享文档 https://agora.xiaohongshu.com/doc/android 中的标题、正文、图片、视频与封面字段，以及现有笔记参考。
- 哔哩哔哩创作入口：https://member.bilibili.com/ ，专栏编辑器 https://member.bilibili.com/york/read-editor 。公开页依赖脚本/登录，本地模拟视频、封面、标题、简介、标签的检查结构。
- 抖音创作者中心：https://creator.douyin.com/ 。公开入口依赖脚本/登录；本地模拟竖屏作品与发布描述的并排检查。
- 飞书文档参考：用户提供的文档截图及官方帮助「文档功能常见问题」https://www.feishu.cn/hc/zh-CN/articles/360044024994-文档功能常见问题 。采用文档标题、作者信息、连续正文、表格与目录；不伪造评论、浏览数或审核状态。

发布规格没有核实的地方不作为强制限制。界面仅提示实际缺少的媒体、空正文或较长标题需要人工核对，不声称已通过平台审核。

## 验证

`node --test tests/preview-batch.test.mjs tests/preview-presentation.test.mjs`

`npm run test:batch-preview-ui`：真实应用入口、四个平台、选择、翻图、完整文档、修改后复核、窄屏、工具入口、刷新恢复、无 AI/写入请求、批量调配带入对话。

`npm run test:preview-ui`：原图片/ZIP/HTML/Word/复制排版与草稿隔离。

`npm run test:application-ui`、`npm run test:chat-ui`：共享资源、页面恢复、接入与模型选择。
