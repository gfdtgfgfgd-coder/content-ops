# Hanabi conversation runtime

Natural-language assistant text and native function calls replace the former CHAT_STEP_SCHEMA JSON planner for chat. Structured background analysis schemas remain for validated archive writes.

- Codex subscription: official app-server ephemeral thread, dynamic tools, agentMessage deltas, interrupt/process cleanup. No provider fallback.
- API: OpenAI-compatible, Anthropic and Gemini native SSE/function calls.
- Claude/Gemini subscriptions: official CLI stream-json and scoped ephemeral MCP bridge; only Hanabi tool registry exposed. Their account login remains required. No private reasoning displayed.
- ChatWorkbench persists partial content, tool activity and bounded prior tool evidence. Server SSE sends actual deltas and state snapshots; refresh reconnects without repeating sends.
- Stop aborts model/reading plus owned analysis/discovery/report jobs, preserves delivered text and completed results. Admission is serialized; jobs created during stop are registered before cancellation check.
- Browser reads reuse observed public Chrome tabs and detach; no cookie/input/key reads, no closing user tabs. Public-page reader and Exa search provide alternatives.

References consulted (2026-10-29):
- https://github.com/deepseek-ai/deepseek-harness/tree/master/packages/core/agent-loop (stream/tool/history/cancel lifecycle; design reference, not a wholesale dependency transplant)
- https://learn.chatgpt.com/docs/app-server (dynamic tools, item/agentMessage/delta, turn/interrupt)
- https://code.claude.com/docs/en/headless
- https://geminicli.com/docs/cli/headless/

Tests: tests/agent-stream.test.mjs, tests/chat-workbench.test.mjs, tests/chat-http.test.mjs, npm run test:chat-ui, npm run test:application-ui.

Verified locally: 128/128 unit tests; Electron chat + linked application navigation; HTTP connection/image persistence; real connected Codex produced 45 SSE deltas and retained 25 characters on cancellation; actual APIPod browser extraction returned 19,922 characters. Claude/Google subscription paths require the user's login and were not live-account verified.

## Conversation archive

The SQLite `hanabi_chats.archived_at` flag controls both history lists and message admission. Archiving preserves messages, attachments, tool evidence, artifacts, and original recency. The normal history hides archived conversations; a searchable archive dialog opens them read-only and supports restore. Current-chat actions are also available from the top-bar menu on narrow screens. Running conversations or linked background jobs must be stopped before archiving; restore never automatically starts a model. No model call is needed for archive/list/restore.

Design reference: https://github.com/deepseek-ai/deepseek-harness/blob/master/packages/api/session-controller/src/archived-session-gate.ts and its `apps/web/tests/session-unarchive.e2e.ts` round-trip test. Hanabi uses its own existing SQLite and chat lifecycle.

## Conversation rename

侧栏会话菜单、当前会话菜单和归档列表提供「重命名」。`POST /api/chats/:id/rename {title}` 仅更新标题与 title_custom 标记，保留消息、成果、归档状态和原有排序时间；不调用模型。手动名称不会被首条消息的自动标题覆盖，包括发送与改名并发的情况。分支来源按父会话当前名称显示，分支自身名称保持独立。名称规范化空白后须为 1–120 个字符，按普通文本渲染。

## 当前飞书文档

左下角接入可授权本机 `Hanabi 文档读取` 助手。macOS 辅助功能首次授权后，`feishu_read_current` 读取正在显示的飞书云文档正文和表格。助手仅连接 `com.bytedance.macos.feishu`，不会点击、输入、读取剪贴板或扫描其他应用。当前已加载范围始终标记为 partial；快照按会话隔离，长文用 snapshotId/nextOffset 续读，断开即清除。测试读取只返回标题、字符与表格数，不自动归档或调用模型。

开发和打包先运行 `node scripts/build-document-helper.mjs`；安装器复制 `.build/HanabiDocuments.app` 到持久运行目录，授权应授予安装后的助手，避免开发副本和运行副本混淆。

## 消息分支

每条消息下的「在新对话中分支」调用 `POST /api/chats/:id/branch {messageId}`。事务内复制到该消息的完整前缀、附件引用及工具证据，重建消息和工具记录 ID，保存 parent_chat_id / parent_message_id。不会调用模型，也不会复制后续消息；停止/归档状态独立。历史成果通过 inheritedFrom 标记引用，不能被分支停止操作取消。运行中的起点返回 409，允许从更早的完成消息或已归档会话分支。来源条支持回到原消息，刷新后仍可查看。

## 对话直达预览

`produce` 可直接接收对话正文或 sourceMessageId。`operation:publish` 创建已完成的制花成品，原文不变，不重跑模型；`operation:create` 以对话上下文作为任务输入继续创作，无需资料库样本。独立接口 `POST /api/chats/:id/produce` 验证消息归属和当前用户消息边界；内部上下文使用 conversation 空间，不计入资料库或预览资源。保留同一套成品、Word 导出、纠错与预览；清空对应任务时回收孤立上下文。`read_conversation` 支持按消息 ID 分页读取，ID 从 inventory.conversation 获得。

## 重复执行保护

同轮采火、调配、调研和纠错通过 toolEffectKey（字段排序后的完整参数）复用已成功结果；制花始终检查持久化输入版本身份；只读工具不缓存，失败调用允许重试。对话制花统一进入 ConversationProduction：内容/附件、参考版本、要求及模型配置形成持久指纹，复用活跃或完成任务；纯保存不因标题/平台/要求措辞重复生成。existingJobId 只可引用本对话可见成果。newVersion 仅用于明确另做一版；HTTP 请求键仍保证重试幂等。跨轮/跨会话引用标记 inheritedFrom，停止不会取消来源任务；同轮重复请求保留本轮停止权限。

## Empty knowledge archive

用户明确清空内容后，保留空 knowledge/ai-content-alchemy 目录，避免启动初始化重新导入打包知识。optionalKnowledge 对缺失的档案返回空正文；对其他读取错误仍报错。对话使用程序内置协议，任务只读取本应用现有档案，不回退到 Codex 中的旧知识。连接配置与模型偏好独立保留。清空数据时先停止后台服务，备份数据库、上传、知识、历史结果及缓存，再统一清除记录及附件，重启检查所有资源与会话计数。
