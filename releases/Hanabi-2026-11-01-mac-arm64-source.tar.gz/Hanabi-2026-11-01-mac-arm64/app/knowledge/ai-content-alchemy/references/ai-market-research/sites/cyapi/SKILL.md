---
name: market-site-cyapi
description: 研究我方 CyAPI 逆向站的模型、分组价格、人民币充值及群聊售后，用于与我方其他业务和竞品比较；不作为模型原厂报价。
---

# CyAPI 逆向站 · 网站 Skill

入口：[cyapi.ai](https://cyapi.ai/) · [模型广场](https://cyapi.ai/pricing) · 核对日期：2026-10-28。

CyAPI 是我方自营的逆向 API 站。当前目录共 **33 个型号、57 条型号与分组关联**，按厂商和型号列价如下。人民币充值后按调用量或次数扣额度，**人民币 1 元＝1 美元站内额度**，不乘美元汇率；无充值折扣，余额无有效期（用户确认）。

## 分组

同一型号只使用它实际关联的分组，不把全局分组套给所有型号。折数是倍率×10，例如0.8折＝0.08倍。
- **default** [x1]（默认分组；关联 32 个型号）
- **claude_kiro** [x0.08]（claude-kiro 渠道分组；关联 10 个型号）
- **claude_anti** [x0.25]（claude-anti 渠道分组；关联 2 个型号）
- **codex文字** [x0.15]（codex 渠道分组；关联 4 个型号）
- **gemini_anti** [x0.25]（gemini-anti 渠道分组；关联 2 个型号）
- **快速分组** [x2.5]（快速分组；关联 5 个型号）
- **测试分组** [x1]（测试用；关联 2 个型号）
- **auto** [x1]（自动分组；只用于自动选择链路，不是一个额外收费层）
- **gemini_openai路径** [x1]（/v1/images/generations；本次目录没有关联型号）

auto 的稳定优先顺序为 default → codex文字，价格优先顺序相反；仅在型号支持相应组时可选。Claude/Gemini 的低价组不在这条默认 auto 链中，不能把最低分组价冒充默认自动路由的成交价。

## 厂商与型号价格

以下金额为人民币；文本单位为 **1M Tokens（100万 Token）**，按次型号明确写“次”。静态详情已有分组最终价，不再乘一次倍率。动态型号以下列“档位基价×本组倍率”的推算最终价交付。缓存创建项由公开目录的缓存创建系数换算，页面未展示不等于免费。小数保留四位；精确值保留在结构化报价，前端显示存在三位小数中间舍入。

### Anthropic

**claude-fable-5**

default分组 1 倍率，输入价格 ¥10.0000/1M Tokens，补全价格 ¥50.0000/1M Tokens，缓存读取价格 ¥1.0000/1M Tokens，缓存创建价格 ¥12.5000/1M Tokens。

claude_kiro分组 0.08 倍率，输入价格 ¥0.8000/1M Tokens，补全价格 ¥4.0000/1M Tokens，缓存读取价格 ¥0.0800/1M Tokens，缓存创建价格 ¥1.0000/1M Tokens。

[查看本站型号详情](https://cyapi.ai/pricing?keyword=claude-fable-5)

**claude-fable-5-1**

default分组 1 倍率，输入价格 ¥10.0000/1M Tokens，补全价格 ¥50.0000/1M Tokens，缓存读取价格 ¥0.2500/1M Tokens，缓存创建价格 ¥12.5000/1M Tokens。

claude_kiro分组 0.08 倍率，输入价格 ¥0.8000/1M Tokens，补全价格 ¥4.0000/1M Tokens，缓存读取价格 ¥0.0200/1M Tokens，缓存创建价格 ¥1.0000/1M Tokens。

[查看本站型号详情](https://cyapi.ai/pricing?keyword=claude-fable-5-1)

**claude-opus-4-6**

default分组 1 倍率，输入价格 ¥5.0000/1M Tokens，补全价格 ¥25.0000/1M Tokens，缓存读取价格 ¥0.5000/1M Tokens，缓存创建价格 ¥6.2500/1M Tokens。

claude_kiro分组 0.08 倍率，输入价格 ¥0.4000/1M Tokens，补全价格 ¥2.0000/1M Tokens，缓存读取价格 ¥0.0400/1M Tokens，缓存创建价格 ¥0.5000/1M Tokens。

claude_anti分组 0.25 倍率，输入价格 ¥1.2500/1M Tokens，补全价格 ¥6.2500/1M Tokens，缓存读取价格 ¥0.1250/1M Tokens，缓存创建价格 ¥1.5625/1M Tokens。

[查看本站型号详情](https://cyapi.ai/pricing?keyword=claude-opus-4-6)

**claude-opus-4-7**

default分组 1 倍率，输入价格 ¥5.0000/1M Tokens，补全价格 ¥25.0000/1M Tokens，缓存读取价格 ¥0.5000/1M Tokens，缓存创建价格 ¥6.2500/1M Tokens。

claude_kiro分组 0.08 倍率，输入价格 ¥0.4000/1M Tokens，补全价格 ¥2.0000/1M Tokens，缓存读取价格 ¥0.0400/1M Tokens，缓存创建价格 ¥0.5000/1M Tokens。

[查看本站型号详情](https://cyapi.ai/pricing?keyword=claude-opus-4-7)

**claude-opus-4-8**

default分组 1 倍率，输入价格 ¥5.0000/1M Tokens，补全价格 ¥25.0000/1M Tokens，缓存读取价格 ¥0.5000/1M Tokens，缓存创建价格 ¥6.2500/1M Tokens。

claude_kiro分组 0.08 倍率，输入价格 ¥0.4000/1M Tokens，补全价格 ¥2.0000/1M Tokens，缓存读取价格 ¥0.0400/1M Tokens，缓存创建价格 ¥0.5000/1M Tokens。

[查看本站型号详情](https://cyapi.ai/pricing?keyword=claude-opus-4-8)

**claude-opus-5**

default分组 1 倍率，输入价格 ¥5.0000/1M Tokens，补全价格 ¥25.0000/1M Tokens，缓存读取价格 ¥0.5000/1M Tokens，缓存创建价格 ¥6.2500/1M Tokens。

claude_kiro分组 0.08 倍率，输入价格 ¥0.4000/1M Tokens，补全价格 ¥2.0000/1M Tokens，缓存读取价格 ¥0.0400/1M Tokens，缓存创建价格 ¥0.5000/1M Tokens。

[查看本站型号详情](https://cyapi.ai/pricing?keyword=claude-opus-5)

**claude-opus-5-5**

default分组 1 倍率，输入价格 ¥4.0000/1M Tokens，补全价格 ¥20.0000/1M Tokens，缓存读取价格 ¥0.2000/1M Tokens，缓存创建价格 ¥5.0000/1M Tokens。

claude_kiro分组 0.08 倍率，输入价格 ¥0.3200/1M Tokens，补全价格 ¥1.6000/1M Tokens，缓存读取价格 ¥0.0160/1M Tokens，缓存创建价格 ¥0.4000/1M Tokens。

[查看本站型号详情](https://cyapi.ai/pricing?keyword=claude-opus-5-5)

**claude-sonnet-4-6**

default分组 1 倍率，输入价格 ¥3.0000/1M Tokens，补全价格 ¥15.0000/1M Tokens，缓存读取价格 ¥0.3000/1M Tokens，缓存创建价格 ¥3.7500/1M Tokens。

claude_kiro分组 0.08 倍率，输入价格 ¥0.2400/1M Tokens，补全价格 ¥1.2000/1M Tokens，缓存读取价格 ¥0.0240/1M Tokens，缓存创建价格 ¥0.3000/1M Tokens。

claude_anti分组 0.25 倍率，输入价格 ¥0.7500/1M Tokens，补全价格 ¥3.7500/1M Tokens，缓存读取价格 ¥0.0750/1M Tokens，缓存创建价格 ¥0.9375/1M Tokens。

[查看本站型号详情](https://cyapi.ai/pricing?keyword=claude-sonnet-4-6)

**claude-sonnet-5**

default分组 1 倍率，输入价格 ¥2.0000/1M Tokens，补全价格 ¥10.0000/1M Tokens，缓存读取价格 ¥0.2000/1M Tokens，缓存创建价格 ¥2.5000/1M Tokens。

claude_kiro分组 0.08 倍率，输入价格 ¥0.1600/1M Tokens，补全价格 ¥0.8000/1M Tokens，缓存读取价格 ¥0.0160/1M Tokens，缓存创建价格 ¥0.2000/1M Tokens。

[查看本站型号详情](https://cyapi.ai/pricing?keyword=claude-sonnet-5)

**claude-sonnet-5-5**

default分组 1 倍率，输入价格 ¥2.0000/1M Tokens，补全价格 ¥10.0000/1M Tokens，缓存读取价格 ¥0.2000/1M Tokens，缓存创建价格 ¥2.5000/1M Tokens。

claude_kiro分组 0.08 倍率，输入价格 ¥0.1600/1M Tokens，补全价格 ¥0.8000/1M Tokens，缓存读取价格 ¥0.0160/1M Tokens，缓存创建价格 ¥0.2000/1M Tokens。

[查看本站型号详情](https://cyapi.ai/pricing?keyword=claude-sonnet-5-5)

### Google

**gemini-2.5-flash-image**

default分组 1 倍率，价格 ¥0.0500/次。

[查看本站型号详情](https://cyapi.ai/pricing?keyword=gemini-2.5-flash-image)

**gemini-3-flash-preview**

default分组 1 倍率，输入价格 ¥0.5000/1M Tokens，补全价格 ¥3.0000/1M Tokens，缓存读取价格 ¥0.1250/1M Tokens。

gemini_anti分组 0.25 倍率，输入价格 ¥0.1250/1M Tokens，补全价格 ¥0.7500/1M Tokens，缓存读取价格 ¥0.0313/1M Tokens。

[查看本站型号详情](https://cyapi.ai/pricing?keyword=gemini-3-flash-preview)

**gemini-3-pro-image-preview**

default分组 1 倍率，价格 ¥0.1200/次。

快速分组分组 2.5 倍率，价格 ¥0.3000/次。

[查看本站型号详情](https://cyapi.ai/pricing?keyword=gemini-3-pro-image-preview)

**gemini-3-pro-image-preview-1K**

default分组 1 倍率，价格 ¥0.1200/次。

快速分组分组 2.5 倍率，价格 ¥0.3000/次。

[查看本站型号详情](https://cyapi.ai/pricing?keyword=gemini-3-pro-image-preview-1K)

**gemini-3-pro-image-preview-2K**

default分组 1 倍率，价格 ¥0.1200/次。

快速分组分组 2.5 倍率，价格 ¥0.3000/次。

[查看本站型号详情](https://cyapi.ai/pricing?keyword=gemini-3-pro-image-preview-2K)

**gemini-3-pro-image-preview-4K**

default分组 1 倍率，价格 ¥0.1200/次。

快速分组分组 2.5 倍率，价格 ¥0.3000/次。

[查看本站型号详情](https://cyapi.ai/pricing?keyword=gemini-3-pro-image-preview-4K)

**gemini-3.1-flash-image-preview**

default分组 1 倍率，价格 ¥0.0700/次。

快速分组分组 2.5 倍率，价格 ¥0.1750/次。

[查看本站型号详情](https://cyapi.ai/pricing?keyword=gemini-3.1-flash-image-preview)

**gemini-3.5-flash**

default分组 1 倍率，输入价格 ¥1.5000/1M Tokens，补全价格 ¥9.0000/1M Tokens，缓存读取价格 ¥0.3750/1M Tokens。

gemini_anti分组 0.25 倍率，输入价格 ¥0.3750/1M Tokens，补全价格 ¥2.2500/1M Tokens，缓存读取价格 ¥0.0938/1M Tokens。

[查看本站型号详情](https://cyapi.ai/pricing?keyword=gemini-3.5-flash)

### OpenAI

**gpt-5.6-luna**

default分组 1 倍率，输入 Token ≤ 272000，输入价格 ¥0.2000/1M Tokens，补全价格 ¥1.2000/1M Tokens，缓存读取价格 ¥0.0200/1M Tokens，缓存创建价格 ¥0.2500/1M Tokens。（档位基价乘本组倍率一次。）

default分组 1 倍率，输入 Token > 272000，输入价格 ¥0.4000/1M Tokens，补全价格 ¥1.8000/1M Tokens，缓存读取价格 ¥0.0400/1M Tokens，缓存创建价格 ¥0.5000/1M Tokens。（档位基价乘本组倍率一次。）

codex文字分组 0.15 倍率，输入 Token ≤ 272000，输入价格 ¥0.0300/1M Tokens，补全价格 ¥0.1800/1M Tokens，缓存读取价格 ¥0.0030/1M Tokens，缓存创建价格 ¥0.0375/1M Tokens。（档位基价乘本组倍率一次。）

codex文字分组 0.15 倍率，输入 Token > 272000，输入价格 ¥0.0600/1M Tokens，补全价格 ¥0.2700/1M Tokens，缓存读取价格 ¥0.0060/1M Tokens，缓存创建价格 ¥0.0750/1M Tokens。（档位基价乘本组倍率一次。）

[查看本站型号详情](https://cyapi.ai/pricing?keyword=gpt-5.6-luna)

**gpt-5.6-sol**

default分组 1 倍率，输入 Token ≤ 272000，输入价格 ¥5.0000/1M Tokens，补全价格 ¥30.0000/1M Tokens，缓存读取价格 ¥0.5000/1M Tokens，缓存创建价格 ¥6.2500/1M Tokens。（档位基价乘本组倍率一次。）

default分组 1 倍率，输入 Token > 272000，输入价格 ¥10.0000/1M Tokens，补全价格 ¥45.0000/1M Tokens，缓存读取价格 ¥1.0000/1M Tokens，缓存创建价格 ¥12.5000/1M Tokens。（档位基价乘本组倍率一次。）

codex文字分组 0.15 倍率，输入 Token ≤ 272000，输入价格 ¥0.7500/1M Tokens，补全价格 ¥4.5000/1M Tokens，缓存读取价格 ¥0.0750/1M Tokens，缓存创建价格 ¥0.9375/1M Tokens。（档位基价乘本组倍率一次。）

codex文字分组 0.15 倍率，输入 Token > 272000，输入价格 ¥1.5000/1M Tokens，补全价格 ¥6.7500/1M Tokens，缓存读取价格 ¥0.1500/1M Tokens，缓存创建价格 ¥1.8750/1M Tokens。（档位基价乘本组倍率一次。）

[查看本站型号详情](https://cyapi.ai/pricing?keyword=gpt-5.6-sol)

**gpt-5.6-terra**

default分组 1 倍率，输入 Token ≤ 272000，输入价格 ¥2.0000/1M Tokens，补全价格 ¥12.0000/1M Tokens，缓存读取价格 ¥0.2000/1M Tokens，缓存创建价格 ¥2.5000/1M Tokens。（档位基价乘本组倍率一次。）

default分组 1 倍率，输入 Token > 272000，输入价格 ¥4.0000/1M Tokens，补全价格 ¥18.0000/1M Tokens，缓存读取价格 ¥0.4000/1M Tokens，缓存创建价格 ¥5.0000/1M Tokens。（档位基价乘本组倍率一次。）

codex文字分组 0.15 倍率，输入 Token ≤ 272000，输入价格 ¥0.3000/1M Tokens，补全价格 ¥1.8000/1M Tokens，缓存读取价格 ¥0.0300/1M Tokens，缓存创建价格 ¥0.3750/1M Tokens。（档位基价乘本组倍率一次。）

codex文字分组 0.15 倍率，输入 Token > 272000，输入价格 ¥0.6000/1M Tokens，补全价格 ¥2.7000/1M Tokens，缓存读取价格 ¥0.0600/1M Tokens，缓存创建价格 ¥0.7500/1M Tokens。（档位基价乘本组倍率一次。）

[查看本站型号详情](https://cyapi.ai/pricing?keyword=gpt-5.6-terra)

**gpt-6-astra**

default分组 1 倍率，输入 Token ≤ 272000，输入价格 ¥10.0000/1M Tokens，补全价格 ¥50.0000/1M Tokens，缓存读取价格 ¥1.0000/1M Tokens，缓存创建价格 ¥12.5000/1M Tokens。（档位基价乘本组倍率一次。）

default分组 1 倍率，输入 Token > 272000，输入价格 ¥20.0000/1M Tokens，补全价格 ¥75.0000/1M Tokens，缓存读取价格 ¥2.0000/1M Tokens，缓存创建价格 ¥25.0000/1M Tokens。（档位基价乘本组倍率一次。）

codex文字分组 0.15 倍率，输入 Token ≤ 272000，输入价格 ¥1.5000/1M Tokens，补全价格 ¥7.5000/1M Tokens，缓存读取价格 ¥0.1500/1M Tokens，缓存创建价格 ¥1.8750/1M Tokens。（档位基价乘本组倍率一次。）

codex文字分组 0.15 倍率，输入 Token > 272000，输入价格 ¥3.0000/1M Tokens，补全价格 ¥11.2500/1M Tokens，缓存读取价格 ¥0.3000/1M Tokens，缓存创建价格 ¥3.7500/1M Tokens。（档位基价乘本组倍率一次。）

[查看本站型号详情](https://cyapi.ai/pricing?keyword=gpt-6-astra)

**gpt-image-2**

default分组 1 倍率，价格 ¥0.0500/次。

测试分组分组 1 倍率，价格 ¥0.0500/次。

[查看本站型号详情](https://cyapi.ai/pricing?keyword=gpt-image-2)

**gpt-image-2-c**

测试分组分组 1 倍率，价格 ¥0.0500/次。

[查看本站型号详情](https://cyapi.ai/pricing?keyword=gpt-image-2-c)

**gpt-image-2.5**

default分组 1 倍率，价格 ¥0.0500/次。

[查看本站型号详情](https://cyapi.ai/pricing?keyword=gpt-image-2.5)

**gpt-image-2.5-flare**

default分组 1 倍率，价格 ¥0.3000/次。

[查看本站型号详情](https://cyapi.ai/pricing?keyword=gpt-image-2.5-flare)

**gpt-image-2.5-sunburst**

default分组 1 倍率，价格 ¥0.3000/次。

[查看本站型号详情](https://cyapi.ai/pricing?keyword=gpt-image-2.5-sunburst)

### xAI

**grok-imagine-image**

default分组 1 倍率，价格 ¥0.0600/次。

[查看本站型号详情](https://cyapi.ai/pricing?keyword=grok-imagine-image)

**grok-imagine-image-2.0**

default分组 1 倍率，价格 ¥0.1000/次。

[查看本站型号详情](https://cyapi.ai/pricing?keyword=grok-imagine-image-2.0)

**grok-imagine-video**

default分组 1 倍率，价格 ¥0.5000/次。

[查看本站型号详情](https://cyapi.ai/pricing?keyword=grok-imagine-video)

**grok-imagine-video-1.5**

default分组 1 倍率，价格 ¥0.5000/次。

[查看本站型号详情](https://cyapi.ai/pricing?keyword=grok-imagine-video-1.5)

### 未知供应商

以下两项在本站目录没有填写供应商，保留原归属；不凭型号名称证明供给厂商或官方渠道。

**veo-3-1**

default分组 1 倍率，价格 ¥0.3000/次。

[查看本站型号详情](https://cyapi.ai/pricing?keyword=veo-3-1)

**veo-3-1-fast**

default分组 1 倍率，价格 ¥0.3000/次。

[查看本站型号详情](https://cyapi.ai/pricing?keyword=veo-3-1-fast)

## 充值与售后

- 充值页已核对 10 / 20 / 50 / 100 / 200 / 500 元档，实付与到账相同，支持支付宝；本次只读取金额，未付款。
$ 符号在此代表站内额度；页面写 1 $＝1.00 ¥，不属于现金美元兑换。
- 用户确认：没有充值折扣或有效期；失败请求不扣费。
- 用户确认：没有额外使用限制，售后在群聊处理。该表述不扩写为无限并发、固定响应时长、官方渠道或服务等级承诺。

## 功能与运营模式

这是聚合 API 的接入与管理工作台：模型搜索和厂商筛选负责选型；令牌、路由、钱包负责接入；数据看板、使用日志与任务日志负责用量管理。公开目录声明 OpenAI 兼容、Anthropic、Gemini 三类接口，具体型号支持的接口各不相同。首页的热搜、默认演示模型或空分类不是实际在售型号，供给以33个目录型号及各自分组为准。

经营定位来自用户确认：我方自营逆向站，以分组渠道和按量/按次计费提供调用，群聊承接售后。Claude Kiro/Anti、Codex、Gemini Anti 的低价应与 default 单列，分组名仅是本站渠道标签，不能证明原厂身份、质量或成功率。前端成功率和延迟为当时滚动监控，不当作稳定SLA。

视频按次列价；比较具体视频任务前，核对对应请求的时长、分辨率和返回规格，不从同名视频或按次价格推成每秒。公开详情没有独立时长阶梯，本次不编造时长选项。

## 后续调研如何使用

与[市场调研主 Skill](../../SKILL.md)组合。取当前网站型号和分组，再按对应档位价格计算；auto只选路由，静态已含倍率报价不重乘，动态每档乘本组倍率一次。输入、输出和缓存按互斥计费桶计算；缺失项目不能填0。需要原厂比较时另读对应模型系列Skill，不把此处逆向站报价写成原厂价。

网页初始可能先显示空目录、在线充值未开启等加载占位。等待模型数量与价表/充值金额完整返回，再读取一次确认；不能把首屏占位当关闭功能。若与用户新截图矛盾，重读当前页面核实，不沿用早先占位结论。

新增事实归本档案与下列参考文件，报告与竞品沿主Skill归档。重要计费条件仍不清楚时直接问用户，已确认的1:1与充值、售后口径不反复问。

## 数据与依据

- [完整结构化报价](references/prices-20261028.json) · [计费规则](references/pricing-rules-20261028.json)
- [公开目录快照](references/catalogue-20261028.json) · [逐型号页面依据](references/detail-evidence-20261028.json)
- [充值与功能依据](references/website-evidence-20261028.json) · [用户确认](references/confirmations-20261028.json)
- [核验记录](references/verification-20261028.json)。
