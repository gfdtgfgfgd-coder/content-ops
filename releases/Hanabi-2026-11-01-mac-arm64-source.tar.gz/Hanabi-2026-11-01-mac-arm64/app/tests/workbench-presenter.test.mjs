import test from 'node:test';
import assert from 'node:assert/strict';
import { workJobStage, reviewableJobIds, filterWorkJobs, workbenchSummary } from '../lib/workbench-presenter.mjs';

const jobs = [
  { id: 'source', mode: 'intake', status: 'completed', destinations: ['knowledge'], updatedAt: '2026-10-26T01:00:00Z' },
  { id: 'rule', mode: 'distill', status: 'completed', candidateRules: ['先呈现结果'], updatedAt: '2026-10-26T02:00:00Z' },
  { id: 'revision', mode: 'correction', parentMode: 'produce', status: 'completed', destinations: ['knowledge'], result: '报告', updatedAt: '2026-10-26T03:00:00Z' },
  { id: 'failed', mode: 'produce', status: 'failed', updatedAt: '2026-10-26T04:00:00Z' },
  { id: 'running', mode: 'intake', status: 'analyzing', updatedAt: '2026-10-26T00:00:00Z' },
  { id: 'partial', mode: 'intake', status: 'partial', updatedAt: '2026-10-26T05:00:00Z' },
];
test('workflow presentation preserves market intake and correction stage routing', () => {
  assert.equal(workJobStage(jobs[0]), 'inflow');
  assert.equal(workJobStage(jobs[1]), 'refine');
  assert.equal(workJobStage(jobs[2]), 'outflow');
  assert.equal(workJobStage({mode:'correction', parentMode:'intake', destinations:['archive']}), 'inflow');
  assert.equal(workJobStage({mode:'commit',status:'committing'}), 'refine');
});
test('only explicit completed commits remove candidates from the review list', () => {
  assert.deepEqual([...reviewableJobIds(jobs)], ['rule']);
  const pending = {id:'commit',mode:'commit',status:'committing',sourceJobIds:['rule']};
  assert.deepEqual([...reviewableJobIds([...jobs,pending])], ['rule']);
  assert.deepEqual([...reviewableJobIds([...jobs,{...pending,status:'completed'}])], []);
});
test('task filters preserve complete history and expose partial results for follow-up', () => {
  assert.deepEqual(filterWorkJobs(jobs,'inflow').map(job=>job.id), ['source','running','partial']);
  assert.deepEqual(filterWorkJobs(jobs,'inflow','active').map(job=>job.id), ['running']);
  assert.deepEqual(filterWorkJobs(jobs,'inflow','attention').map(job=>job.id), ['partial']);
  assert.deepEqual(filterWorkJobs(jobs,'refine','attention').map(job=>job.id), ['rule']);
  assert.deepEqual(filterWorkJobs(jobs,'outflow','completed').map(job=>job.id), ['revision']);
  assert.deepEqual(filterWorkJobs(jobs,'outflow','attention').map(job=>job.id), ['failed']);
});
test('home counts actual assets and keeps running work visible without mutating jobs', () => {
  const before = structuredClone(jobs);
  const summary = workbenchSummary({jobs,items:[{id:'a'},{id:'b'}],knowledgeFiles:[{path:'SKILL.md',filename:'SKILL.md'},{path:'rule.md',filename:'rule.md'}],discoveries:[{id:'d',status:'searching'},{id:'old',status:'completed'}]});
  assert.equal(summary.running,1); assert.equal(summary.activeResearch,1); assert.equal(summary.reviews,1); assert.equal(summary.attention,3);
  assert.equal(summary.materials,2); assert.equal(summary.knowledge,1); assert.equal(summary.outputs,1);
  assert.equal(summary.knowledgeDocuments,1); assert.equal(summary.previewResources,3);
  assert.equal(summary.recent[0].id,'running'); assert.equal(summary.recent[1].id,'rule');
  assert.equal(new Set(summary.recent.map(job=>job.id)).size,summary.recent.length);
  assert.deepEqual(jobs,before);
  assert.equal(workbenchSummary().recent.length,0);
});
