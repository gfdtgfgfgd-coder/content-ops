import { writeModelFixture, selectTestModel } from './model-catalog-fixture.mjs';
import test from 'node:test';
import assert from 'node:assert/strict';
import { mkdtemp, writeFile, readFile, rm } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { spawn } from 'node:child_process';
import { createServer } from 'node:net';
import JSZip from 'jszip';

test('intake -> owned-site report -> automatic archive -> editable Word, with isolated network and model fixtures', { timeout: 30000 }, async () => {
  const root = await mkdtemp(join(tmpdir(), 'hanabi-market-workflow-'));
  const probe = createServer(); await new Promise(resolve => probe.listen(0, '127.0.0.1', resolve));
  const port = probe.address().port; await new Promise(resolve => probe.close(resolve));
  const base = `http://127.0.0.1:${port}`;
  const preload = join(root, 'network.mjs'), cli = join(root, 'codex.cjs');
  await writeFile(preload, `const original=globalThis.fetch;globalThis.fetch=(url,opts)=>String(url).startsWith('https://r.jina.ai/')?Promise.resolve(new Response('Title: Public pricing\\n\\nMarkdown Content:\\n'+('| Model | Price | Unit |\\n| --- | --- | --- |\\n| model-a | CNY 1.2 | million input tokens |\\n').repeat(6))):original(url,opts);`);
  await writeFile(cli, `#!${process.execPath}
let prompt='';process.stdin.on('data',c=>prompt+=c);process.stdin.on('end',async()=>{
try{
const jobId=prompt.match(/任务 ID：([^\\s]+)/)[1],base=${JSON.stringify(base)};
const call=async(name,args)=>{const r=await fetch(base+'/mcp',{method:'POST',headers:{'Content-Type':'application/json',Origin:base},body:JSON.stringify({jsonrpc:'2.0',id:1,method:'tools/call',params:{name,arguments:args}})});const x=await r.json();if(x.error||x.result?.isError)throw new Error(JSON.stringify(x));return x.result;};
const p=JSON.parse((await call('alchemy_get_analysis_job',{jobId})).content[0].text);
if(!p.marketResearch||p.marketResearch.products.length!==6)throw new Error('Missing six-product context');
if(p.job.mode==='intake'){
if(p.marketResearch.baseline!==null)throw new Error('Intake included unnecessary baseline');
const page=JSON.parse((await call('alchemy_read_market_page',{jobId,url:p.item.sourceUrl})).content[0].text);
const content='竞品模型 model-a，公开标价 CNY 1.2/百万输入 Token。来源：'+page.url+'，读取日期 '+page.retrievedAt.slice(0,10)+'；合同、真实支付和质量未验证。';
await call('alchemy_complete_analysis_job',{jobId,result:content,sources:[{title:'公开价目',url:page.url,evidence:'model-a 价格表'}]});
}else{
const c=JSON.parse((await call('alchemy_calculate_market_cost',{jobId,currency:'CNY',lines:[{rate:'1.2',quantity:'100000',rateUnit:'million_tokens',quantityUnit:'token',bucket:'uncached_input',evidence:'fixture pricing'}]})).content[0].text);
if(c.cny!=='0.12')throw new Error('Bad deterministic cost');
const pack=JSON.parse((await call('alchemy_calculate_package_prices',{jobId,mode:'discount',referenceCurrency:'CNY_REFERENCE',discountZhe:'1.19',evidence:'fixture plan',rates:[{model:'model-a',component:'input',unit:'million_tokens',rate:'4',evidence:'fixture rate'}]})).content[0].text);
if(pack.prices[0].cnyReference!=='0.476')throw new Error('Bad package price');
await call('alchemy_calculate_market_cost',{jobId,currency:'CNY',lines:[{rate:'1',quantity:'100000',rateUnit:'million_tokens',quantityUnit:'token',bucket:'uncached_input',evidence:'fixture pricing'}]});
const result='# 竞品比价报告\\n\\n## 执行摘要\\n本报告覆盖 C 端 API、B 端 API、镜像站、MakeNow、海外站 OctopusX、CyAPI。\\n\\n| 对照项 | 人民币 | 条件 |\\n| --- | --- | --- |\\n| model-a | 0.12 | 十万输入 Token |\\n| model-b | 0.1 | 十万输入 Token |\\n| 价差 | 20% | 我方高于竞品 |\\n按缓存占比10%和30%另测临界点。\\n\\n'+('已核对公开价目；这是条件式测算，未验证付款、质量和模型实际路由。需要按规格而非名称比较。\\n\\n').repeat(22)+'## 来源\\nhttps://example.com/pricing';
await call('alchemy_complete_analysis_job',{jobId,result,sources:[{title:'公开价目',url:'https://example.com/pricing',evidence:'fixture evidence'}]});
}
}catch(e){console.error(e);process.exitCode=1;}});`, { mode: 0o700 });
  await writeModelFixture(root);
  const child = spawn(process.execPath, ['--import', preload, 'server.mjs'], { cwd: new URL('..', import.meta.url), env: { ...process.env, CODEX_HOME: root, CONTENT_ALCHEMY_DATA_DIR: join(root, 'data'), CONTENT_ALCHEMY_PORT: String(port), CONTENT_ALCHEMY_CODEX_BIN: cli }, stdio: ['ignore', 'pipe', 'pipe'] });
  let log = ''; child.stderr.on('data', c => log += c); child.stdout.on('data', c => log += c);
  const request = async (path, body, status = 200) => {
    const r = await fetch(base + path, body === undefined ? {} : { method: 'POST', headers: { Origin: base, 'Content-Type': 'application/json' }, body: JSON.stringify(body) });
    const result = await r.json(); assert.equal(r.status, status, JSON.stringify(result)); return result;
  };
  const completed = async id => {
    for (let i = 0; i < 120; i++) {
      const job = (await request('/api/analysis-jobs')).jobs.find(job => job.id === id);
      if (job?.status === 'completed') return job;
      if (job?.status === 'failed') assert.fail(JSON.stringify(job) + log);
      await new Promise(resolve => setTimeout(resolve, 50));
    }
    assert.fail('Job did not complete: ' + log);
  };
  try {
    for (let i = 0; i < 100; i++) { try { await request('/api/state'); break; } catch { await new Promise(resolve => setTimeout(resolve, 30)); } }
    await selectTestModel(base);
    const item = await request('/api/items', { title: '竞品', type: 'text', sourceUrl: 'https://example.com/pricing', content: '' }, 201);
    const internal = await request('/api/items', { title: '非法地址', type: 'text', sourceUrl: 'http://localhost/', content: '' }, 201);
    await request('/api/analysis-jobs', { mode: 'intake', marketResearch: true, itemIds: [item.id, internal.id], scope: ['text'] }, 400);
    assert.equal((await request('/api/analysis-jobs')).jobs.length, 0, 'Invalid batch left orphan jobs');
    await request('/api/market-research/reports', { itemIds: [item.id] }, 409);
    await request('/api/analysis-jobs', { mode: 'intake', marketResearch: true, itemIds: [item.id], scope: ['text','image'] }, 400);
    const { jobs } = await request('/api/analysis-jobs', { mode: 'intake', marketResearch: true, itemIds: [item.id], scope: ['text'], moduleIds: [], brief: '竞品比价' }, 202);
    const intake = await completed(jobs[0].id); assert.equal(intake.marketResearch, true); assert.ok(intake.marketBatchId);
    const visible = (await request('/api/items')).items;
    assert.equal(visible.some(entry => entry.id === item.id), false, 'Market intake polluted the library');
    assert.ok(visible.some(entry => entry.id === internal.id), 'Ordinary library item was affected');
    const intakeArchive = intake.uiChanges.find(change => change.kind === 'knowledge'); assert.ok(intakeArchive);
    assert.match(await (await fetch(base + '/api/knowledge/file?path=' + encodeURIComponent(intakeArchive.path))).text(), /model-a/);
    const { jobs: produced } = await request('/api/market-research/reports', { itemIds: [item.id], brief: '五条线比价', facts: '用户提供的合同价需标注为内部陈述' }, 202);
    const report = await completed(produced[0].id); assert.equal(report.marketReport, true); assert.match(report.productionPrompt, /用户提供的合同价需标注为内部陈述/);
    assert.equal(report.outputFormat,'report');assert.equal(report.targetPlatform,'document');
    const output = report.uiChanges.find(change => change.kind === 'knowledge'); assert.ok(output, 'Report was not archived to knowledge');
    const firstSave = await request(`/api/analysis-jobs/${report.id}/archive-output`, {}, 201);
    const secondSave = await request(`/api/analysis-jobs/${report.id}/archive-output`, {}, 201); assert.equal(firstSave.item.path, secondSave.item.path);
    assert.equal(firstSave.item.path, output.path);
    assert.equal((await request('/api/items')).items.length, 1, 'Market output polluted the library');
    const absolute = join(root, 'data/knowledge/ai-content-alchemy', output.path);
    await writeFile(absolute, await readFile(absolute, 'utf8') + '\n\n用户编辑保存后的价格口径');
    const word = await fetch(`${base}/api/analysis-jobs/${report.id}/export.docx`);
    assert.equal(word.status, 200); assert.match(word.headers.get('content-type'), /wordprocessingml/);
    const zip = await JSZip.loadAsync(Buffer.from(await word.arrayBuffer())); assert.match(await zip.file('word/document.xml').async('string'), /竞品比价报告/); assert.match(await zip.file('word/document.xml').async('string'), /用户编辑保存后的价格口径/);
    const html = await (await fetch(`${base}/api/analysis-jobs/${report.id}/export.html`)).text(); assert.match(html, /用户编辑保存后的价格口径/);
    await request(`/api/market-research/reports/${report.id}/revision`, { markdown:report.result, expectedUpdatedAt:'stale' }, 409);
    const current = (await request('/api/analysis-jobs')).jobs.find(j=>j.id===report.id);
    const revised = await request(`/api/market-research/reports/${report.id}/revision`, { markdown:report.result+'\n\n复核后的最终版本', expectedUpdatedAt:current.updatedAt, sources:current.sources });
    assert.match(revised.job.result,/复核后的最终版本/);assert.equal(revised.artifact.path,output.path);
    assert.match(await readFile(absolute,'utf8'),/复核后的最终版本/);
    const index = await request('/api/knowledge/index');
    assert.equal(index.files.find(file=>file.path===output.path).categoryId,'market-main');
    assert.ok(index.categories.some(c=>c.id==='market-main'&&c.internalFileCount>0));
    assert.ok(!index.categories.some(c=>['market-reports','market-official','market-keywords'].includes(c.id)));
    const custom = await request('/api/knowledge/categories', { name:'客户报价', parentId:'market' }, 201);
    await request('/api/knowledge/classify', { paths:[output.path], categoryId:custom.id });
    const search = await request('/api/knowledge/search?q=' + encodeURIComponent('最终版本') + '&category=' + custom.id); assert.equal(search.matches.length, 1);
    const other = await request('/api/knowledge/search?q=' + encodeURIComponent('最终版本') + '&category=market-models'); assert.equal(other.matches.length, 0);
    const evil = await fetch(base + '/api/market-research/reports', { method: 'POST', headers: { Origin: 'https://evil.example', 'Content-Type': 'application/json' }, body: '{}' }); assert.equal(evil.status, 403);
  } finally {
    child.kill('SIGTERM'); await new Promise(resolve => child.once('exit', resolve));
    await rm(root, { recursive: true, force: true });
  }
});
