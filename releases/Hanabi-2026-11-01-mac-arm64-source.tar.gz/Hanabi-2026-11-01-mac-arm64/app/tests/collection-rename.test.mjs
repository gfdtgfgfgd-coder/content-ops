import test from "node:test";
import assert from "node:assert/strict";
import { mkdtemp, mkdir, rm } from "node:fs/promises";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { spawn } from "node:child_process";
import { createServer } from "node:net";
import { DatabaseSync } from "node:sqlite";

test("collection rename preserves identity, color, files, fields and membership after restart", { timeout: 25_000 }, async () => {
  const root = await mkdtemp(join(tmpdir(), "hanabi-rename-"));
  const data = join(root, "data"); await mkdir(data);
  // Start with the previous schema to exercise migration of existing collections.
  const legacy = new DatabaseSync(join(data, "library.sqlite"));
  legacy.exec("CREATE TABLE library_modules(id TEXT PRIMARY KEY,name TEXT NOT NULL,view_key TEXT NOT NULL,description TEXT NOT NULL DEFAULT '',fields_json TEXT NOT NULL DEFAULT '[]',created_by_job_id TEXT NOT NULL DEFAULT '',created_at TEXT NOT NULL,updated_at TEXT NOT NULL,UNIQUE(view_key,name))");
  legacy.prepare("INSERT INTO library_modules VALUES(?,?,'archive',?,?,'',?,?)").run("legacy-style", "风格", "说明原样保留", JSON.stringify([{ key: "note", label: "风格要点", type: "text" }]), "2026-01-01", "2026-01-01");
  legacy.close();
  const probe = createServer(); await new Promise((resolve) => probe.listen(0, "127.0.0.1", resolve));
  const port = probe.address().port; await new Promise((resolve) => probe.close(resolve));
  const base = `http://127.0.0.1:${port}`;
  let child, log = "";
  async function start() {
    child = spawn(process.execPath, ["server.mjs"], { cwd: new URL("..", import.meta.url), env: { ...process.env, CONTENT_ALCHEMY_DATA_DIR: data, CONTENT_ALCHEMY_PORT: String(port) }, stdio: ["ignore", "ignore", "pipe"] });
    child.stderr.on("data", (bytes) => log += bytes);
    for (let attempt = 0; attempt < 80; attempt++) {
      try { const response = await fetch(base + "/healthz"); if (response.ok) return; } catch {}
      if (child.exitCode !== null) throw new Error(log);
      await new Promise((resolve) => setTimeout(resolve, 50));
    }
    throw new Error("Temporary Hanabi server did not start: " + log);
  }
  async function stop() {
    if (!child || child.exitCode !== null) return;
    child.kill("SIGTERM"); await new Promise((resolve) => child.once("close", resolve));
  }
  async function request(path, { method = "GET", body, status = 200, origin = base } = {}) {
    const response = await fetch(base + path, { method, headers: { Origin: origin, "Content-Type": "application/json" }, ...(body === undefined ? {} : { body: JSON.stringify(body) }) });
    const result = await response.json(); assert.equal(response.status, status, JSON.stringify(result)); return result;
  }
  try {
    await start();
    const initial = (await request("/api/library-modules")).modules.find((module) => module.id === "legacy-style");
    assert.equal(initial.tone, "mint");
    const other = (await request("/api/library-modules", { method: "POST", body: { name: "ShoppingList", views: ["archive"] }, status: 201 })).modules[0];
    const png = "iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8/x8AAwMCAO+a9l8AAAAASUVORK5CYII=";
    const item = await request("/api/items", { method: "POST", status: 201, body: { title: "图片与笔记", type: "image", content: "正文原样保留。", tags: ["风格", "独立标签"], moduleIds: [initial.id], moduleValues: { [initial.id]: { note: "字段原样保留" } }, files: [{ name: "reference.png", mimeType: "image/png", data: png }] } });
    const outside = await request("/api/items", { method: "POST", status: 201, body: { title: "其他资料", type: "text", tags: ["风格"], content: "不属于这个集合。" } });
    const patch = (name, status = 200) => request(`/api/library-modules/${initial.id}`, { method: "PATCH", body: { name }, status });
    const renamed = await patch("  设计参考  ");
    assert.equal(renamed.module.id, initial.id); assert.equal(renamed.module.name, "设计参考"); assert.equal(renamed.module.tone, initial.tone);
    assert.equal(renamed.module.description, initial.description); assert.deepEqual(renamed.module.fields, initial.fields);
    assert.ok(renamed.module.previousNames.includes("风格"));
    assert.deepEqual(renamed.updatedItemTags, [{ id: item.id, tags: ["设计参考", "独立标签"] }]);
    const after = await request(`/api/items/${item.id}`);
    for (const key of ["id", "title", "type", "content", "moduleIds", "moduleValues", "attachments", "mediaFrames", "updatedAt"]) assert.deepEqual(after[key], item[key], `rename changed item ${key}`);
    assert.deepEqual((await request(`/api/items/${outside.id}`)).tags, ["风格"]);
    assert.equal((await patch("shoppinglist", 409)).error, "已有同名集合，请换一个名称。");
    for (const name of ["", "  ", "字".repeat(81), null, { name: "非法输入" }]) await patch(name, 400);
    await request("/api/library-modules/missing", { method: "PATCH", body: { name: "不存在" }, status: 404 });
    await request(`/api/library-modules/${initial.id}`, { method: "PATCH", body: { name: "不允许" }, status: 403, origin: "https://example.com" });
    assert.equal((await patch("设计参考")).module.id, initial.id);
    assert.equal((await request("/api/analysis-jobs")).jobs.length, 0, "rename started an analysis task");
    await stop(); await start();
    const modules = (await request("/api/library-modules")).modules;
    assert.equal(modules.length, 2); assert.equal(modules.find((module) => module.id === initial.id).name, "设计参考");
    assert.equal(modules.find((module) => module.id === initial.id).tone, "mint");
    assert.equal(modules.find((module) => module.id === other.id).name, "ShoppingList");
    assert.deepEqual((await request(`/api/items/${item.id}`)).moduleIds, [initial.id]);
    await patch("风格");
    assert.equal((await request("/api/library-modules")).modules.find((module) => module.id === initial.id).tone, "mint");
    assert.deepEqual((await request(`/api/items/${item.id}`)).tags, ["风格", "独立标签"]);
  } finally { await stop(); await rm(root, { recursive: true, force: true }); }
});
