import test from 'node:test';
import assert from 'node:assert/strict';
import { DatabaseSync } from 'node:sqlite';
import { mkdtemp, rm } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { AiModelSettings, normalizeModels, analysisModelArgs } from '../lib/ai-models.mjs';
import { SemanticIntakeInterpreter, prepareInterpretation } from '../lib/semantic-intake.mjs';

const catalog = async () => [
  { model: 'luna', displayName: 'Luna', defaultReasoningEffort: 'medium', supportedReasoningEfforts: [{ reasoningEffort: 'low' }, { reasoningEffort: 'medium' }, { reasoningEffort: 'xhigh' }] },
  { model: 'sol', displayName: 'Sol', defaultReasoningEffort: 'medium', supportedReasoningEfforts: [{ reasoningEffort: 'medium' }] },
  { model: 'hidden', hidden: true },
];

test('a fresh user must explicitly select a model; no implicit Codex default', async () => {
  const db = new DatabaseSync(':memory:');
  const models = new AiModelSettings(db, { catalog, configuredEffort: 'xhigh' });
  assert.equal((await models.state()).selectionRequired, true);
  await assert.rejects(models.resolve(), { code: 'MODEL_SELECTION_REQUIRED' });
  assert.equal(models.lastModel(), '');
  db.close();
});

test('remembered choice survives restart, and changing it does not mutate previous task selections', async () => {
  const dir = await mkdtemp(join(tmpdir(), 'hanabi-models-'));
  try {
    let db = new DatabaseSync(join(dir, 'prefs.sqlite'));
    let models = new AiModelSettings(db, { catalog, configuredEffort: 'xhigh' });
    const first = await models.resolve('luna', { remember: true });
    await models.resolve('sol', { remember: true });
    assert.equal(first.id, 'luna'); assert.equal(first.effort, 'xhigh');
    db.close();
    db = new DatabaseSync(join(dir, 'prefs.sqlite'));
    models = new AiModelSettings(db, { catalog, configuredEffort: 'xhigh' });
    const reused = await models.resolve();
    assert.equal(reused.id, 'sol'); assert.equal(reused.effort, 'medium'); assert.equal(reused.intentEffort, 'medium');
    assert.equal((await models.state()).selectionRequired, false);
    await assert.rejects(models.resolve('made-up-model'), { code: 'MODEL_NOT_AVAILABLE' });
    assert.equal(models.lastModel(), 'sol'); db.close();
  } finally { await rm(dir, { recursive: true, force: true }); }
});

test('hidden and malformed entries cannot become picker options or CLI overrides', async () => {
  assert.deepEqual(normalizeModels(await catalog()).map(model => model.id), ['luna', 'sol']);
  assert.deepEqual(normalizeModels([{ model: '--unsafe' }, { model: 'model with spaces' }]), []);
  assert.deepEqual(analysisModelArgs('luna', 'xhigh'), ['--model', 'luna', '-c', 'model_reasoning_effort="xhigh"']);
  assert.throws(() => analysisModelArgs(''), { code: 'MODEL_SELECTION_REQUIRED' });
});

test('simultaneous model-list requests share one lookup and preserve a usable cached catalog', async () => {
  const db = new DatabaseSync(':memory:'); let calls = 0;
  const models = new AiModelSettings(db, { catalog: async () => { calls++; return catalog(); }, cacheMs: 0 });
  await Promise.all([models.models(), models.models()]); assert.equal(calls, 1);
  models.catalog = async () => { throw new Error('offline'); };
  assert.equal((await models.models()).length, 2); db.close();
});

test('intent parsing is keyed by selected model and passes it to every execution', async () => {
  const seen = [];
  const interpreter = new SemanticIntakeInterpreter({ run: async (_input, _signal, selected) => { seen.push(selected); throw new Error('test executor stopped'); } });
  const input = prepareInterpretation('学标题。作品 https://xhslink.cn/o/example', [], 50);
  assert.equal(input.requiresSemantic, true);
  const a = interpreter.request(input, { model: 'luna', reasoningEffort: 'low' });
  const b = interpreter.request(input, { model: 'sol', reasoningEffort: 'medium' });
  while (interpreter.activeCount()) await new Promise(resolve => setTimeout(resolve, 1));
  assert.notEqual(a.id, b.id);
  assert.deepEqual(seen, [{ model: 'luna', reasoningEffort: 'low' }, { model: 'sol', reasoningEffort: 'medium' }]);
  assert.equal(interpreter.get(a.id).model, 'luna');
  assert.equal(interpreter.get(b.id).model, 'sol');
});
