import test from 'node:test';
import assert from 'node:assert/strict';
import { calculatePackagePrices } from '../lib/market-package.mjs';
const evidence='https://example.com/plan#observed-2026-10-27';
const rate=(value='4')=>({model:'model-a',component:'input',unit:'million_tokens',rate:value,evidence});
const discount={mode:'discount',referenceCurrency:'USD_REFERENCE',discountZhe:'0.73',evidence,rates:[rate()]};
const fx={cnyPerUsd:'6.7171',date:'2026-10-27',source:'https://www.safe.gov.cn/'};
test('published zhe converts once; missing price stays unknown, zero stays zero, USD is reference only',()=>{
 const result=calculatePackagePrices({...discount,fx,rates:[rate(),{...rate(null),component:'cache_read'},{...rate('0'),component:'cache_write'}]});
 assert.equal(result.finalFactor,'0.073');assert.equal(result.prices[0].referenceAfterDiscount,'0.292');assert.equal(result.prices[0].cnyReference,'1.9613932');
 assert.equal(result.prices[1].cnyReference,null);assert.equal(result.prices[1].status,'not_listed');assert.equal(result.prices[2].cnyReference,'0');
 assert.equal(calculatePackagePrices(discount).prices[0].cnyReference,null);
 assert.throws(()=>calculatePackagePrices({...discount,consumptionMultiplier:'2'}),/额外倍率/);
 assert.throws(()=>calculatePackagePrices({...discount,paidCny:'99',effectiveQuota:'200'}),/不能叠加/);
});
test('store price wins, tutorial discount is scaled by comparable price and quota once without intermediate rounding',()=>{
 const input={...discount,discountZhe:'0.27',fx,discountAdjustment:{storePaidCny:'139',tutorialPaidCny:'149',tutorialQuota:'1500',storeQuota:'1500',evidence}};
 const result=calculatePackagePrices(input);
 assert.equal(result.finalZhe,'0.25187919');assert.equal(result.prices[0].cnyReference,'0.6767591');
 const lowerQuota=calculatePackagePrices({...input,discountAdjustment:{...input.discountAdjustment,storeQuota:'1200'}});
 assert.equal(lowerQuota.finalZhe,'0.31484899');assert.equal(lowerQuota.prices[0].cnyReference,'0.84594887');
});
test('domestic 1:1 never gets FX; quota calculations use effective allowance, not a second discount',()=>{
 const domestic={...discount,referenceCurrency:'CNY_REFERENCE',discountZhe:'1.19'};
 assert.equal(calculatePackagePrices(domestic).prices[0].cnyReference,'0.476');
 assert.throws(()=>calculatePackagePrices({...domestic,fx}),/不再乘外汇/);
 const quota={mode:'quota',referenceCurrency:'CREDIT_REFERENCE',paidCny:'199',effectiveQuota:'150',evidence,rates:[rate('5')]};
 assert.equal(calculatePackagePrices(quota).prices[0].cnyReference,'6.63333333');
 assert.throws(()=>calculatePackagePrices({...quota,fx}),/不再叠加/);
 assert.throws(()=>calculatePackagePrices({...quota,discountZhe:'1.5'}),/不再叠加/);
 assert.throws(()=>calculatePackagePrices({...quota,effectiveQuota:'0'}),/不能为零/);
});
test('rejects unsupported values, stale unit guessing and missing source evidence',()=>{
 assert.throws(()=>calculatePackagePrices({...discount,discountZhe:'73'}),/0–10/);
 assert.throws(()=>calculatePackagePrices({...discount,evidence:''}),/来源/);
 assert.throws(()=>calculatePackagePrices({...discount,rates:[{...rate(),unit:''}]}),/单位/);
 assert.throws(()=>calculatePackagePrices({...discount,fx:{...fx,date:''}}),/日期/);
 assert.throws(()=>calculatePackagePrices({...discount,rates:[rate('-1')]}),/非负/);
});
