import test from 'node:test';
import assert from 'node:assert/strict';
import { spawn } from 'node:child_process';
import { createServer } from 'node:net';
import { DatabaseSync } from 'node:sqlite';
import { mkdtemp, writeFile, readFile, rm } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { writeModelFixture, selectTestModel } from './model-catalog-fixture.mjs';

test('every AI route requires a first choice, remembers it and freezes models per task', { timeout: 30_000 }, async () => {
  const root = await mkdtemp(join(tmpdir(), 'hanabi-model-routes-'));
  const probe = createServer(); await new Promise(resolve => probe.listen(0, '127.0.0.1', resolve));
  const port = probe.address().port; await new Promise(resolve => probe.close(resolve));
  const base = `http://127.0.0.1:${port}`, log = join(root, 'model-invocations.jsonl'), cli = join(root, 'codex.cjs');
  await writeModelFixture(root);
  // Only inspect routing; no real inference, MCP writes or global Skill edits.
  await writeFile(cli, `#!${process.execPath}\nconst fs=require('node:fs');const args=process.argv.slice(2);if(args.includes('app-server')){let buffer='';process.stdin.on('data',chunk=>{buffer+=chunk;const lines=buffer.split('\\n');buffer=lines.pop();for(const line of lines){try{const message=JSON.parse(line);if(message.id)console.log(JSON.stringify({id:message.id,result:message.method==='account/read'?{account:{type:'chatgpt'}}:{}}));}catch{}}});}else{fs.appendFileSync(${JSON.stringify(log)},JSON.stringify(args)+'\\n');process.stdin.resume();process.stdin.on('end',()=>setTimeout(()=>process.exit(1),40));}`, { mode: 0o700 });
  const child = spawn(process.execPath, ['server.mjs'], { cwd: new URL('..', import.meta.url), env: { ...process.env, CODEX_HOME: root, CONTENT_ALCHEMY_DATA_DIR: join(root, 'data'), CONTENT_ALCHEMY_PORT: String(port), CONTENT_ALCHEMY_CODEX_BIN: cli }, stdio: ['ignore', 'ignore', 'ignore'] });
  const request = async (path, body, method = 'POST') => {
    const response = await fetch(base + path, { method: body === undefined ? 'GET' : method, headers: { Origin: base, 'Content-Type': 'application/json' }, body: body === undefined ? undefined : JSON.stringify(body) });
    return { status: response.status, body: await response.json() };
  };
  const waitIdle = async () => {
    for (let count = 0; count < 600; count++) {
      const { body } = await request('/api/analysis-jobs');
      if (body.jobs.every(job => !['queued', 'analyzing', 'commit_queued', 'committing'].includes(job.status))) return body.jobs;
      await new Promise(resolve => setTimeout(resolve, 20));
    }
    assert.fail('isolated jobs did not finish');
  };
  try {
    for (let n = 0; n < 100; n++) { try { await request('/healthz'); break; } catch { await new Promise(resolve => setTimeout(resolve, 30)); } }
    assert.equal((await request('/api/ai/models')).body.selectionRequired, true);
    const uuid = '00000000-0000-4000-8000-000000000000';
    for (const [path, body] of [
      ['/api/analysis-jobs', { itemIds: [uuid], mode: 'distill' }],
      ['/api/intake/interpretations', { text: '学标题。作品 https://xhslink.cn/o/example' }],
      ['/api/market-research/reports', { itemIds: [uuid] }],
      ['/api/market-research/discoveries', {}],
      [`/api/analysis-jobs/${uuid}/retry`, {}],
      [`/api/analysis-jobs/${uuid}/correct`, { correction: '更简洁' }],
      [`/api/analysis-jobs/${uuid}/approve`, { jobIds: [uuid], approvedRules: '已审核的规则' }],
    ]) {
      const result = await request(path, body);
      assert.equal(result.status, 400, path); assert.equal(result.body.code, 'MODEL_SELECTION_REQUIRED', path);
    }
    assert.deepEqual((await request('/api/analysis-jobs')).body.jobs, []);
    const items = [];
    for (let n = 0; n < 2; n++) items.push((await request('/api/items', { title: `素材${n}`, type: 'text', content: '先呈现结果，再说明过程，最后给一步行动。' })).body.id);
    await selectTestModel(base, 'gpt-6-luna');
    const batch = await request('/api/analysis-jobs', { itemIds: items, mode: 'distill', brief: '只分析文字结构' });
    assert.equal(batch.status, 202); assert.equal(batch.body.jobs.length, 2);
    assert.ok(batch.body.jobs.every(job => job.analysisModel === 'fixture::gpt-6-luna'));
    await selectTestModel(base, 'gpt-6-sol');
    const output = await request('/api/analysis-jobs', { itemIds: items, mode: 'produce', productionPrompt: '写三条短文案' });
    assert.equal(output.body.jobs[0].analysisModel, 'fixture::gpt-6-sol');
    const finished = await waitIdle();
    assert.ok(batch.body.jobs.every(job => finished.find(entry => entry.id === job.id).analysisModel === 'fixture::gpt-6-luna'));
    const firstId = batch.body.jobs[0].id, secondId = batch.body.jobs[1].id;
    assert.equal((await request(`/api/analysis-jobs/${firstId}/retry`, {})).body.job.analysisModel, 'fixture::gpt-6-sol');
    await waitIdle();
    const db = new DatabaseSync(join(root, 'data', 'library.sqlite'));
    db.prepare("UPDATE analysis_jobs SET status='completed',result='fixture result',candidate_rules='[\"fixture rule\"]' WHERE id=?").run(secondId); db.close();
    const correction = await request(`/api/analysis-jobs/${secondId}/correct`, { correction: '缩短说明' });
    assert.equal(correction.status, 202); assert.equal(correction.body.job.analysisModel, 'fixture::gpt-6-sol');
    const commit = await request(`/api/analysis-jobs/${secondId}/approve`, { jobIds: [secondId], approvedRules: '已审核的 fixture rule' });
    assert.equal(commit.status, 202); assert.equal(commit.body.job.analysisModel, 'fixture::gpt-6-sol');
    await waitIdle();
    const parsed = await request('/api/intake/interpretations', { text: '学标题。作品 https://xhslink.cn/o/example', model: 'fixture::gpt-6-luna' });
    assert.equal(parsed.body.interpretation.model, 'fixture::gpt-6-luna');
    for (let n = 0; n < 100; n++) { if (!(await request('/api/intake/interpretations')).body.activeCount) break; await new Promise(resolve => setTimeout(resolve, 20)); }
    assert.equal((await request('/api/ai/models')).body.lastModel, 'fixture::gpt-6-sol', 'an older interpretation changed the remembered choice');
    const calls = (await readFile(log, 'utf8')).trim().split('\n').map(JSON.parse);
    assert.equal(calls.filter(args => args[args.indexOf('--model') + 1] === 'gpt-6-luna').length, 3);
    assert.equal(calls.filter(args => args[args.indexOf('--model') + 1] === 'gpt-6-sol').length, 4);
    assert.ok(calls.every(args=>!args.includes('workspace-write')&&!args.includes('--add-dir')),'models must submit scoped edits through the server');
    assert.ok(calls.some(args => args.includes('--output-schema') && args.includes('gpt-6-luna')));
  } finally {
    child.kill('SIGTERM'); await new Promise(resolve => child.once('close', resolve));
    await rm(root, { recursive: true, force: true });
  }
});
