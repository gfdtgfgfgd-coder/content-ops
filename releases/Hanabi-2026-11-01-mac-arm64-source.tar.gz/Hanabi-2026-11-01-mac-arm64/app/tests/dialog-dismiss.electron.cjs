// Real Hanabi UI, isolated synthetic data. No personal database or live tabs.
const { app, BrowserWindow } = require('electron');
const { createServer } = require('node:http');
const { readFileSync, writeFileSync, mkdirSync, mkdtempSync } = require('node:fs');
const { resolve, join, extname } = require('node:path');
const { tmpdir } = require('node:os');
const assert = require('node:assert/strict');
app.disableHardwareAcceleration();
const root = resolve(__dirname, '..');
const output = mkdtempSync(join(tmpdir(), 'hanabi-dialogs-'));
for (const name of ['userData', 'sessionData', 'logs']) {
  const path = join(output, name); mkdirSync(path); app.setPath(name, path);
}
const item = {
  id: 'dialog-fixture', title: '剪辑方法 · 隔离示例', type: 'image',
  content: '先展示结果，再解释过程。\n\n这段正文用于检查资料弹窗的框外关闭、修改保护和图片预览。',
  tags: [], moduleIds: [], moduleValues: {}, sourceName: '隔离示例',
  updatedAt: '2026-10-21T00:00:00Z', attachments: [],
  mediaFrames: [{ id: 'frame-one', name: '画面一.jpg', mimeType: 'image/jpeg' }, { id: 'frame-two', name: '画面二.jpg', mimeType: 'image/jpeg' }],
};
const image = Buffer.from('<svg xmlns="http://www.w3.org/2000/svg" width="360" height="480"><rect width="360" height="480" fill="#e5f2fc"/><circle cx="180" cy="200" r="90" fill="#9e50c4"/><path d="M70 390h220" stroke="#006ec4" stroke-width="16"/></svg>');
const hooks = `\nwindow.__dialogTest = { state, openDetail, startDetailEditing, openDetailFrameViewer, openEditorAssetPreview,
  setRenameSaving: value => { collectionRenameSaving = value; } };
window.__confirmCalls = []; window.__confirmAnswer = false;
window.confirm = message => { window.__confirmCalls.push(message); return window.__confirmAnswer; };`;
let mutations = 0;
const server = createServer((request, response) => {
  const pathname = new URL(request.url, 'http://fixture').pathname;
  if (request.method !== 'GET') { mutations++; response.writeHead(400); response.end('{}'); return; }
  const json = value => { response.setHeader('Content-Type', 'application/json'); response.end(JSON.stringify(value)); };
  if (pathname === '/api/state') return json({ items: [item], counts: [] });
  if (pathname === '/api/library-modules') return json({ modules: [{ id: 'collection-one', name: '剪辑参考', viewKey: 'archive', fields: [] }] });
  if (pathname === '/api/analysis-jobs') return json({ jobs: [] });
  if (pathname.startsWith('/api/knowledge')) return json({ files: [] });
  if (pathname.startsWith('/api/uploads/')) { response.setHeader('Content-Type', 'image/svg+xml'); response.end(image); return; }
  const file = resolve(root, '.' + (pathname === '/' ? '/index.html' : pathname));
  if (!file.startsWith(root + '/')) { response.writeHead(403); response.end(); return; }
  try {
    let data = readFileSync(file);
    if (pathname === '/app.js') data = Buffer.from(data.toString() + hooks);
    response.setHeader('Content-Type', ({ '.html': 'text/html', '.mjs': 'text/javascript', '.js': 'text/javascript', '.css': 'text/css', '.woff2': 'font/woff2', '.svg': 'image/svg+xml', '.png': 'image/png' })[extname(file)] || 'application/octet-stream');
    response.end(data);
  } catch { response.writeHead(404); response.end(); }
});
app.whenReady().then(async () => {
  app.dock?.hide();
  await new Promise(resolve => server.listen(0, '127.0.0.1', resolve));
  const base = `http://127.0.0.1:${server.address().port}`;
  const window = new BrowserWindow({ show: false, width: 1400, height: 1000, webPreferences: { offscreen: true, contextIsolation: true } });
  const errors = [];
  window.webContents.on('console-message', event => { if (/Uncaught|TypeError|ReferenceError/.test(event.message || '')) errors.push(event.message); });
  const evaluate = async code => {
    try { return await window.webContents.executeJavaScript(code); }
    catch (error) { throw new Error(error.message + '\nEvaluating: ' + code.slice(0, 1200)); }
  };
  const delay = (ms = 50) => new Promise(resolve => setTimeout(resolve, ms));
  const waitFor = async code => {
    for (let attempt = 0; attempt < 100; attempt++) { if (await evaluate(code)) return; await delay(); }
    throw new Error('Timed out: ' + code);
  };
  const click = async (x, y, button = 'left') => {
    window.webContents.sendInputEvent({ type: 'mouseMove', x, y });
    window.webContents.sendInputEvent({ type: 'mouseDown', x, y, button, clickCount: 1 });
    window.webContents.sendInputEvent({ type: 'mouseUp', x, y, button, clickCount: 1 });
    await delay();
  };
  const escape = async () => {
    window.webContents.sendInputEvent({ type: 'keyDown', keyCode: 'Escape' });
    window.webContents.sendInputEvent({ type: 'keyUp', keyCode: 'Escape' });
    await delay();
  };
  const open = async id => {
    await evaluate(`(() => { const dialog = document.getElementById(${JSON.stringify(id)}); if (dialog.id === 'detail-dialog') __dialogTest.openDetail(__dialogTest.state.items[0]); else dialog.showModal(); })()`);
    await delay();
  };
  const isOpen = id => evaluate(`document.getElementById(${JSON.stringify(id)}).open`);
  try {
    await window.loadURL(base + '/');
    window.webContents.focus();
    await waitFor('window.__dialogTest?.state.items.length === 1');
    const ids = await evaluate(`[...document.querySelectorAll('dialog')].map(dialog => dialog.id)`);
    assert.deepEqual(new Set(ids),new Set(['entry-dialog','detail-dialog','inflow-collection-dialog','collection-create-dialog','collection-rename-dialog','asset-preview-dialog','frame-viewer-dialog','split-dialog','knowledge-category-dialog','ai-model-dialog']));
    assert.equal(await evaluate(`[...document.querySelectorAll('dialog button'), ...document.querySelector('#entry-form-template').content.querySelectorAll('button')].filter(button => /^(关闭|×)$/.test(button.textContent.trim())).length`), 0);
    const matrix = [];
    for (const theme of ['light', 'dark']) {
      await evaluate(`document.documentElement.classList.toggle('dark-theme', ${theme === 'dark'});`);
      for (const width of [1400, 390]) {
        window.setContentSize(width, 1000); await delay();
        for (const id of ids) {
          await open(id);
          const point = await evaluate(`(() => {const r=document.getElementById(${JSON.stringify(id)}).getBoundingClientRect();return {x:Math.ceil(r.left+4),y:Math.ceil(r.top+4)};})()`);
          await click(point.x, point.y);
          assert.equal(await isOpen(id), true, `${id}: clicking the dialog's own padding closed it`);
          await click(3, 3);
          assert.equal(await isOpen(id), false, `${id}: backdrop did not close (${theme}, ${width})`);
          await open(id); await escape();
          assert.equal(await isOpen(id), false, `${id}: Escape did not close (${theme}, ${width})`);
          matrix.push({ id, theme, width });
        }
      }
    }
    window.setContentSize(1400, 1000); await delay();
    await open('detail-dialog');
    const inside = await evaluate(`(() => {const r=document.querySelector('#detail-dialog').getBoundingClientRect();return {x:Math.ceil(r.left+20),y:Math.ceil(r.top+20)};})()`);
    for (const [start, end] of [[inside, { x: 3, y: 3 }], [{ x: 3, y: 3 }, inside], [{ x: 3, y: 3 }, { x: 30, y: 3 }]]) {
      window.webContents.sendInputEvent({ type: 'mouseDown', ...start, button: 'left', clickCount: 1 });
      window.webContents.sendInputEvent({ type: 'mouseMove', ...end });
      window.webContents.sendInputEvent({ type: 'mouseUp', ...end, button: 'left', clickCount: 1 });
      await delay(); assert.equal(await isOpen('detail-dialog'), true, 'Dragging was mistaken for an outside click');
    }
    await click(3, 3, 'right'); assert.equal(await isOpen('detail-dialog'), true);
    await click(3, 3);
    // Real nested previews close only their own layer.
    await open('detail-dialog');
    await evaluate(`__dialogTest.openDetailFrameViewer('frame-one')`);
    await click(3, 3);
    assert.equal(await isOpen('frame-viewer-dialog'), false);
    assert.equal(await isOpen('detail-dialog'), true);
    await evaluate(`__dialogTest.openDetailFrameViewer('frame-one'); document.querySelector('#frame-viewer-remove').click();`);
    await click(3, 3);
    assert.equal(await evaluate('__dialogTest.state.detailFrameChanges.removedFrameIds.length'), 1, 'Closing the preview lost pending removals');
    await click(3, 3);
    assert.equal(await isOpen('detail-dialog'), true, 'Declining discard lost unsaved frame changes');
    await evaluate('window.__confirmAnswer = true'); await click(3, 3);
    assert.equal(await isOpen('detail-dialog'), false);
    // Inline edits share the same guard for backdrop and Escape.
    await open('detail-dialog');
    await evaluate(`window.__confirmAnswer=false; __dialogTest.startDetailEditing(); const field=document.querySelector('#detail-title');field.textContent='未保存的修改';field.dispatchEvent(new Event('input',{bubbles:true}));`);
    await click(3, 3); assert.equal(await isOpen('detail-dialog'), true);
    await escape(); assert.equal(await isOpen('detail-dialog'), true);
    assert.equal(await evaluate("document.querySelector('#detail-title').textContent"), '未保存的修改');
    assert.equal(await evaluate('__dialogTest.state.detailDirty'), true);
    await evaluate('window.__confirmAnswer=true'); await escape();
    assert.equal(await isOpen('detail-dialog'), false);
    assert.equal(await evaluate('__dialogTest.state.items[0].title'), item.title);
    // Saving cannot be interrupted by outside clicks, Escape or Cancel.
    const guards = [
      ['detail-dialog', '__dialogTest.state.detailSaving'],
      ['frame-viewer-dialog', '__dialogTest.state.detailSaving'],
      ['entry-dialog', '__dialogTest.state.entrySaving'],
      ['split-dialog', '__dialogTest.state.splitSaving'],
      ['inflow-collection-dialog', '__dialogTest.state.inflowCollectionSaving'],
      ['collection-create-dialog', "document.querySelector('#collection-create-submit').disabled"],
    ];
    for (const [id, flag] of guards) {
      await open(id); await evaluate(`${flag}=true`);
      await click(3, 3); assert.equal(await isOpen(id), true, `${id}: saving interrupted by backdrop`);
      await escape(); assert.equal(await isOpen(id), true, `${id}: saving interrupted by Escape`);
      await evaluate(`document.querySelector('#${id} [data-close]')?.click()`);
      assert.equal(await isOpen(id), true, `${id}: saving interrupted by Cancel`);
      await evaluate(`${flag}=false`); await click(3, 3);
      assert.equal(await isOpen(id), false);
    }
    await open('collection-rename-dialog'); await evaluate('__dialogTest.setRenameSaving(true)');
    await click(3, 3); await escape(); assert.equal(await isOpen('collection-rename-dialog'), true);
    await evaluate(`document.querySelector('#collection-rename-dialog [data-close]').click();__dialogTest.setRenameSaving(false);`);
    assert.equal(await isOpen('collection-rename-dialog'), true);
    await click(3, 3);
    // Preview media is paused and removed; underlying modal remains open.
    await open('detail-dialog');
    await evaluate(`__dialogTest.openEditorAssetPreview({id:'preview-video',name:'示例视频',mimeType:'video/mp4'});window.__pauseCount=0;document.querySelector('#asset-preview-body video').pause=()=>{window.__pauseCount++};void 0;`);
    await click(3, 3);
    assert.equal(await evaluate('window.__pauseCount'), 1);
    assert.equal(await evaluate("document.querySelector('#asset-preview-body').childElementCount"), 0);
    assert.equal(await isOpen('detail-dialog'), true);
    assert.equal(await evaluate("getComputedStyle(document.querySelector('.detail-footer')).display"), 'none');
    writeFileSync(join(output, 'detail-without-close.png'), (await window.webContents.capturePage()).toPNG());
    await click(3, 3);
    await evaluate("document.querySelector('#collection-bulk-menu').open=true");
    await open('detail-dialog'); await escape();
    assert.equal(await isOpen('detail-dialog'), false);
    assert.equal(await evaluate("document.querySelector('#collection-bulk-menu').open"), true, 'Escape dismissed an underlying menu instead of the modal');
    await escape();
    assert.equal(await evaluate("document.querySelector('#collection-bulk-menu').open"), false);
    await evaluate("document.querySelector('#collection-bulk-menu').open=true"); await click(3, 3);
    assert.equal(await evaluate("document.querySelector('#collection-bulk-menu').open"), false);
    await evaluate("document.querySelector('#collection-bulk-menu').open=true"); await escape();
    assert.equal(await evaluate("document.querySelector('#collection-bulk-menu').open"), false);
    assert.equal(mutations, 0); assert.deepEqual(errors, []);
    console.log(JSON.stringify({ ok: true, dialogs: ids, matrixCases: matrix.length, verified: ['inside-padding', 'outside-click', 'Escape', 'drag-boundaries', 'right-click', 'nested-previews', 'unsaved-edits', 'pending-removals', 'saving-guards', 'media-cleanup', 'dropdown-dismissal', 'close-buttons-removed'], output }));
    window.destroy(); server.close(); app.exit(0);
  } catch (error) {
    console.error(error.stack || error); console.error(JSON.stringify({ errors, output }));
    window.destroy(); server.close(); app.exit(1);
  }
});
