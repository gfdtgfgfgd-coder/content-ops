import { writeModelFixture, selectTestModel } from './model-catalog-fixture.mjs';
import test from "node:test";
import assert from "node:assert/strict";
import { mkdtemp, writeFile, readFile, rm } from "node:fs/promises";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { spawn } from "node:child_process";
import { createServer } from "node:net";
import { DatabaseSync } from "node:sqlite";
import { randomUUID } from "node:crypto";
import { existsSync } from "node:fs";

test("source failure does not call AI or archive an error report, and the next job still runs", { timeout: 25_000 }, async () => {
  const root = await mkdtemp(join(tmpdir(), "hanabi-queue-"));
  const probe = createServer();
  await new Promise((resolve) => probe.listen(0, "127.0.0.1", resolve));
  const port = probe.address().port;
  await new Promise((resolve) => probe.close(resolve));
  const cli = join(root, "opencli.cjs"), codex = join(root, "codex.cjs"), sentinel = join(root, "ai-calls.txt"), cliCalls = join(root, "browser-calls.txt"), saveTarget = join(root, "cache-job-id");
  await writeFile(cli, `#!${process.execPath}\nrequire('node:fs').appendFileSync(${JSON.stringify(cliCalls)},'call\\n');process.stdout.write(JSON.stringify(process.argv.includes('profile')?{ok:true,data:{daemonRunning:true,profiles:[{contextId:'fixture',connected:true,default:true}]}}:{ok:false,error:{code:'SECURITY_BLOCK',message:'fixture source access denied'}}));\n`, { mode: 0o700 });
  await writeFile(codex, `#!${process.execPath}
let s='';process.stdin.on('data',x=>s+=x);process.stdin.on('end',async()=>{
 const jobId=s.match(/任务 ID：([^\\s]+)/)?.[1];require('node:fs').appendFileSync(${JSON.stringify(sentinel)},jobId+'\\n');
 if(!require('node:fs').existsSync(${JSON.stringify(saveTarget)})||require('node:fs').readFileSync(${JSON.stringify(saveTarget)},'utf8')!==jobId)return;
 const base='http://127.0.0.1:'+process.env.CONTENT_ALCHEMY_PORT;
 const call=async(name,args)=>{const r=await fetch(base+'/mcp',{method:'POST',headers:{'Content-Type':'application/json',Origin:base},body:JSON.stringify({jsonrpc:'2.0',id:1,method:'tools/call',params:{name,arguments:args}})});const x=await r.json();if(x.error||x.result?.isError)throw new Error(JSON.stringify(x));return x.result;};
 const payload=JSON.parse((await call('alchemy_get_analysis_job',{jobId})).content[0].text);
 if(!process.argv.includes('--image'))throw new Error('Native image input is missing');
 if(payload.job.sourceRead.visualInput.count!==(payload.job.scope.includes('image')?2:1))throw new Error('Image delivery was not recorded');
 if(!payload.furnaceProtocol.includes('归档 content 只写按需整理结果'))throw new Error('Intake output policy is missing');
 const visual=payload.sourceMedia.visualSearch;if(visual.required)await call('alchemy_review_visual_evidence',{jobId,decision:'sufficient',reason:'已核对全部提供的画面，可回答用户需求',reviewedFrameIds:visual.review.overviewIds,selectedImageIds:payload.job.scope.includes('image')?payload.item.attachments.filter(file=>file.mimeType.startsWith('image/')).map(file=>file.id):[]});
 if(payload.job.scope.includes('image')){
  if(payload.item.attachments.some(file=>file.mimeType.startsWith('video/')))throw new Error('Unselected video reached the model');
  await call('alchemy_update_media_coverage',{jobId,mediaType:'video',visualsReviewed:true,fullDurationReviewed:false,audioPresent:null,audioReviewed:false,note:'已读取正文与原始配图，视频和音频不在本次范围。'});
  await call('alchemy_save_library_item',{jobId,title:'正文与配图归档',collectionPurpose:'content',collectionReason:'表达与版式学习',type:'image',content:'按需求学习版式与文案。'});
  await call('alchemy_complete_analysis_job',{jobId,result:'按需求学习版式与文案。'});return;
 }
 await call('alchemy_update_media_coverage',{jobId,mediaType:'video',visualsReviewed:true,fullDurationReviewed:false,audioPresent:false,audioReviewed:false,onScreenTextReviewed:true,readerReady:true,note:'画面为抽样。'});
 const result='按需求整理的内容。证据边界：画面为抽样。';
 await call('alchemy_save_library_item',{jobId,title:'缓存素材归档',collectionPurpose:'content',collectionReason:'视频表达学习',type:'video',content:result});
 await call('alchemy_complete_analysis_job',{jobId,result});
});
`, { mode: 0o700 });
  await writeModelFixture(root);
  const child = spawn(process.execPath, ["server.mjs"], { cwd: new URL("..", import.meta.url), env: { ...process.env, CODEX_HOME: root, CONTENT_ALCHEMY_DATA_DIR: join(root, "data"), CONTENT_ALCHEMY_PORT: String(port), CONTENT_ALCHEMY_OPENCLI_BIN: cli, CONTENT_ALCHEMY_CODEX_BIN: codex }, stdio: ["ignore", "pipe", "pipe"] });
  let log = ""; child.stderr.on("data", (x) => log += x);
  const base = `http://127.0.0.1:${port}`;
  const api = async (path, body) => {
    const response = await fetch(base + path, body ? { method: "POST", headers: { "Content-Type": "application/json", Origin: base }, body: JSON.stringify(body) } : {});
    assert.ok(response.ok, `${response.status}: ${await response.clone().text()}`);
    return response.json();
  };
  try {
    for (let i = 0; i < 50; i++) {
      try { await api("/healthz"); break; } catch { await new Promise((resolve) => setTimeout(resolve, 100)); }
    }
    const placeholder = "待分析链接。请先打开原始页面读取内容；如果页面需要登录、访问受限或链接失效，先说明缺少什么，不要根据标题或链接猜测正文。";
    await selectTestModel(base);
    const raw = await api("/api/items", { title: "等待读取", type: "text", content: placeholder, sourceUrl: "https://xhslink.cn/o/example", tags: ["入炉样本", "链接"] });
    const good = await api("/api/items", { title: "真实文字", type: "text", content: "这是用户提供的真实作品正文。" });
    const badJob = (await api("/api/analysis-jobs", { itemIds: [raw.id], mode: "intake", scope: ["text", "video"], brief: "学习表达" })).jobs[0];
    const goodJob = (await api("/api/analysis-jobs", { itemIds: [good.id], mode: "intake", scope: ["text"], brief: "整理正文" })).jobs[0];
    let jobs;
    for (let i = 0; i < 100; i++) {
      jobs = (await api("/api/analysis-jobs")).jobs;
      if (jobs.length === 2 && jobs.every((job) => job.status === "failed")) break;
      await new Promise((resolve) => setTimeout(resolve, 100));
    }
    const failed = jobs.find((job) => job.id === badJob.id);
    assert.equal(failed.status, "failed", log);
    assert.equal(failed.result, "");
    assert.equal(failed.sourceRead.status, "failed");
    assert.equal(failed.uiChanges.length, 0);
    const state = await api("/api/state");
    assert.equal(state.items.find((item) => item.id === raw.id).content, placeholder);
    assert.equal(state.items.length, 2);
    assert.equal((await readFile(sentinel, "utf8")).trim(), goodJob.id);

    // A prepared source snapshot must survive projection into the archive.
    // Reprocessing the same video should use that source cache, while its
    // analysis frames stay out of the archive unless images were selected.
    const localDb = new DatabaseSync(join(root, "data", "library.sqlite"));
    const video = { id: randomUUID(), name: "source.mp4", mimeType: "video/mp4", size: 16 };
    const frame = { id: randomUUID(), name: "frame.png", mimeType: "image/png", size: 68, seconds: 0.5 };
    const ocr = { id: randomUUID(), name: "OCR.txt", mimeType: "text/plain", sourceType: "on-screen-text-ocr", size: 20, sampleCount: 2, expectedSampleCount: 2 };
    await writeFile(join(root, "data", "uploads", video.id + ".mp4"), "cached-source-file");
    await writeFile(join(root, "data", "uploads", frame.id + ".png"), Buffer.from("iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8/x8AAwMCAO+a9l8AAAAASUVORK5CYII=", "base64"));
    await writeFile(join(root, "data", "uploads", ocr.id + ".txt"), "00:00 原始画面文字");
    const sourceItem = localDb.prepare("SELECT * FROM items WHERE id=?").get(raw.id);
    const snapshot = { version: 1, prepared: true, acquisitionComplete: true, sourceUrl: raw.sourceUrl, scope: ["text", "video"], item: { ...sourceItem, type: "video", content: "这是已读取的原始作品正文。", attachments: JSON.stringify([video, ocr]), media_frames: JSON.stringify([frame]) }, coverage: { mediaType: "video", readerReady: true, onScreenTextReviewed: true, audioPresent: false, durationSeconds: 1, frameCount: 1 } };
    localDb.prepare("UPDATE analysis_jobs SET source_snapshot=?,brief='cache-fixture' WHERE id=?").run(JSON.stringify(snapshot), badJob.id);
    await writeFile(saveTarget, badJob.id);
    const callsBefore = await readFile(cliCalls, "utf8");
    for (let round = 0; round < 2; round++) {
      const response = await fetch(base + `/api/analysis-jobs/${badJob.id}/retry`, { method: "POST", headers: { Origin: base } });
      assert.equal(response.status, 202);
      let latest;
      for (let i = 0; i < 100; i++) {
        latest = (await api("/api/analysis-jobs")).jobs.find((job) => job.id === badJob.id);
        if (["completed", "partial", "failed"].includes(latest.status)) break;
        await new Promise((resolve) => setTimeout(resolve, 50));
      }
      assert.equal(latest.status, "partial", JSON.stringify(latest));
      assert.equal(latest.sourceRead.cached, true);
      const archived = await api(`/api/items/${raw.id}`);
      assert.equal(archived.mediaFrames.length, 0);
      assert.deepEqual(archived.attachments.map((asset) => asset.mimeType), ["video/mp4", "text/plain"]);
      assert.equal(archived.content.split("按需求整理的内容").length - 1, 1);
      assert.equal(archived.content.includes("这是已读取的原始作品正文"), false, "raw source text was duplicated into the visible result");
      assert.ok(existsSync(join(root, "data", "uploads", frame.id + ".png")), "analysis cache was deleted during archive projection");
    }
    assert.equal(await readFile(cliCalls, "utf8"), callsBefore, "cached retries opened the browser again");

    // A video note can be collected as text + static images. The unselected
    // video/audio must neither block completion nor appear in the archive.
    const imageItem = await api("/api/items", { title: "图文范围", type: "text", content: placeholder, sourceUrl: "https://xhslink.cn/o/images", tags: ["入炉样本", "链接"] });
    const image = { id: randomUUID(), name: "cover.png", mimeType: "image/png", size: 68, sourceType: "source-original" };
    await writeFile(join(root, "data", "uploads", image.id + ".png"), await readFile(join(root, "data", "uploads", frame.id + ".png")));
    const imageJobId = randomUUID(), timestamp = new Date().toISOString();
    const imageSnapshot = { ...snapshot, sourceUrl: imageItem.sourceUrl, scope: ["text", "image"], item: { ...localDb.prepare("SELECT * FROM items WHERE id=?").get(imageItem.id), type: "video", content: "真实的帖子文案。", attachments: JSON.stringify([video, image, ocr]), media_frames: JSON.stringify([frame]) }, coverage: { mediaType: "video", readerReady: true, onScreenTextReviewed: true, expectedImageCount: 1, imageCount: 1 } };
    localDb.prepare("INSERT INTO analysis_jobs(id,item_id,mode,status,brief,analysis_scope,destinations,source_snapshot,created_at,updated_at) VALUES (?,?,'intake','failed','学习版式与文案',?,'[\"archive\"]',?,?,?)")
      .run(imageJobId, imageItem.id, JSON.stringify(imageSnapshot.scope), JSON.stringify(imageSnapshot), timestamp, timestamp);
    await writeFile(saveTarget, imageJobId);
    const imageRetry = await fetch(base + `/api/analysis-jobs/${imageJobId}/retry`, { method: "POST", headers: { Origin: base } });
    assert.equal(imageRetry.status, 202);
    let imageJob;
    for (let i = 0; i < 100; i++) {
      imageJob = (await api("/api/analysis-jobs")).jobs.find((job) => job.id === imageJobId);
      if (["completed", "partial", "failed"].includes(imageJob.status)) break;
      await new Promise((resolve) => setTimeout(resolve, 50));
    }
    assert.equal(imageJob.status, "completed", JSON.stringify(imageJob));
    assert.deepEqual(imageJob.missingScopes, []);
    const imageArchive = await api(`/api/items/${imageItem.id}`);
    assert.equal(imageArchive.type, "image");
    assert.equal(imageArchive.attachments.filter((asset) => /^image\//.test(asset.mimeType)).length, 1);
    assert.equal(imageArchive.attachments.some((asset) => /^(video|audio)\//.test(asset.mimeType)), false);
    assert.equal(imageArchive.mediaFrames.length, 0);
    assert.equal(await readFile(cliCalls, "utf8"), callsBefore);

    const cleared = await fetch(base + "/api/analysis-jobs?stage=inflow", { method: "DELETE", headers: { Origin: base } });
    assert.equal(cleared.status, 200);
    assert.equal(existsSync(join(root, "data", "uploads", frame.id + ".png")), false, "clearing jobs leaked hidden source cache");
    assert.ok(existsSync(join(root, "data", "uploads", video.id + ".mp4")), "clearing jobs deleted an archived video");
    localDb.close();
  } finally {
    child.kill("SIGTERM");
    if (child.exitCode === null) await new Promise((resolve) => child.once("close", resolve));
    await rm(root, { recursive: true, force: true });
  }
});
