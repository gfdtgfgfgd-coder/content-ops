import test from 'node:test';
import assert from 'node:assert/strict';
import {DatabaseSync} from 'node:sqlite';
import {mkdtemp,mkdir,writeFile,readFile,rm} from 'node:fs/promises';
import {join,dirname} from 'node:path';
import {tmpdir} from 'node:os';
import {KnowledgeCatalog} from '../lib/knowledge-catalog.mjs';
import {LEGACY_KNOWLEDGE_CATEGORIES} from '../lib/knowledge-taxonomy.mjs';
import {knowledgeListFiles} from '../lib/market-knowledge.mjs';

const restoreOldRows=db=>{
 for(const category of LEGACY_KNOWLEDGE_CATEGORIES)db.prepare('INSERT INTO knowledge_categories(id,name,parent_id) VALUES(?,?,?)').run(category.id,category.name,category.parentId);
 db.prepare("DELETE FROM knowledge_catalog_meta WHERE key='taxonomy-v2'").run();
};
test('legacy storage categories merge once without changing any Skill, document, evidence or manual filing',async()=>{
 const root=await mkdtemp(join(tmpdir(),'hanabi-taxonomy-')),dir=join(root,'knowledge'),db=new DatabaseSync(join(root,'db.sqlite'));
 const contents={'SKILL.md':'# 我的基础 Skill','references/preferences.md':'# 我的手动规则','references/ai-market-research/SKILL.md':'# 市场调研主 Skill','references/ai-market-research/references/official/old.json':'[{"price":"1.25"}]'};
 for(const[path,body]of Object.entries(contents)){await mkdir(dirname(join(dir,path)),{recursive:true});await writeFile(join(dir,path),body);}
 try{
  let catalog=new KnowledgeCatalog(db,dir);
  assert.ok(LEGACY_KNOWLEDGE_CATEGORIES.every(old=>!catalog.categories().some(c=>c.id===old.id)),'fresh installs must not seed retired categories');
  await catalog.move(['references/preferences.md'],'workflow-main');
  restoreOldRows(db);
  db.prepare('INSERT INTO knowledge_file_categories(path,category_id,manual) VALUES(?,?,0)').run('references/ai-market-research/references/official/old.json','market-official');
  catalog=new KnowledgeCatalog(db,dir);
  const files=await catalog.files();
  assert.equal(files.length,4);assert.equal(files.filter(f=>f.filename==='SKILL.md').length,2);
  assert.equal(knowledgeListFiles(files).length,3);
  assert.equal(files.find(f=>f.filename==='old.json').categoryId,'market-main');assert.equal(files.find(f=>f.filename==='old.json').categoryAssigned,false);
  assert.equal(files.find(f=>f.path==='references/preferences.md').knowledgeGroupId,'workflow-main');assert.equal(files.find(f=>f.path==='references/preferences.md').categoryAssigned,true);
  for(const legacy of LEGACY_KNOWLEDGE_CATEGORIES){assert.ok(!catalog.categories().some(c=>c.id===legacy.id));assert.equal(catalog.categoryRedirects()[legacy.id],'market-main');}
  assert.throws(()=>catalog.update('market-official',{name:'旧页面不能改到其他分类'}),/不存在/);
  await assert.rejects(catalog.remove('market-official',{moveToCategoryId:'creation'}),/不存在/);
  await catalog.saveArtifact({jobId:'11111111-1111-1111-1111-111111111111',role:'report',title:'新报告',content:'# 新报告\n\n证据与分析'});
  for(let n=0;n<3;n++){
   catalog=new KnowledgeCatalog(db,dir);
   assert.ok(LEGACY_KNOWLEDGE_CATEGORIES.every(old=>!catalog.categories().some(c=>c.id===old.id)));
   assert.equal(catalog.categoryId('references/ai-market-research/references/reports/11111111-1111-1111-1111-111111111111.md'),'market-main');
   for(const[path,body]of Object.entries(contents))assert.equal(await readFile(join(dir,path),'utf8'),body);
  }
 }finally{db.close();await rm(root,{recursive:true,force:true});}
});
test('migration preserves renamed, reparented, manually used and custom child categories, including empty ones',async()=>{
 const root=await mkdtemp(join(tmpdir(),'hanabi-taxonomy-custom-')),dir=join(root,'knowledge'),db=new DatabaseSync(join(root,'db.sqlite'));
 await mkdir(dir);await writeFile(join(dir,'notes.md'),'# 我的知识');
 try{
  let catalog=new KnowledgeCatalog(db,dir);restoreOldRows(db);
  catalog.rename('market-reports','客户报告');catalog.update('market-official',{parentId:'creation'});
  await catalog.move(['notes.md'],'market-competitors');
  const child=catalog.create('我的子分类','market-methods'),empty=catalog.create('待整理');
  catalog=new KnowledgeCatalog(db,dir);
  for(const id of ['market-reports','market-official','market-competitors','market-methods',child.id,empty.id])assert.ok(catalog.categories().some(c=>c.id===id));
  for(const id of ['market-reports','market-official','market-competitors','market-methods'])assert.equal(catalog.categoryRedirects()[id],undefined);
  assert.equal(catalog.categoryId('references/ai-market-research/references/reports/new.md'),'market-reports');
  assert.equal((await catalog.files()).find(f=>f.path==='notes.md').categoryId,'market-competitors');
  assert.equal(catalog.categories().find(c=>c.id===child.id).parentId,'market-methods');
  assert.equal(catalog.categories().find(c=>c.id==='market-reports').name,'客户报告');
  assert.ok(!catalog.categories().some(c=>['market-keywords','market-data','market-history'].includes(c.id)));
 }finally{db.close();await rm(root,{recursive:true,force:true});}
});
