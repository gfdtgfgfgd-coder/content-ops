import test from 'node:test';
import assert from 'node:assert/strict';
import {resourceInventory,PENDING_INFLOW_LINK_CONTENT,isPendingInflowLink} from '../lib/resource-inventory.mjs';
import {workbenchSummary} from '../lib/workbench-presenter.mjs';

test('home, library, Skill and preview counts use one inventory through intake, deletion and job completion',()=>{
 const pending={id:'pending',type:'text',sourceUrl:'https://example.com/source',content:PENDING_INFLOW_LINK_CONTENT,tags:['入炉样本','链接']};
 const items=[{id:'one',content:'正文'},pending,{id:'two',content:'正文'}];
 const files=[{path:'SKILL.md',filename:'SKILL.md'},{path:'models/example/SKILL.md',filename:'SKILL.md'},{path:'preferences.md',filename:'preferences.md'},...Array.from({length:30},(_,i)=>({path:`evidence/${i}.json`,filename:`${i}.json`,skillKind:'evidence'}))];
 const jobs=[{id:'p',mode:'produce',status:'completed',result:'作品'},{id:'q',mode:'correction',parentMode:'produce',status:'analyzing',result:''},{id:'empty',mode:'produce',status:'completed',result:'   '}];
 const verify=()=>{
  const inventory=resourceInventory({items,jobs,knowledgeFiles:files}),home=workbenchSummary({items,jobs,knowledgeFiles:files});
  assert.equal(home.materials,inventory.archiveItems.length);assert.equal(home.knowledge,inventory.skillFiles.length);
  assert.equal(home.knowledgeDocuments,inventory.knowledgeDocuments.length);assert.equal(home.previewResources,inventory.archiveItems.length+inventory.productionJobs.length);
  return inventory;
 };
 assert.ok(isPendingInflowLink(pending));
 const initial=verify();assert.equal(initial.archiveItems.length,2);assert.equal(initial.skillFiles.length,2);assert.equal(initial.knowledgeDocuments.length,1);assert.equal(initial.previewCount,3);
 pending.content='已读到的真实正文';assert.equal(verify().archiveItems.length,3);
 items.splice(0,1);assert.equal(verify().previewCount,3);
 files.push({path:'new/SKILL.md',filename:'SKILL.md'});assert.equal(verify().skillFiles.length,3);
 jobs[1].status='completed';jobs[1].result='修订成品';assert.equal(verify().previewCount,4);
 jobs.splice(0,1);assert.equal(verify().previewCount,3);
 const duplicate=resourceInventory({items:[...items,items[0]],jobs:[...jobs,jobs[0]],knowledgeFiles:[...files,files[0]]});
 assert.equal(duplicate.archiveItems.length,2);assert.equal(duplicate.skillFiles.length,3);assert.equal(duplicate.productionJobs.length,1);
});
