import test from 'node:test';
import assert from 'node:assert/strict';
import { createBrowserConnection, existingChromeLaunchArgs } from '../lib/browser-startup.mjs';
import { classifySourceError } from '../lib/intake-source.mjs';
import { parseOpenCliEnvelope } from '../lib/opencli-output.mjs';

const profile = { contextId: 'saved-profile', default: true, connected: true };

test('daemon replies with nested ok fields retain the outer envelope', () => {
  const data = { action: 'started', status: { ok: true, extensionConnected: false } };
  assert.deepEqual(parseOpenCliEnvelope(JSON.stringify({ ok: true, data })), data);
  assert.deepEqual(parseOpenCliEnvelope(`progress\n${JSON.stringify({ ok: true, data })}\nupdate notice`), data);
  assert.throws(() => parseOpenCliEnvelope('{"ok":false,"error":{"code":"daemon_stop_failed","message":"still running"}}'), { code: 'daemon_stop_failed' });
});

test('cold intake starts the bridge, opens the browser and waits for the extension', async () => {
  let daemon = false, opened = false, polls = 0;
  const events = [];
  const connect = createBrowserConnection({
    listProfiles: async () => ({ daemonRunning: daemon, profiles: opened && ++polls >= 3 ? [profile] : [] }),
    startBridge: async () => { events.push('daemon'); daemon = true; },
    launchBrowser: async () => { events.push('browser'); opened = true; },
    delay: async () => {},
  });
  const result = await connect({ onProgress: message => events.push(message) });
  assert.equal(result, profile.contextId);
  assert.ok(events.indexOf('daemon') < events.indexOf('browser'));
  assert.equal(polls, 3);
  assert.match(events.at(-1), /已连接/);
});

test('connected browsers are reused and concurrent intake shares one startup', async () => {
  let opened = false, launches = 0, daemonStarts = 0;
  const connect = createBrowserConnection({
    listProfiles: async () => ({ daemonRunning: true, profiles: opened ? [profile] : [] }),
    startBridge: async () => { daemonStarts++; },
    launchBrowser: async () => { launches++; opened = true; },
  });
  assert.deepEqual(await Promise.all([connect(), connect(), connect()]), Array(3).fill(profile.contextId));
  assert.equal(await connect(), profile.contextId);
  assert.equal(launches, 1);
  assert.equal(daemonStarts, 0);
});

test('disconnected extensions time out without repeated launches; late connections recover', async () => {
  let now = 0, launches = 0, connected = false;
  const connect = createBrowserConnection({
    listProfiles: async () => ({ daemonRunning: true, profiles: connected ? [profile] : [] }),
    startBridge: async () => assert.fail('daemon is already running'),
    launchBrowser: async () => { launches++; },
    clock: () => now, delay: async ms => { now += ms; }, timeoutMs: 100, pollMs: 25,
  });
  await assert.rejects(connect(), error => {
    assert.equal(classifySourceError(error).code, 'SOURCE_BROWSER_DISCONNECTED');
    assert.match(error.message, /扩展尚未连接/);
    return true;
  });
  await assert.rejects(connect(), { code: 'SOURCE_BROWSER_DISCONNECTED' });
  assert.equal(now, 100);
  assert.equal(launches, 1);
  connected = true;
  assert.equal(await connect(), profile.contextId);
});

test('launch uses the existing enabled bridge profile, without a new profile or security flags', async () => {
  const args = await existingChromeLaunchArgs({ home: '/example', exists: () => true, json: async path => {
    if (path.endsWith('Local State')) return { profile: { last_used: 'Default', info_cache: { Default: {}, 'Profile 2': {}, '../../invalid': {} } } };
    if (path.includes('/Profile 2/')) return { extensions: { settings: { existing: { manifest: { name: 'OpenCLI' }, disable_reasons: [] } } } };
    return {};
  } });
  assert.deepEqual(args, ['-g', '-a', '/Applications/Google Chrome.app', '--args', '--profile-directory=Profile 2']);
});

test('missing browser is a clear non-retryable startup error', async () => {
  await assert.rejects(existingChromeLaunchArgs({ exists: () => false }), error => {
    const failure = classifySourceError(error);
    assert.equal(failure.code, 'SOURCE_BROWSER_START_FAILED');
    assert.equal(failure.retryable, false);
    return true;
  });
});
