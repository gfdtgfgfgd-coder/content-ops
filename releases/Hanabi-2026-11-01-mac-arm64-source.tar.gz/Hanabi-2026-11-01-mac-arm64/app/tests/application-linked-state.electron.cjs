// Run the real application against mutable, isolated API fixtures.
const {app,BrowserWindow}=require('electron');
const {createServer}=require('node:http');
const {readFileSync,mkdirSync,mkdtempSync}=require('node:fs');
const {join,resolve,extname}=require('node:path');
const {tmpdir}=require('node:os');
const assert=require('node:assert/strict');
app.disableHardwareAcceleration();
const root=resolve(__dirname,'..'),output=mkdtempSync(join(tmpdir(),'hanabi-linked-state-'));
for(const key of ['userData','sessionData','logs']){const path=join(output,key);mkdirSync(path);app.setPath(key,path);}
const placeholder='待分析链接。请先打开原始页面读取内容；如果页面需要登录、访问受限或链接失效，先说明缺少什么，不要根据标题或链接猜测正文。';
const material=id=>({id,title:id,type:'text',content:'真实资料正文',tags:[],attachments:[],mediaFrames:[],moduleIds:[],updatedAt:'2026-10-26T00:00:00Z'});
const pending={...material('pending'),content:placeholder,sourceUrl:'https://example.com/source',tags:['入炉样本','链接']};
let items=[material('one'),material('two'),pending];
const files=[{path:'SKILL.md',filename:'SKILL.md',name:'基础 Skill',extension:'.md',categoryId:'workflow'},{path:'model/SKILL.md',filename:'SKILL.md',name:'模型 Skill',extension:'.md',categoryId:'workflow'},{path:'preferences.md',filename:'preferences.md',name:'用户偏好',extension:'.md',categoryId:'workflow'},{path:'raw.json',filename:'raw.json',name:'底层证据',extension:'.json',categoryId:'workflow',skillKind:'evidence'}];
const product={id:'output',itemId:'one',title:'成品',mode:'produce',status:'completed',result:'# 成品\n\n作品正文',scope:['text'],destinations:['knowledge'],updatedAt:'2026-10-26T00:00:00Z',uiChanges:[],candidateRules:[]};
const jobs=[product];let mutations=0,knowledgeRevision=1,slowKnowledgePath='',unchangedReads=0;
const server=createServer((request,response)=>{
 const path=new URL(request.url,'http://fixture').pathname;
 const json=value=>{response.setHeader('Content-Type','application/json');response.end(JSON.stringify(value));};
 if(request.method!=='GET'){mutations++;response.writeHead(400);response.end('{}');return;}
 if(path==='/api/state')return json({items,counts:[]});
 if(path==='/api/library-modules')return json({modules:[]});
 if(path==='/api/analysis-jobs')return json({jobs});
 if(path==='/api/knowledge/index')return json({files,categories:[{id:'workflow',name:'Skill 与工作流程',parentId:''}]});
 if(path==='/api/market-research/discoveries')return json({discoveries:[],activeCount:0});
 if(path==='/api/chats')return json({chats:[]});
 if(path==='/api/connections')return json({connections:[],subscriptions:[]});
 if(path==='/api/ai/models')return json({models:[],selected:null});
 if(path==='/api/knowledge/file'){
  const filePath=new URL(request.url,'http://fixture').searchParams.get('path'),etag='"knowledge-'+knowledgeRevision+'"';response.setHeader('ETag',etag);
  if(request.headers['if-none-match']===etag){unchangedReads++;response.writeHead(304);response.end();return;}
  response.setHeader('Content-Type','text/plain; charset=utf-8');
  const text='# 阅读原件\n\n档案：'+filePath+' · 版本 '+knowledgeRevision+'\n\n'+(knowledgeRevision>1?'最新分组价格：claude x0.3。\n\n':'')+Array.from({length:100},(_,i)=>`第 ${i+1} 段。用于验证刷新后能回到原件的原阅读位置。`).join('\n\n');
  if(filePath===slowKnowledgePath)setTimeout(()=>response.end(text),120);else response.end(text);return;
 }
 if(path.startsWith('/api/'))return json({});
 const absolute=resolve(root,'.'+(path==='/'?'/index.html':path));
 if(!absolute.startsWith(root+'/')){response.writeHead(403);response.end();return;}
 try{
  let data=readFileSync(absolute);
  if(path==='/app.js')data=Buffer.from(data.toString()+`\nwindow.__linkedState={state,loadState,loadKnowledge,refreshAnalysisJobs,setView,openKnowledgeFile};`);
  response.setHeader('Content-Type',({'.html':'text/html','.js':'text/javascript','.mjs':'text/javascript','.css':'text/css','.woff2':'font/woff2','.png':'image/png'})[extname(absolute)]||'application/octet-stream');response.end(data);
 }catch{response.writeHead(404);response.end();}
});
app.whenReady().then(async()=>{
 app.dock?.hide();await new Promise(resolve=>server.listen(0,'127.0.0.1',resolve));
 const window=new BrowserWindow({show:false,width:1400,height:1050,webPreferences:{offscreen:true,contextIsolation:true}}),errors=[];
 window.webContents.on('console-message',event=>{if(/Uncaught|ReferenceError|TypeError/.test(event.message||''))errors.push(event.message);});
 const evaluate=code=>window.webContents.executeJavaScript(code);
 const wait=async(code)=>{for(let i=0;i<100;i++){if(await evaluate(code))return;await new Promise(resolve=>setTimeout(resolve,50));}throw Error('Timed out: '+code+' '+JSON.stringify(errors));};
 const frame=()=>evaluate('new Promise(resolve=>requestAnimationFrame(()=>requestAnimationFrame(resolve)))');
 const reload=async()=>{await new Promise(resolve=>{window.webContents.once('did-finish-load',resolve);window.webContents.reload();});await wait('window.__linkedState?.state.navigationReady');await frame();};
 let phase='startup';
 const homeCounts=()=>evaluate(`Object.fromEntries([...document.querySelectorAll('[data-resource-count]')].map(node=>[node.dataset.resourceCount,Number(node.textContent)]))`);
 const parity=async(expected)=>{
  assert.deepEqual(await homeCounts(),expected);
  assert.equal(await evaluate(`__linkedState.setView('archive');Number(document.querySelector('[data-module-filter=""] .module-tab-count').textContent)`),expected.archive);
  assert.equal(await evaluate(`__linkedState.setView('knowledge');Number(document.querySelector('#knowledge-total').textContent)`),expected.knowledge);
  assert.equal(await evaluate(`__linkedState.setView('preview');document.querySelectorAll('#preview-item-select option[value]:not([value=""])').length`),expected.preview);
 };
 try{
  await window.loadURL(`http://127.0.0.1:${server.address().port}/`);
  await wait('window.__linkedState?.state.navigationReady');
  assert.equal(await evaluate('__linkedState.state.view'),'home');
  phase='initial counts';await parity({archive:2,knowledge:2,preview:3});
  // Update while the home page is hidden: both its count and the destination
  // lists must follow the same source without reloading or manual reconciliation.
  pending.content='采火完成后的真实正文';
  await evaluate('__linkedState.loadState()');await parity({archive:3,knowledge:2,preview:4});
  items=items.filter(item=>item.id!=='two');await evaluate('__linkedState.loadState()');await parity({archive:2,knowledge:2,preview:3});
  files.push({path:'new/SKILL.md',filename:'SKILL.md',name:'新增 Skill',extension:'.md',categoryId:'workflow'});
  await evaluate('__linkedState.loadKnowledge()');await parity({archive:2,knowledge:3,preview:3});
  jobs.push({...product,id:'revision',mode:'correction',parentMode:'produce',result:'# 修订成品\n\n修订正文'});
  await evaluate('__linkedState.refreshAnalysisJobs()');await parity({archive:2,knowledge:3,preview:4});
  phase='navigation';const navigation=[];
  for(const width of [1400,900]){
   window.setContentSize(width,1050);await frame();
   const peers=await evaluate(`(()=>{__linkedState.setView('home');return [...document.querySelectorAll('.workflow-nav > .nav-stage-group > .flow-nav-link')].map(button=>({view:button.dataset.view,parent:button.parentElement.parentElement.className,height:Math.round(button.getBoundingClientRect().height),glyph:Math.round(button.querySelector('.nav-glyph').getBoundingClientRect().width),font:getComputedStyle(button.querySelector('strong')).fontSize}));})()`);
   assert.deepEqual(peers.map(peer=>peer.view),['archive','knowledge','preview']);
   assert.equal(new Set(peers.map(peer=>peer.height)).size,1,JSON.stringify(peers));assert.equal(new Set(peers.map(peer=>peer.font)).size,1);assert.equal(new Set(peers.map(peer=>peer.glyph)).size,1);
   navigation.push({width,peers});
  }
  phase='brand workbench';
  assert.equal(await evaluate(`document.querySelectorAll('.nav-stage-home').length`),0);
  await evaluate(`__linkedState.setView('archive');document.querySelector('.hanabi-brand').click()`);
  assert.equal(await evaluate(`__linkedState.state.view`),'home');
  assert.equal(await evaluate(`document.querySelector('.hanabi-brand').getAttribute('aria-current')`),'page');
  phase='reload archive';
  items.push(...Array.from({length:30},(_,i)=>material('reading-'+i)));
  await evaluate(`__linkedState.loadState()`);
  await evaluate(`__linkedState.setView('archive');document.querySelector('#collection-search').value='reading';document.querySelector('#collection-search').dispatchEvent(new Event('input'));`);
  await frame();await evaluate(`window.scrollTo(0,700)`);await frame();
  const archiveBefore=await evaluate(`({view:__linkedState.state.view,query:__linkedState.state.collectionQuery,y:scrollY})`);
  assert.ok(archiveBefore.y>=690);
  await reload();
  const archiveAfter=await evaluate(`({view:__linkedState.state.view,query:document.querySelector('#collection-search').value,y:scrollY})`);
  assert.deepEqual(archiveAfter,archiveBefore);
  phase='reload knowledge reader';
  await evaluate(`__linkedState.setView('knowledge');__linkedState.openKnowledgeFile('SKILL.md')`);await frame();
  await evaluate(`document.querySelector('#knowledge-reader').scrollTop=600`);await frame();
  assert.equal(await evaluate(`document.querySelector('#knowledge-reader').scrollTop`),600);
  await reload();
  const knowledgeAfter=await evaluate(`({view:__linkedState.state.view,path:__linkedState.state.currentKnowledgePath,y:document.querySelector('#knowledge-reader').scrollTop})`);
  assert.deepEqual(knowledgeAfter,{view:'knowledge',path:'SKILL.md',y:600});
  phase='knowledge freshness';knowledgeRevision=2;
  await evaluate(`__linkedState.openKnowledgeFile('SKILL.md',{refresh:true})`);
  assert.match(await evaluate(`document.querySelector('#knowledge-reader').textContent`),/最新分组价格：claude x0.3/);
  assert.equal(await evaluate(`document.querySelector('#knowledge-reader').scrollTop`),600,'an updated archive must keep the reading position');
  await evaluate(`window.__readerBefore=document.querySelector('#knowledge-reader').firstElementChild;__linkedState.openKnowledgeFile('SKILL.md',{refresh:true})`);
  assert.equal(await evaluate(`window.__readerBefore===document.querySelector('#knowledge-reader').firstElementChild`),true,'unchanged content must not flicker');assert.ok(unchangedReads>=1);
  knowledgeRevision=3;
  await evaluate(`Object.defineProperty(document,'hidden',{configurable:true,value:false});window.dispatchEvent(new Event('focus'))`);
  await wait(`document.querySelector('#knowledge-reader').textContent.includes('版本 3')`);
  assert.equal(await evaluate(`document.querySelector('#knowledge-reader').scrollTop`),600,'focus refresh must preserve the reading position');
  phase='knowledge read race';slowKnowledgePath='SKILL.md';
  await evaluate(`Promise.all([__linkedState.openKnowledgeFile('SKILL.md'),__linkedState.openKnowledgeFile('model/SKILL.md')])`);
  assert.equal(await evaluate(`document.querySelector('#knowledge-reader code').textContent`),'model/SKILL.md','a slower previous archive must not overwrite the chosen archive');slowKnowledgePath='';
  phase='reload production mode';
  await evaluate(`__linkedState.setView('outflow');document.querySelector('#task-mode').value='research';document.querySelector('#task-mode').dispatchEvent(new Event('change'));document.querySelector('#task-output').value='市场调研比价报告 / Word';`);
  await reload();
  const productionAfter=await evaluate(`({view:__linkedState.state.view,mode:document.querySelector('#task-mode').value,output:document.querySelector('#task-output').value})`);
  assert.deepEqual(productionAfter,{view:'outflow',mode:'research',output:'市场调研比价报告 / Word'});
  phase='new launch';
  await window.loadURL(`http://127.0.0.1:${server.address().port}/?reopen`);
  await wait('window.__linkedState?.state.navigationReady');
  assert.equal(await evaluate('__linkedState.state.view'),'home');assert.equal(await evaluate('scrollY'),0);
  assert.equal(mutations,0);assert.deepEqual(errors,[]);
  // Visual proof is captured from the installed app in the user's browser;
  // this isolated test exercises state, actual reloads and responsive geometry.
  console.log(JSON.stringify({ok:true,knowledgeFreshness:{contentUpdated:true,scrollPreserved:true,unchangedReads,staleReadsIgnored:true},crossViewMutations:4,reload:{archiveBefore,archiveAfter,knowledgeAfter,productionAfter,newLaunch:'home'},finalCounts:await homeCounts(),navigation}));
  window.destroy();server.close();app.exit(0);
 }catch(error){console.error(phase,error.stack,JSON.stringify(errors));window.destroy();server.close();app.exit(1);}
});
