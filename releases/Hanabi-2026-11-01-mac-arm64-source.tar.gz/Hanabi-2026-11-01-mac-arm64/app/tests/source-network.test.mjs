import test from "node:test";
import assert from "node:assert/strict";
import { readFile } from "node:fs/promises";
import vm from "node:vm";
import { createSourceMediaFetcher, sourceProxyForUrl, validateSourceMediaUrl, isPublicIpAddress } from "../lib/source-network.mjs";
import { missingSourceScopes, readXhsSource, classifySourceError, retrySourceRead } from "../lib/intake-source.mjs";
import { activeWorkStatuses, filterWorkJobs, workJobStage } from "../lib/workbench-presenter.mjs";

const media = "https://sns-webpic-qc.xhscdn.com/image.webp";

test("media requests use the configured proxy and honor NO_PROXY", async () => {
  const env = { HTTPS_PROXY: "http://127.0.0.1:7890", NO_PROXY: "localhost,.example.com" };
  assert.equal(sourceProxyForUrl(new URL(media), env), env.HTTPS_PROXY);
  assert.equal(sourceProxyForUrl(new URL(media), { ...env, no_proxy: ".xhscdn.com" }), "");
  assert.equal(sourceProxyForUrl(new URL(media), { ...env, no_proxy: "*" }), "");
  assert.equal(sourceProxyForUrl(new URL(media), { ...env, no_proxy: "sns-webpic-qc.xhscdn.com:80" }), env.HTTPS_PROXY);
  const dispatchers = [];
  const client = createSourceMediaFetcher({ env, fetchImpl: async (_url, options) => {
    assert.equal(options.redirect, "manual"); dispatchers.push(options.dispatcher.constructor.name);
    return new Response("image", { headers: { "content-type": "image/webp" } });
  } });
  try {
    await client.fetch(media);
    env.NO_PROXY = "*";
    await client.fetch(media);
    assert.deepEqual(dispatchers, ["ProxyAgent", "Agent"]);
  } finally { await client.close(); }
});

test("proxy support retains CDN allowlist and checks every redirect", async () => {
  assert.equal(validateSourceMediaUrl(media.replace("https:", "http:")).protocol, "https:");
  for (const url of ["https://127.0.0.1/pic", "https://xhscdn.com.evil.test/a", "https://evilxhscdn.com/a", "https://u:p@xhscdn.com/a", "https://xhscdn.com:8080/a", "file:///a"]) assert.throws(() => validateSourceMediaUrl(url));
  let calls = 0;
  const client = createSourceMediaFetcher({ env: {}, fetchImpl: async () => { calls++; return new Response(null, { status: 302, headers: { location: "https://127.0.0.1/private" } }); } });
  try { await assert.rejects(client.fetch(media), { code: "SOURCE_MEDIA_ADDRESS_INVALID" }); assert.equal(calls, 1); }
  finally { await client.close(); }
});

test("direct media connections reject private DNS results at connect time", async () => {
  for (const ip of ["127.0.0.1", "10.0.0.1", "192.168.1.1", "198.18.0.1", "::1", "fe80::1", "::ffff:127.0.0.1", "::ffff:7f00:1"]) assert.equal(isPublicIpAddress(ip), false, ip);
  assert.equal(isPublicIpAddress("8.8.8.8"), true);
  const client = createSourceMediaFetcher({ env: {}, lookupImpl: (_host, _options, callback) => callback(null, [{ address: "127.0.0.1", family: 4 }]) });
  try { await assert.rejects(client.fetch(media), { code: "SOURCE_MEDIA_PRIVATE_ADDRESS" }); }
  finally { await client.close(); }
  assert.equal(classifySourceError({ code: "SOURCE_DNS_UNAVAILABLE", message: "解析失败" }).retryable, true);
});

test("scope completion requires actual selected images, independently of source media type", () => {
  const image = { id: "image", mimeType: "image/webp" };
  const item = { type: "video", content: "来源真实正文", attachments: [image], media_frames: [] };
  const coverage = { mediaType: "video", readerReady: true, expectedImageCount: 1, audioPresent: null };
  assert.deepEqual(missingSourceScopes(coverage, ["text", "image"], item), []);
  assert.deepEqual(missingSourceScopes(coverage, ["text", "image"], { ...item, attachments: [] }), ["image"]);
  assert.deepEqual(missingSourceScopes({ ...coverage, mediaType: "image", expectedImageCount: 2 }, ["text", "image"], item), ["image"]);
  assert.deepEqual(missingSourceScopes(coverage, ["text", "image"], item, () => false), ["image"]);
  assert.deepEqual(missingSourceScopes(coverage, ["text"], item), []);
});

test("one failed asset does not discard other requested images", async () => {
  const source = await readFile(new URL("../server.mjs", import.meta.url), "utf8");
  const functionCode = source.slice(source.indexOf("async function downloadSourceMedia("), source.indexOf("async function prepareSourceForAnalysis("));
  const written = [];
  const download = vm.runInNewContext(`(${functionCode})`, {
    Buffer, AbortSignal, analysisSignal: ms=>AbortSignal.timeout(ms), MAX_FILE_BYTES: 1000, MAX_MEDIA_BYTES: 1000,
    MIME_EXTENSIONS: new Map([["image/webp", ".webp"]]), safeFilename: (s) => s, join: (...s) => s.join("/"),
    writeFile: async (path, bytes) => written.push({ path, size: bytes.length }),
    retrySourceRead: (fn, options) => retrySourceRead(fn, { ...options, delay: async () => {} }), classifySourceError,
    sourceMediaClient: { fetch: async (url) => url.includes("broken") ? new Response("denied", { status: 403 }) : new Response("image", { headers: { "content-type": "image/webp" } }) },
  });
  const result = await download([{ type: "video", url: "broken-video" }, { type: "image", url: "good-1" }, { type: "image", url: "broken-image" }, { type: "image", url: "good-2" }], "/fixture");
  assert.equal(result.downloaded.length, 2); assert.equal(result.failures.length, 2); assert.equal(written.length, 2);
  assert.ok(written.every((file) => file.path.endsWith(".webp") && file.size === 5));
});

test("reader reports per-asset failures while retaining readable body", async () => {
  const signed = "https://www.xiaohongshu.com/explore/abc123?xsec_token=fixture";
  const result = await readXhsSource({ sourceUrl: signed, jobId: "asset-results", profile: "p", directory: "/unused", delay: async () => {},
    execute: async (_profile, args) => args.includes("open") ? { page: "owned" } : args.includes("eval") ? { url: signed, ready: true, description: "作品正文", media: [{ type: "image", url: media }] } : {},
    download: async () => ({ downloaded: [{ type: "image" }], failures: [{ type: "image", code: "SOURCE_MEDIA_FAILED", message: "下载失败", detail: "HTTP 403", retryable: false }] }),
  });
  assert.equal(result.description, "作品正文"); assert.equal(result.downloadError.code, "SOURCE_MEDIA_INCOMPLETE");
});

test("image-only gaps have image actions rather than a video warning", async () => {
  const source = await readFile(new URL("../app.js", import.meta.url), "utf8");
  const code = source.slice(source.indexOf("function renderAnalysisJobs()"), source.indexOf("function renderCard("));
  const elements = new Map();
  const $ = (selector) => { if (!elements.has(selector)) elements.set(selector, {contains:()=>false}); return elements.get(selector); };
  const state = { view: "inflow", workJobFilter: 'all', expandedJobs: new Map(), items: [], correctionDrafts: {}, reviewJobIds: new Set(), analysisJobs: [{ id: "fixture", itemId: "item", mode: "intake", status: "partial", scope: ["text", "image"], destinations: ["archive"], missingScopes: ["image"], mediaCoverage: { mediaType: "video", note: "正文已读取，图片下载失败。" } }] };
  vm.runInNewContext(`${code};renderAnalysisJobs();`, { $, $$:()=>[], state, document:{activeElement:null}, renderWorkbenchHome:()=>{}, renderMarketDiscoveries:()=>{}, filterWorkJobs, activeWorkStatuses, workJobStage, queueFor: () => new Set(), isPendingInflowLink: () => false, inflowDestinationLabels: { archive: "资料库" }, inflowScopeOptions: [["text", "文字"], ["image", "图片"]], escapeHtml: (s) => String(s), safeHttpUrl: (s) => s });
  const html = $("#analysis-job-list").innerHTML;
  assert.ok(html.includes("图片未读全")); assert.ok(html.includes("图片尚未读取完整")); assert.ok(html.includes("补传图片"));
  assert.equal(html.includes("视频未读全"), false); assert.equal(html.includes("补传原视频"), false);
});

test("reprocessing the same item refreshes its archive even when change count is unchanged", async () => {
  const source = await readFile(new URL("../app.js", import.meta.url), "utf8");
  const start = source.indexOf("async function refreshAnalysisJobs(");
  assert.ok(start >= 0);
  const code = source.slice(start, source.indexOf("\nfunction renderWorkbenchHome()"));
  const old = { id: "job", status: "analyzing", uiChanges: [{ kind: "item", id: "item", attachmentCount: 0 }] };
  const next = { ...old, status: "completed", uiChanges: [{ kind: "item", id: "item", attachmentCount: 2 }] };
  let refreshed = 0;
  await vm.runInNewContext(`${code};refreshAnalysisJobs();`, { state: { view: "collection", analysisJobs: [old], resourceReady: {jobs:false} }, analysisClearInProgress: false, analysisPollTimer: null, api: async () => ({ jobs: [next] }), loadState: async () => { refreshed++; }, loadKnowledge: async()=>{}, renderLinkedResourceViews: () => {}, renderAnalysisJobs: () => {}, clearTimeout: () => {}, console });
  assert.equal(refreshed, 1);
});
