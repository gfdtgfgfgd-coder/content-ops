const {app,BrowserWindow}=require('electron');const {createServer}=require('node:http');const {readFileSync,mkdtempSync,mkdirSync,writeFileSync}=require('node:fs');const {join,resolve,extname}=require('node:path');const {tmpdir}=require('node:os');const assert=require('node:assert/strict');
app.disableHardwareAcceleration();const root=resolve(__dirname,'..'),out=mkdtempSync(join(tmpdir(),'hanabi-refine-ui-'));for(const key of ['userData','sessionData','logs']){const path=join(out,key);mkdirSync(path);app.setPath(key,path);}
const categories=[{id:'workflow',name:'Skill 与工作流程',parentId:''},{id:'workflow-main',name:'基础 Skill',parentId:'workflow',isGroup:1},{id:'creation',name:'创作方法与风格',parentId:''},{id:'writing',name:'内容方法',parentId:'creation',isGroup:1}];
const files=[{path:'SKILL.md',filename:'SKILL.md',name:'基础 Skill',extension:'.md',categoryId:'workflow',knowledgeGroupId:'workflow-main'},{path:'references/method.md',filename:'method.md',name:'叙事方法',extension:'.md',categoryId:'writing',knowledgeGroupId:'writing'},{path:'raw.json',filename:'raw.json',name:'原始证据',extension:'.json',categoryId:'writing',skillKind:'evidence'}];
const items=[1,2].map(n=>({id:'sample-'+n,title:'软广样本 '+n,type:'text',content:'先建立人物需求，再让产品参与解决问题。',tags:[],moduleIds:[],attachments:[],mediaFrames:[],updatedAt:'2026-10-27T00:00:00Z'}));
const jobs=[],posted=[];const server=createServer(async(req,res)=>{
 const path=new URL(req.url,'http://fixture').pathname,json=value=>{res.setHeader('Content-Type','application/json');res.end(JSON.stringify(value));};
 if(req.method==='POST'){
  let raw='';for await(const part of req)raw+=part;const body=JSON.parse(raw);posted.push({path,body});
  if(path==='/api/analysis-jobs'){
   const target={...body.knowledgeDestination,path:'user-skills/11111111-1111-1111-1111-111111111111/SKILL.md',categoryName:'内容方法'};
   jobs.push(...body.itemIds.map((id,n)=>({id:'job-'+n,itemId:id,title:'样本调配 '+n,mode:'distill',status:'completed',destinations:['knowledge'],result:'逐段拆解与仿写结果',candidateRules:['规则 '+n+'：先明确人物需求。'],uiChanges:[],knowledgeDestination:target,refineRecipe:body.refineRecipe})));return json({jobs});
  }
  if(path.endsWith('/approve')){const target={...body.knowledgeDestination,title:'叙事方法',categoryName:'内容方法'};const job={id:'commit',itemId:'sample-1',mode:'commit',status:'completed',destinations:['knowledge'],sourceJobIds:body.jobIds,approvedRules:body.approvedRules,commitResult:'已更新选定档案。',knowledgeDestination:target,uiChanges:[{kind:'knowledge',path:target.path,title:target.title}]};jobs.push(job);return json({job});}
  res.writeHead(400);return res.end('{}');
 }
 if(path==='/api/state')return json({items,counts:[]});if(path==='/api/library-modules')return json({modules:[]});if(path==='/api/analysis-jobs')return json({jobs});if(path==='/api/knowledge/index')return json({files,categories});if(path==='/api/market-research/discoveries')return json({discoveries:[]});if(path==='/api/ai/models')return json({models:[{id:'gpt-6-luna',name:'GPT-6-Luna'}],lastModel:'gpt-6-luna',selectionRequired:false});if(path.startsWith('/api/'))return json({});
 const absolute=resolve(root,'.'+(path==='/'?'/index.html':path));if(!absolute.startsWith(root+'/')){res.writeHead(403);return res.end();}
 try{let body=readFileSync(absolute);if(path==='/app.js')body=Buffer.from(body.toString()+'\nwindow.__refineTest={state,setView};');res.setHeader('Content-Type',({'.js':'text/javascript','.mjs':'text/javascript','.html':'text/html','.css':'text/css','.woff2':'font/woff2','.png':'image/png'})[extname(absolute)]||'application/octet-stream');res.end(body);}catch{res.writeHead(404);res.end();}
});
app.whenReady().then(async()=>{
 app.dock?.hide();await new Promise(resolve=>server.listen(0,'127.0.0.1',resolve));const window=new BrowserWindow({show:false,width:1500,height:1120,webPreferences:{offscreen:true,contextIsolation:true}}),errors=[];window.webContents.on('console-message',event=>{if(/Uncaught|ReferenceError|TypeError/.test(event.message||''))errors.push(event.message);});
 const evaluate=code=>window.webContents.executeJavaScript(code),frame=()=>evaluate('new Promise(resolve=>requestAnimationFrame(()=>requestAnimationFrame(resolve)))');const wait=async(code)=>{for(let n=0;n<100;n++){if(await evaluate(code))return;await new Promise(resolve=>setTimeout(resolve,40));}throw Error('Timeout '+code+' '+JSON.stringify(errors));};
 let phase='startup';try{
  await window.loadURL(`http://127.0.0.1:${server.address().port}/`);await wait('window.__refineTest?.state.navigationReady && __refineTest.state.aiModel');
  await evaluate(`__refineTest.setView('archive');for(const id of ['sample-1','sample-2'])document.querySelector('[data-flow-queue="refine"][data-id="'+id+'"]').click();__refineTest.setView('refine');`);await frame();
  assert.equal(await evaluate(`document.querySelector('#refine-knowledge-file').value`),'SKILL.md');
  assert.equal(await evaluate(`document.querySelector('#refine-recipe')`),null,'the requirement box replaces the separate recipe form');
  await evaluate(`localStorage.setItem('hanabiRefineRecipe',JSON.stringify({sectionCount:12,imitationCount:20,platform:'旧平台'}))`);
  const choose=(selector,value)=>evaluate(`(()=>{const field=document.querySelector(${JSON.stringify(selector)});field.value=${JSON.stringify(value)};field.dispatchEvent(new Event('change',{bubbles:true}));})()`);
  assert.equal(await evaluate(`document.querySelector('#refine-knowledge-destination').open`),false,'save target should start compact');
  assert.match(await evaluate(`document.querySelector('#refine-destination-summary').textContent`),/基础 Skill/);
  await evaluate(`document.querySelector('#refine-knowledge-destination > summary').click()`);
  phase='existing target';await choose('#refine-knowledge-category','writing');assert.equal(await evaluate(`document.querySelector('#refine-knowledge-file').value`),'references/method.md');assert.equal(await evaluate(`document.querySelector('#refine-knowledge-file').options.length`),1);
  phase='new target';await evaluate(`document.querySelector('input[name="refine-destination-mode"][value="create"]').click()`);assert.equal(await evaluate(`document.querySelector('#build-task').disabled`),true);
  await evaluate(`const title=document.querySelector('#refine-knowledge-title');title.value='剧情软广配方';title.dispatchEvent(new Event('input',{bubbles:true}));document.querySelector('#task-brief').value='学习软广植入。'`);assert.equal(await evaluate(`document.querySelector('#build-task').disabled`),false);
  await evaluate(`document.querySelector('#build-task').click()`);await wait(`document.querySelectorAll('[data-review-job]').length===2`);
  assert.deepEqual(posted[0].body.knowledgeDestination,{mode:'create',categoryId:'writing',title:'剧情软广配方'});
  assert.equal(posted[0].body.brief,'学习软广植入。');
  assert.equal(Object.hasOwn(posted[0].body,'refineRecipe'),false,'hidden legacy preferences must not accompany the current requirement');
  phase='review destination';await evaluate(`document.querySelector('[data-review-job="job-0"]').click()`);assert.match(await evaluate(`document.querySelector('#review-destination-summary').textContent`),/剧情软广配方/);
  await evaluate(`document.querySelector('#review-destination').open=true;document.querySelector('input[name="review-destination-mode"][value="update"]').click()`);assert.equal(await evaluate(`document.querySelector('#review-knowledge-file').value`),'references/method.md');
  await evaluate(`document.querySelector('#confirm-inflow').click()`);await wait(`__refineTest.state.analysisJobs.some(job=>job.mode==='commit')`);
  assert.deepEqual(posted.find(call=>call.path.endsWith('/approve')).body.knowledgeDestination,{mode:'update',categoryId:'writing',path:'references/method.md'});
  await wait(`__refineTest.state.reviewJobIds.size===0`);
  await evaluate(`document.querySelector('[data-review-job="job-1"]').click()`);assert.equal(await evaluate(`document.querySelector('#inflow-review-card').hidden`),false,'a previous commit must not hide the next review');
  phase='responsive layout';await evaluate(`document.querySelector('#refine-knowledge-destination > summary').click()`);const layouts=[];
  for(const width of [1500,900]){window.setContentSize(width,1120);await frame();const layout=await evaluate(`(()=>{const host=document.querySelector('#refine-knowledge-destination'),rect=host.getBoundingClientRect();return{width:innerWidth,compactHeight:rect.height,overflow:document.documentElement.scrollWidth-innerWidth,clipped:[...host.querySelectorAll('input,select')].filter(element=>element.getClientRects().length&&element.getBoundingClientRect().right>rect.right+1).length,color:getComputedStyle(document.querySelector('#build-task')).backgroundColor};})()`);assert.ok(layout.overflow<=1);assert.ok(layout.compactHeight<=64,'closed save target should fit in a compact row');assert.equal(layout.clipped,0);layouts.push(layout);if(process.env.HANABI_CAPTURE_UI){await evaluate(`document.querySelector('#refine-knowledge-destination').scrollIntoView({block:'center'})`);await frame();try{writeFileSync(join(out,'refine-'+width+'.png'),(await window.webContents.capturePage()).toPNG());}catch(error){console.log('Screenshot unavailable: '+error.message);}}}
  phase='reload';await new Promise(resolve=>{window.webContents.once('did-finish-load',resolve);window.webContents.reload();});await wait('window.__refineTest?.state.navigationReady');assert.equal(await evaluate('__refineTest.state.view'),'refine');assert.equal(await evaluate(`document.querySelector('#refine-knowledge-title').value`),'剧情软广配方');
  assert.deepEqual(errors,[]);console.log(JSON.stringify({ok:true,newTarget:posted[0].body.knowledgeDestination,confirmedTarget:posted[1].body.knowledgeDestination,layouts,screenshots:process.env.HANABI_CAPTURE_UI?[join(out,'refine-1500.png'),join(out,'refine-900.png')]:[],reviewAfterPreviousCommit:true,reload:true}));
  window.destroy();server.close();app.exit(0);
 }catch(error){console.error(phase,error.stack,JSON.stringify({errors,posted,jobs}));window.destroy();server.close();app.exit(1);}
});
