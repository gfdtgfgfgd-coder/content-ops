import test from 'node:test';import assert from 'node:assert/strict';
import {batchPreviewItems,normalizeBatchPreferences,previewPayload,previewChecks,previewRevision} from '../lib/preview-batch-model.mjs';
test('batch choices share the application inventory and separate productions from sources',()=>{
 const choices=batchPreviewItems({items:[{id:'a',title:'资料'},{id:'k',archiveSpace:'knowledge'}],jobs:[{id:'done',mode:'produce',status:'completed',result:'# 成品'},{id:'busy',mode:'produce',status:'analyzing'}]});
 assert.deepEqual(choices.map(item=>[item.id,item.previewSource]),[['job:done','production'],['a','archive']]);
});
test('an intentional empty selection survives; invalid platform settings are repaired',()=>{
 assert.deepEqual(normalizeBatchPreferences({selected:[],channel:'invalid',columns:8}).selected,[]);
 assert.equal(normalizeBatchPreferences({}).selected,null);assert.equal(normalizeBatchPreferences({channel:'feishu',columns:3}).channel,'feishu');
});
test('preview reflects a deliberate layout draft without changing the source',()=>{
 const item={id:'a',title:'原题',content:'原文',attachments:[{id:'image',mimeType:'image/png'},{id:'movie',mimeType:'video/mp4'}],mediaFrames:[{id:'frame'}]};
 const result=previewPayload(item,{a:{title:'改过的题',content:'改过的文',imageIds:['frame'],textEdited:true}});
 assert.equal(result.title,'改过的题');assert.deepEqual(result.images.map(image=>image.id),['frame']);assert.equal(result.video.id,'movie');assert.equal(item.title,'原题');
});
test('review marks depend on the actual content and media, and checks never invent assets',()=>{
 const item=previewPayload({id:'a',title:'题',content:'文',attachments:[]});
 assert.match(previewChecks(item,'xiaohongshu').join(),/没有图片/);assert.match(previewChecks(item,'bilibili').join(),/没有视频/);assert.deepEqual(previewChecks(item,'feishu'),[]);assert.deepEqual(previewChecks({...item,images:[{id:'picture'}]},'douyin'),[]);
 assert.notEqual(previewRevision(item),previewRevision({...item,content:'新的文'}));assert.notEqual(previewRevision(item),previewRevision({...item,images:[{id:'new'}]}));
});

test('internal archive metadata is not turned into public hashtags',()=>{
 const item=previewPayload({id:'a',title:'题',content:'文',tags:['主题:设计','平台:小红书','入炉样本','链接','合并资料','正常标签']});
 assert.deepEqual(item.tags,['设计','正常标签']);
});
