import test from 'node:test';
import assert from 'node:assert/strict';
import { mkdtemp, writeFile, rm } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { spawn } from 'node:child_process';
import { createServer } from 'node:net';
import { DatabaseSync } from 'node:sqlite';
import { CollectionRedirects } from '../lib/library-collections.mjs';
import { writeModelFixture, selectTestModel } from './model-catalog-fixture.mjs';

test('collection consolidation keeps merge undo and stale edits working; intake reuses broad categories and respects manual choices', { timeout: 30_000 }, async () => {
  const root = await mkdtemp(join(tmpdir(), 'hanabi-broad-collections-'));
  const probe = createServer(); await new Promise(resolve => probe.listen(0, '127.0.0.1', resolve));
  const port = probe.address().port; await new Promise(resolve => probe.close(resolve));
  const base = `http://127.0.0.1:${port}`, codex = join(root, 'codex.cjs');
  await writeModelFixture(root);
  await writeFile(codex, `#!${process.execPath}
let s='';process.stdin.on('data',x=>s+=x);process.stdin.on('end',async()=>{
 const jobId=s.match(/任务 ID：([^\\s]+)/)?.[1],base='http://127.0.0.1:'+process.env.CONTENT_ALCHEMY_PORT;
 const call=async(name,args)=>{const r=await fetch(base+'/mcp',{method:'POST',headers:{'Content-Type':'application/json',Origin:base},body:JSON.stringify({jsonrpc:'2.0',id:1,method:'tools/call',params:{name,arguments:args}})});const x=await r.json();if(x.error||x.result?.isError)throw Error(JSON.stringify(x));return x.result;};
 const payload=JSON.parse((await call('alchemy_get_analysis_job',{jobId})).content.find(x=>x.type==='text').text);
 if(!payload.furnaceProtocol.includes('上位'))throw Error('Missing broad classification protocol');
 await call('alchemy_save_library_item',{jobId,title:payload.item.title,content:payload.item.content,collectionPurpose:'content',collectionName:payload.item.title+'专用集合',collectionReason:'作为内容表达参考'});
 await call('alchemy_complete_analysis_job',{jobId,result:'正文已整理',candidateRules:[]});
});
`, { mode: 0o700 });
  const child = spawn(process.execPath, ['server.mjs'], { cwd: new URL('..', import.meta.url), env: { ...process.env, CODEX_HOME: root, CONTENT_ALCHEMY_DATA_DIR: join(root, 'data'), CONTENT_ALCHEMY_PORT: String(port), CONTENT_ALCHEMY_CODEX_BIN: codex }, stdio: ['ignore','ignore','pipe'] });
  let log = ''; child.stderr.on('data', data => log += data);
  const api = async (path, body, method = 'POST') => {
    const response = await fetch(base + path, body === undefined ? {} : { method, headers: { 'Content-Type':'application/json', Origin:base }, body:JSON.stringify(body) });
    assert.ok(response.ok, await response.clone().text()); return response.json();
  };
  try {
    for (let i=0;i<100;i++) { try { await api('/healthz'); break; } catch {} await new Promise(resolve=>setTimeout(resolve,50)); }
    const module = async (name, fields=[]) => (await api('/api/library-modules',{name,fields,views:['archive']})).modules[0];
    const layout = await module('版式'), voice = await module('口播',[{key:'note',label:'证据',type:'text'}]);
    const a = await api('/api/items',{title:'杂志版式',type:'text',content:'原始版式资料',moduleIds:[layout.id]});
    const b = await api('/api/items',{title:'演讲停顿',type:'text',content:'原始口播资料',moduleIds:[voice.id],moduleValues:{[voice.id]:{note:'保留停顿证据'}}});
    const merged = await api('/api/items/merge',{ids:[a.id,b.id]});
    assert.ok(merged);
    const db = new DatabaseSync(join(root,'data','library.sqlite'));
    new CollectionRedirects(db).consolidate([{id:layout.id,name:'内容创作',ids:[layout.id,voice.id],description:'创作参考'}]);
    db.close();
    const canonical = (await api('/api/library-modules')).modules[0];
    assert.equal(canonical.name,'内容创作'); assert.deepEqual(canonical.previousIds,[voice.id]);
    const undone = await api('/api/items/split',{ids:[a.id],mode:'undo'});
    assert.equal(undone.restoredCount,2);
    for (const item of undone.items) assert.deepEqual(item.moduleIds,[layout.id]);
    assert.equal(undone.items.find(item=>item.id===b.id).moduleValues[layout.id].note,'保留停顿证据');
    const stale = await api(`/api/items/${b.id}`,{...b,title:'更新后的标题'},'PUT');
    assert.deepEqual(stale.moduleIds,[layout.id]); assert.equal(stale.moduleValues[layout.id].note,'保留停顿证据');
    await selectTestModel(base);
    const ingest = async (title, moduleIds=[]) => {
      const item = await api('/api/items',{title,type:'text',content:'第一段完整内容。\n\n第二段完整内容。'});
      const job = (await api('/api/analysis-jobs',{itemIds:[item.id],mode:'intake',scope:['text'],moduleIds})).jobs[0];
      for(let i=0;i<120;i++) {
        const current=(await api('/api/analysis-jobs')).jobs.find(x=>x.id===job.id);
        if(['completed','failed','partial'].includes(current.status)) { assert.equal(current.status,'completed',JSON.stringify(current)+log); return api(`/api/items/${item.id}`); }
        await new Promise(resolve=>setTimeout(resolve,50));
      }
      throw Error('Intake did not complete: '+log);
    };
    for (const title of ['诗歌意象摘录','海报留白参考']) assert.deepEqual((await ingest(title)).moduleIds,[layout.id]);
    assert.equal((await api('/api/library-modules')).modules.length,1,'narrow proposals recreated collections');
    const custom = await module('我的手选集合');
    assert.deepEqual((await ingest('手选资料',[custom.id])).moduleIds,[custom.id]);
    assert.equal((await api('/api/library-modules')).modules.length,2);
  } finally {
    if(child.exitCode===null) { child.kill('SIGTERM'); await new Promise(resolve=>child.once('close',resolve)); }
    await rm(root,{recursive:true,force:true});
  }
});
