import { writeModelFixture, selectTestModel } from './model-catalog-fixture.mjs';
import test from "node:test";
import assert from "node:assert/strict";
import { mkdtemp, writeFile, readFile, rm } from "node:fs/promises";
import { existsSync } from "node:fs";
import { spawn } from "node:child_process";
import { createServer } from "node:net";
import { DatabaseSync } from "node:sqlite";
import { randomUUID } from "node:crypto";
import { join } from "node:path";
import { tmpdir } from "node:os";
import { frameTimes } from "../lib/visual-search.mjs";

test("a video collected as text + images expands, focuses, and saves only the matching later frame", { timeout: 25_000 }, async () => {
  const root = await mkdtemp(join(tmpdir(), "hanabi-adaptive-"));
  const probe = createServer(); await new Promise((resolve) => probe.listen(0, "127.0.0.1", resolve));
  const port = probe.address().port; await new Promise((resolve) => probe.close(resolve));
  const base = `http://127.0.0.1:${port}`;
  const png = Buffer.from("iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8/x8AAwMCAO+a9l8AAAAASUVORK5CYII=", "base64");
  const extractor = join(root, "extractor.cjs"), codex = join(root, "codex.cjs"), audit = join(root, "audit.json"), extractionCalls = join(root, "extraction-calls.txt");
  await writeFile(extractor, `#!${process.execPath}
const fs=require('node:fs'),path=require('node:path'),args=process.argv.slice(2),dir=args[1];
fs.appendFileSync(${JSON.stringify(extractionCalls)},'extract\\n');
if(!args.includes('--frames-only'))throw new Error('Expansion must only extract images');
fs.mkdirSync(dir,{recursive:true});
const times=args[args.indexOf('--times')+1].split(',').map(Number);
const frames=times.map((seconds,i)=>{const file=path.join(dir,'frame-'+i+'.jpg');fs.writeFileSync(file,Buffer.from(${JSON.stringify(png.toString("base64"))},'base64'));return {path:file,seconds};});
process.stdout.write(JSON.stringify({durationSeconds:20,hasAudio:true,frames,audioBytes:0,onScreenText:[],ocrSampleCount:0,ocrExpectedSampleCount:0}));
`, { mode: 0o700 });
  await writeFile(codex, `#!${process.execPath}
let prompt='';process.stdin.on('data',chunk=>prompt+=chunk);process.stdin.on('end',async()=>{try{
const jobId=prompt.match(/任务 ID：([^\\s]+)/)[1],base=${JSON.stringify(base)};
const raw=async(name,args)=>{const r=await fetch(base+'/mcp',{method:'POST',headers:{'Content-Type':'application/json',Origin:base},body:JSON.stringify({jsonrpc:'2.0',id:1,method:'tools/call',params:{name,arguments:args}})});return (await r.json()).result;};
const call=async(name,args)=>{const r=await raw(name,args);if(r.isError)throw new Error(r.content[0].text);return r;};
const read=result=>JSON.parse(result.content[0].text);
const payload=read(await call('alchemy_get_analysis_job',{jobId}));
const search=payload.sourceMedia.visualSearch,checked=[...search.review.overviewIds];
if(!search.required||search.frames.length!==6)throw new Error('Cross-duration overview is missing');
if(process.argv.filter(arg=>arg==='--image').length!==7)throw new Error('Native input lacks the six overview frames and cover');
if(payload.sourceMedia.video!==null||payload.sourceMedia.audio!==null)throw new Error('Unselected raw media was exposed as output');
const blockedSave=await raw('alchemy_save_library_item',{jobId,title:'premature',type:'image',content:'Only saw the cover'});
const blockedFinish=await raw('alchemy_complete_analysis_job',{jobId,result:'Only saw the cover'});
if(!blockedSave.isError||!blockedFinish.isError)throw new Error('Premature archive or completion was accepted');
const expandedResponse=await call('alchemy_review_visual_evidence',{jobId,decision:'not_found',reason:'概览尚未看到所需版式，继续查找后半段',reviewedFrameIds:checked});
const expanded=read(expandedResponse);
if(expanded.review.decision!=='searching'||!expanded.frames.length||!expandedResponse.content.some(block=>block.type==='image'))throw new Error('Initial no-match did not return more real images');
checked.push(...expanded.frames.map(frame=>frame.id));
const focus=read(await call('alchemy_review_visual_evidence',{jobId,decision:'need_more',reason:'13至14秒附近有目标文字，需要细看布局',reviewedFrameIds:checked,startSeconds:13,endSeconds:14}));
checked.push(...focus.frames.map(frame=>frame.id));
const target=[...search.frames,...expanded.frames,...focus.frames].find(frame=>frame.seconds>=13.3&&frame.seconds<=13.4);
if(!target||!target.localPath||!require('node:fs').existsSync(target.localPath))throw new Error('Focused target frame is missing');
await call('alchemy_review_visual_evidence',{jobId,decision:'sufficient',reason:'后段13.36秒展示了需要学习的文字布局',reviewedFrameIds:checked,selectedImageIds:[target.id]});
await call('alchemy_update_media_coverage',{jobId,mediaType:'video',visualsReviewed:true,fullDurationReviewed:false,audioPresent:true,audioReviewed:false,note:'只提炼符合需求的文字和画面，未连续观看视频或分析音频。'});
await call('alchemy_save_library_item',{jobId,title:'目标版式与文案',type:'image',content:'约13.36秒的版式与文案分析。'});
await call('alchemy_complete_analysis_job',{jobId,result:'约13.36秒的版式与文案分析。'});
require('node:fs').writeFileSync(${JSON.stringify(audit)},JSON.stringify({targetId:target.id,blockedSave:blockedSave.isError,blockedFinish:blockedFinish.isError,expanded:expanded.frames.length,focused:focus.frames.length}));
}catch(error){console.error(error.stack);process.exitCode=1;}});
`, { mode: 0o700 });
  await writeModelFixture(root);
  const child = spawn(process.execPath, ["server.mjs"], { cwd: new URL("..", import.meta.url), env: { ...process.env, CODEX_HOME: root, CONTENT_ALCHEMY_DATA_DIR: join(root, "data"), CONTENT_ALCHEMY_PORT: String(port), CONTENT_ALCHEMY_CODEX_BIN: codex, CONTENT_ALCHEMY_VIDEO_EXTRACTOR_BIN: extractor }, stdio: ["ignore", "pipe", "pipe"] });
  let log = ""; child.stderr.on("data", (chunk) => log += chunk);
  const api = async (path, options) => { const r = await fetch(base + path, options); assert.ok(r.ok, `${r.status}: ${await r.clone().text()}`); return r.json(); };
  let localDb;
  try {
    for (let i = 0; i < 50; i++) { try { await api("/healthz"); break; } catch { await new Promise((resolve) => setTimeout(resolve, 100)); } }
    await selectTestModel(base);
    const item = await api("/api/items", { method: "POST", headers: { "Content-Type": "application/json", Origin: base }, body: JSON.stringify({ title: "视频来源", type: "text", content: "原资料仍应保留到核对完成。" }) });
    localDb = new DatabaseSync(join(root, "data", "library.sqlite"));
    const video = { id: randomUUID(), name: "source.mp4", mimeType: "video/mp4", size: 16 };
    const cover = { id: randomUUID(), name: "cover.png", mimeType: "image/png", size: png.length };
    const ocr = { id: randomUUID(), name: "OCR.txt", mimeType: "text/plain", sourceType: "on-screen-text-ocr", sampleCount: 40, expectedSampleCount: 40 };
    const frames = frameTimes(20, 6).map((seconds) => ({ id: randomUUID(), name: `frame-${seconds}.jpg`, mimeType: "image/jpeg", seconds, sourceType: "video-frame" }));
    const uploads = join(root, "data", "uploads");
    await writeFile(join(uploads, video.id + ".mp4"), "cached-source-file"); await writeFile(join(uploads, cover.id + ".png"), png); await writeFile(join(uploads, ocr.id + ".txt"), "约13秒：目标文字布局");
    for (const frame of frames) await writeFile(join(uploads, frame.id + ".jpg"), png);
    const jobId = randomUUID(), timestamp = new Date().toISOString();
    const snapshot = { version: 1, prepared: true, acquisitionComplete: true, sourceUrl: "", scope: ["text", "image"], item: { ...localDb.prepare("SELECT * FROM items WHERE id=?").get(item.id), type: "video", content: "来源原文与用户希望学习的版式。", attachments: JSON.stringify([video, cover, ocr]), media_frames: JSON.stringify(frames) }, coverage: { mediaType: "video", readerReady: true, durationSeconds: 20, expectedImageCount: 1, imageCount: 1, onScreenTextReviewed: true, frameCount: 6 } };
    localDb.prepare("INSERT INTO analysis_jobs(id,item_id,mode,status,brief,analysis_scope,destinations,source_snapshot,created_at,updated_at) VALUES (?,?,'intake','completed','学习后半段版式和文案','[\"text\",\"image\"]','[\"archive\"]',?,?,?)").run(jobId, item.id, JSON.stringify(snapshot), timestamp, timestamp);
    const legacyJob = (await api("/api/analysis-jobs")).jobs.find((entry) => entry.id === jobId);
    assert.equal(legacyJob.needsVisualRecheck, true, "legacy completed jobs must expose a way to inspect later frames");
    await api(`/api/analysis-jobs/${jobId}/retry`, { method: "POST", headers: { Origin: base } });
    let job;
    for (let i = 0; i < 150; i++) { job = (await api("/api/analysis-jobs")).jobs.find((entry) => entry.id === jobId); if (["completed", "partial", "failed"].includes(job.status)) break; await new Promise((resolve) => setTimeout(resolve, 50)); }
    assert.equal(job.status, "completed", JSON.stringify({ job, log }));
    assert.equal(job.needsVisualRecheck, false, "a verified result must not be marked as a legacy one-frame result");
    for (let i = 0; i < 20 && !existsSync(audit); i++) await new Promise((resolve) => setTimeout(resolve, 25));
    const checks = JSON.parse(await readFile(audit, "utf8"));
    assert.ok(checks.blockedSave && checks.blockedFinish); assert.ok(checks.expanded > 6 && checks.focused > 0);
    assert.deepEqual(job.sourceRead.visualReview.rounds.map((round) => round.kind), ["expanded", "focused"]);
    const archive = await api(`/api/items/${item.id}`);
    assert.equal(archive.type, "image"); assert.equal(archive.mediaFrames.length, 1); assert.equal(archive.mediaFrames[0].id, checks.targetId);
    assert.equal(archive.attachments.some((file) => /^(image|video|audio)\//.test(file.mimeType)), false, "unselected cover or raw media leaked into archive");
    assert.equal((await fetch(base + `/api/uploads/${checks.targetId}`)).status, 200);
    const callsBeforeRetry = await readFile(extractionCalls, "utf8");
    await api(`/api/analysis-jobs/${jobId}/retry`, { method: "POST", headers: { Origin: base } });
    for (let i = 0; i < 150; i++) { job = (await api("/api/analysis-jobs")).jobs.find((entry) => entry.id === jobId); if (["completed", "partial", "failed"].includes(job.status)) break; await new Promise((resolve) => setTimeout(resolve, 50)); }
    assert.equal(job.status, "completed", JSON.stringify({ job, log }));
    assert.equal(await readFile(extractionCalls, "utf8"), callsBeforeRetry, "a retry re-extracted already cached evidence");
    let parentId = jobId;
    for (let round = 0; round < 2; round++) {
      const correction = await api(`/api/analysis-jobs/${parentId}/correct`, { method: "POST", headers: { "Content-Type": "application/json", Origin: base }, body: JSON.stringify({ correction: "继续核对后半段的版式和文案" }) });
      let revised;
      for (let i = 0; i < 150; i++) { revised = (await api("/api/analysis-jobs")).jobs.find((entry) => entry.id === correction.job.id); if (["completed", "partial", "failed"].includes(revised.status)) break; await new Promise((resolve) => setTimeout(resolve, 50)); }
      assert.equal(revised.status, "completed", JSON.stringify({ revised, log }));
      assert.equal(revised.parentMode, "intake", "nested corrections lost the intake archive boundary");
      assert.equal((await api("/api/state")).items.length, 1, "a correction created a duplicate archive instead of updating it");
      assert.equal((await api(`/api/items/${item.id}`)).mediaFrames.length, 1);
      parentId = revised.id;
    }
    assert.equal(await readFile(extractionCalls, "utf8"), callsBeforeRetry, "corrections did not reuse the source frame cache");
    await api("/api/analysis-jobs?stage=inflow", { method: "DELETE", headers: { Origin: base } });
    assert.equal(existsSync(join(uploads, video.id + ".mp4")), false);
    assert.equal(existsSync(join(uploads, frames[0].id + ".jpg")), false);
    assert.equal(existsSync(join(uploads, checks.targetId + ".jpg")), true);
  } finally {
    localDb?.close(); child.kill("SIGTERM"); if (child.exitCode === null) await new Promise((resolve) => child.once("close", resolve)); await rm(root, { recursive: true, force: true });
  }
});
