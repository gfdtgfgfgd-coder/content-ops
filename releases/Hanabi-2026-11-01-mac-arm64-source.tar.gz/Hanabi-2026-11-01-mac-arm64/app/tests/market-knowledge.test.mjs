import test from 'node:test';
import assert from 'node:assert/strict';
import {mkdtemp,mkdir,writeFile,readFile,rm} from 'node:fs/promises';
import {tmpdir} from 'node:os';
import {join} from 'node:path';
import {DatabaseSync} from 'node:sqlite';
import {modelFamilyForRecord,marketKnowledgeMetadata,knowledgeSections,knowledgeListFiles,MARKET_KNOWLEDGE_PREFIX,MODEL_FAMILIES} from '../lib/market-knowledge.mjs';
import {KnowledgeCatalog} from '../lib/knowledge-catalog.mjs';
import {restructureMarketKnowledge} from '../scripts/restructure-market-knowledge.mjs';
import {marketBaseline} from '../lib/market-research.mjs';

test('different model families split, cloud resale is never promoted to original-provider pricing',()=>{
 const family=(provider,subject,source_kind='original_provider')=>modelFamilyForRecord({provider,subject,source_kind})?.id;
 assert.equal(family('OpenAI','gpt-6-astra'),'gpt');assert.equal(family('OpenAI','gpt-image-2'),'gpt-image');
 assert.equal(family('Volcengine','doubao-seedance-2.5'),'seedance');assert.equal(family('Volcengine','doubao-seedream-5-0-pro'),'seedream');
 assert.equal(family('Google Vertex','Claude Opus 5','cloud_resale'),undefined);
 assert.equal(family('Kuaishou KAT','DeepSeek V3'),undefined);assert.equal(family('Kuaishou KAT','KAT-Coder-Pro-V2.5'),'kat');
 assert.equal(family('Alibaba','qwen-image-3.0'),'qwen-image');assert.equal(family('Alibaba','wan3.0-video'),'wan');
});
test('report baseline follows a site current-pricing pointer without embedding every price record',async()=>{
 const root=await mkdtemp(join(tmpdir(),'hanabi-site-pricing-')),base=join(root,'references/ai-market-research');
 try{
  await mkdir(base,{recursive:true});
  const currentPricing={observedAt:'2026-10-28',rules:'sites/makenow/references/pricing-rules-20261028.json',quotes:'sites/makenow/references/prices-20261028.json'};
  await writeFile(join(base,'catalog.json'),JSON.stringify({version:1,main:'SKILL.md',sites:[{id:'makenow',name:'MakeNow',path:'sites/makenow/SKILL.md',currentPricing}],models:[],confirmation:{}}));
  const baseline=await marketBaseline(root);
  assert.deepEqual(baseline.skillCatalogue.sites[0].currentPricing,currentPricing);
  currentPricing.rules='sites/makenow/references/pricing-rules-new.json';
  await writeFile(join(base,'catalog.json'),JSON.stringify({version:1,main:'SKILL.md',sites:[{id:'makenow',name:'MakeNow',path:'sites/makenow/SKILL.md',currentPricing}],models:[],confirmation:{}}));
  assert.equal((await marketBaseline(root)).skillCatalogue.sites[0].currentPricing.rules,currentPricing.rules);
 }finally{await rm(root,{recursive:true,force:true});}
});
test('knowledge browsing groups Skills first without losing archive files or search/selection targets',()=>{
 const paths=['SKILL.md',MARKET_KNOWLEDGE_PREFIX+'SKILL.md',MARKET_KNOWLEDGE_PREFIX+'sites/c-api/SKILL.md',MARKET_KNOWLEDGE_PREFIX+'models/gpt/SKILL.md',MARKET_KNOWLEDGE_PREFIX+'references/official/OpenAI.json'];
 const files=paths.map(path=>({path,filename:path.split('/').at(-1),category:'官方价目',...marketKnowledgeMetadata(path)}));
 const sections=knowledgeSections(files),listed=sections.flatMap(s=>s.files.map(f=>f.path));
 assert.equal(new Set(listed).size,files.length);assert.deepEqual(new Set(listed),new Set(paths));
 assert.equal(sections[0].id,'main');assert.equal(sections.find(s=>s.id.startsWith('models')).collapsed,true);
 assert.ok(sections.at(-1).collapsed);
});
test('model Skills use only the five requested groups and retain every family exactly once',()=>{
 const files=MODEL_FAMILIES.map(f=>({path:MARKET_KNOWLEDGE_PREFIX+f.path,filename:'SKILL.md',...marketKnowledgeMetadata(MARKET_KNOWLEDGE_PREFIX+f.path)}));
 const groups=knowledgeSections(files);
 assert.deepEqual(groups.map(g=>g.title),['文本','图像','视频','语音','其它'].map(g=>'模型官方价格 · '+g));
 assert.equal(new Set(groups.flatMap(g=>g.files.map(f=>f.familyId))).size,MODEL_FAMILIES.length);
 assert.equal(marketKnowledgeMetadata(MARKET_KNOWLEDGE_PREFIX+'models/hunyuan3d/SKILL.md').skillGroup,'其它');
});
test('editing uses the same archive entries as browsing and cached search cannot undo a manual move',()=>{
 const main={path:'SKILL.md',filename:'SKILL.md',name:'基础 Skill',categoryId:'workflow'};
 const model={path:MARKET_KNOWLEDGE_PREFIX+'models/gpt/SKILL.md',filename:'SKILL.md',name:'GPT 官方价格',categoryId:'market-models',...marketKnowledgeMetadata(MARKET_KNOWLEDGE_PREFIX+'models/gpt/SKILL.md')};
 const evidence={path:MARKET_KNOWLEDGE_PREFIX+'references/price-checks/old.json',filename:'old.json',name:'内部价格核算',categoryId:'market-data',...marketKnowledgeMetadata(MARKET_KNOWLEDGE_PREFIX+'references/price-checks/old.json')};
 const files=[main,model,evidence],visible=knowledgeListFiles(files);
 assert.deepEqual(visible.map(f=>f.path),[main.path,model.path]);
 assert.deepEqual(knowledgeSections(visible).flatMap(section=>section.files).map(f=>f.path),[main.path,model.path]);
 const categories=[{id:'market'},{id:'market-models',parentId:'market'},{id:'my-methods',parentId:'creation'},{id:'creation'}];
 const moved={...model,categoryId:'my-methods',categoryAssigned:true};
 const hits=[{...model,snippet:'旧搜索命中'},evidence];
 assert.deepEqual(knowledgeListFiles([main,moved,evidence],{query:'价格',matches:hits,categoryId:'creation',categories}).map(f=>f.path),[model.path]);
 assert.deepEqual(knowledgeListFiles([main,moved],{query:'价格',matches:hits,categoryId:'market',categories}),[]);
 assert.equal(knowledgeListFiles([main,moved],{query:'价格',matches:hits})[0].categoryId,'my-methods');
 assert.equal(knowledgeListFiles([main,moved],{query:'价格',matches:hits}).length,1,'a removed file cannot reappear from cached results');
 const explicitlyFiled={...evidence,categoryAssigned:true,categoryId:'my-methods'};
 assert.ok(knowledgeListFiles([explicitlyFiled]).length);
 assert.equal(knowledgeSections([explicitlyFiled])[0].id,'other','an explicitly filed document stays visible after leaving search');
});
test('migration preserves every quote and source, can rerun safely, and report baseline reads the new hierarchy',async()=>{
 const root=await mkdtemp(join(tmpdir(),'hanabi-market-knowledge-')),base=join(root,'references/ai-market-research');
 await mkdir(join(base,'references/official'),{recursive:true});
 const records=[
  {id:'price1',provider:'OpenAI',subject:'gpt-6-astra',source_kind:'original_provider',observed_at:'2026-10-21',source_url:'https://example.com/pricing',specification:{mode:'standard'},unit_text:'1M tokens',price_fields:[{label:'Input',value:'$10',amounts:[{native_amount:'10',native_currency:'USD',cny_reference:'67.192',usd_reference:'10'}]}]},
  {id:'price2',provider:'OpenAI',subject:'gpt-image-2',source_kind:'original_provider',observed_at:'2026-10-21',source_url:'https://example.com/pricing',price_fields:[{label:'Output',value:'$30'}]},
  {id:'price3',provider:'Google Vertex',subject:'Claude',source_kind:'cloud_resale',observed_at:'2026-10-21',source_url:'https://example.com/resale',price_fields:[{label:'Input',value:'$5'}]},
 ];
 await writeFile(join(base,'SKILL.md'),'# 原主 Skill\n用户规则');
 await writeFile(join(base,'references/official/OpenAI.json'),JSON.stringify({observed_at:'2026-10-21',records}));
 await writeFile(join(base,'references/十月嵌入表格.json'),JSON.stringify([{id:'T01',rows:[['模型ID','其他站人民币价','多元探索C端人民币价'],['gpt-6','¥1','¥2 /百万Token']]}]));
 await writeFile(join(base,'references/MakeNow现用站快照.json'),'{}');
 await writeFile(join(base,'references/比价口径.md'),'# 口径');
 const original=await readFile(join(base,'references/official/OpenAI.json'),'utf8');let db;
 try{
  const result=await restructureMarketKnowledge({knowledgeRoot:root,backupRoot:join(root,'backups'),codexMultiplier:2});
  assert.match(await readFile(join(base,'sites/c-api/references/historical-prices.md'),'utf8'),/¥2 \/百万Token/);
  assert.match(await readFile(join(base,'sites/c-api/SKILL.md'),'utf8'),/完整历史报价/);
  assert.equal(result.originalRecords,3);assert.equal(result.familyRecords,2);assert.equal(result.supportingRecords,1);
  assert.equal(await readFile(join(root,'backups/ai-market-research/SKILL.md'),'utf8'),'# 原主 Skill\n用户规则');
  assert.equal(await readFile(join(base,'references/official/OpenAI.json'),'utf8'),original);
  const model=JSON.parse(await readFile(join(base,'models/gpt/references/prices.json'),'utf8'));
  assert.equal(model.records[0].observed_at,'2026-10-21');assert.deepEqual(model.records[0].price_fields,records[0].price_fields);
  await writeFile(join(base,'sites/c-api/SKILL.md'),'# 用户后续修改');
  const again=await restructureMarketKnowledge({knowledgeRoot:root});assert.equal(again.alreadyApplied,true);
  assert.equal(await readFile(join(base,'sites/c-api/SKILL.md'),'utf8'),'# 用户后续修改');
  const baseline=await marketBaseline(root);assert.equal(baseline.skillCatalogue.sites.length,6);assert.equal(baseline.skillCatalogue.models.length,2);
  assert.equal(baseline.skillCatalogue.confirmations.bApiCnyPerCredit,1);assert.equal(baseline.skillCatalogue.confirmations.codexMultiplier,1);
  assert.equal(baseline.skillCatalogue.confirmations.mirrorDiscountIncludesConsumptionMultiplier,true);assert.equal(baseline.skillCatalogue.confirmations.mirrorStoreOverridesTutorial,true);
  assert.ok(baseline.documents.some(d=>d.path==='references/model-skills.md'));assert.ok(baseline.documents.some(d=>d.path==='sites/mirror/SKILL.md'));
  assert.ok(!baseline.documents.some(d=>d.path==='references/渠道与产品.md'));
  db=new DatabaseSync(':memory:');const catalog=new KnowledgeCatalog(db,root),files=await catalog.files();
  assert.equal(files.find(f=>f.path===MARKET_KNOWLEDGE_PREFIX+'SKILL.md').categoryId,'market-main');
  assert.equal(files.find(f=>f.path===MARKET_KNOWLEDGE_PREFIX+'models/gpt/SKILL.md').skillKind,'model');
  const artifact=await catalog.saveArtifact({jobId:'11111111-1111-1111-1111-111111111111',role:'competitor',title:'C 端新价',content:'# C 端新价\n实际来源报价',sourceUrl:'https://duoyuanx.com/pricing'});
  assert.match(artifact.path,/sites\/c-api\/references\/updates\//);assert.equal(artifact.categoryId,'market-sites');
  assert.match(await readFile(join(base,'sites/c-api/references/updates.md'),'utf8'),/C 端新价/);
  assert.match(await readFile(join(base,'sites/c-api/SKILL.md'),'utf8'),/用户后续修改/);
  assert.match(await readFile(join(base,'sites/c-api/SKILL.md'),'utf8'),/references\/updates.md/);

 }finally{db?.close();await rm(root,{recursive:true,force:true});}
});
