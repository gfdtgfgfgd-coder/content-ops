// Offline visual regression: real markup/styles/render functions, synthetic data.
// No running Hanabi service, browser profile or personal database is accessed.
const { app, BrowserWindow } = require("electron");
const { readFileSync, writeFileSync, mkdtempSync, mkdirSync } = require("node:fs");
const { join, resolve } = require("node:path");
const { tmpdir } = require("node:os");
const { pathToFileURL } = require("node:url");
const assert = require("node:assert/strict");
app.disableHardwareAcceleration();

const root = resolve(__dirname, "..");
const output = mkdtempSync(join(tmpdir(), "hanabi-collection-layout-"));
for (const key of ["userData", "sessionData", "logs"]) {
  const path = join(output, key); mkdirSync(path); app.setPath(key, path);
}
const source = readFileSync(join(root, "app.js"), "utf8");
const functionSource = (name, next) => {
  const start = source.search(new RegExp(`(?:^|\\n)(?:async )?function ${name}\\(`)), end = source.search(new RegExp(`(?:^|\\n)(?:async )?function ${next}\\(`));
  assert.ok(start >= 0 && end > start, `Cannot locate renderer ${name}`);
  return source.slice(start, end);
};
const renderer = [
  readFileSync(join(root, "lib", "workbench-presenter.mjs"), "utf8").replace(/^import .*;\n/m, "").replaceAll("export ", ""),
  readFileSync(join(root, "lib", "dialog-dismiss.mjs"), "utf8").replaceAll("export function", "function"),
  readFileSync(join(root, "lib", "collection-presentation.mjs"), "utf8").replace("export function", "function"),
  functionSource("escapeHtml", "safeHttpUrl"),
  functionSource("renderModuleBar", "openCollectionCreateDialog"),
  functionSource("renderArchiveFilters", "updateCollectionBulkToolbar"),
  functionSource("updateCollectionBulkToolbar", "persistFlowQueues"),
  functionSource("renderItemModuleBadges", "renderItemModules"),
  functionSource("openCollectionRenameDialog", "submitCollectionRename"),
  functionSource("submitCollectionRename", "modulesForType"),
  functionSource("renderDetailAttachments", "renderDetailNewFiles"),
  functionSource("detailFramesStillVisible", "currentDetailFrameItem"),
  functionSource("renderDetailMediaFrames", "openDetailFrameViewer"),
  functionSource("renderAnalysisJobs", "renderCard"),
].join("\n");
const clickHandler = source.slice(source.indexOf('document.addEventListener("click", async (event) => {'), source.indexOf('document.addEventListener("input", (event) => {'));
assert.ok(clickHandler.startsWith('document.addEventListener("click",'));
let html = readFileSync(join(root, "index.html"), "utf8")
  .replace(/<script\b[^>]*>[\s\S]*?<\/script>/g, "")
  .replace(/(href|src)="\/([^\"]*)"/g, (_, attr, path) => `${attr}="${pathToFileURL(join(root, path.split("?")[0])).href}"`);
writeFileSync(join(output, "fixture.html"), html);

app.whenReady().then(async () => {
  app.dock?.hide();
  const window = new BrowserWindow({ show: false, width: 1600, height: 900, webPreferences: { offscreen: true, contextIsolation: true } });
  try {
    await window.loadFile(join(output, "fixture.html"));
    await window.webContents.executeJavaScript(`
      window.$ = (selector) => document.querySelector(selector);
      window.$$ = (selector,host=document) => [...host.querySelectorAll(selector)];
      window.renderWorkbenchHome=()=>{};window.renderMarketDiscoveries=()=>{};
      window.state = {
        libraryModules: [{id:'shopping',name:'shoppinglist'}, {id:'style',name:'风格'}, {id:'created-1',name:'新建集合'}, {id:'created-2',name:'视频剪辑'}, {id:'created-3',name:'灵感参考'}],
        activeModuleId:'',activeMediaFilter:'all',platformFilter:'',topicFilter:'',librarySelected:new Set(),librarySelectionMode:false,libraryBulkAction:'',workJobFilter:'all',expandedJobs:new Map(),expandedJobDetails:new Map(),
        items: Array.from({length:125},(_,index)=>({id:String(index),moduleIds:[index%2?'style':'shopping'],facets:['text',index%2?'image':'video','audio']}))
      };
      window.isPendingInflowLink=()=>false;window.archivedLibraryItems=items=>items;
      window.mediaFacetValues=(item)=>item.facets;
      window.platformValues=()=>[]; window.topicValues=()=>[];
      window.mediaFilterOrder=['text','image','video','audio'];
      window.mediaFacetLabels={text:'文字',image:'图片',video:'视频',audio:'音频'};
      window.collectionRenameSaving=false;
      ${renderer}
      document.querySelectorAll('.view-panel').forEach(panel=>{panel.hidden=true;panel.classList.remove('active');});
      $('#view-collection').hidden=false;$('#view-collection').classList.add('active');
      renderModuleBar(); renderArchiveFilters();
      window.renderModuleBar=renderModuleBar;
      window.renderCollection=()=>{renderModuleBar();updateCollectionBulkToolbar(state.items);};
      ${clickHandler}
      window.renameCalls=[];
      window.api=async(path,options)=>{
        const id=decodeURIComponent(path.split('/').at(-1)),name=JSON.parse(options.body).name;
        renameCalls.push({id,name});
        if(state.libraryModules.some(module=>module.id!==id&&module.name.toLowerCase()===name.toLowerCase()))throw new Error('已有同名集合，请换一个名称。');
        const module=state.libraryModules.find(module=>module.id===id);
        return {module:{...module,name,tone:collectionTone(module)},updatedItemTags:[]};
      };
      window.renderCurrentView=()=>renderModuleBar();window.showToast=(message)=>{window.lastToast=message;};
      $('#collection-rename-form').addEventListener('submit',submitCollectionRename);
      $('#collection-rename-name').addEventListener('input',event=>{event.target.setCustomValidity('');$('#collection-rename-error').hidden=true;});
      window.collectionAppearance=()=>Object.fromEntries([...document.querySelectorAll('.module-tab')].map(button=>[button.dataset.moduleFilter,{color:getComputedStyle(button).color,background:getComputedStyle(button).backgroundColor,tone:button.dataset.collectionTone}]));
      window.renderBadges=()=>renderItemModuleBadges({moduleIds:state.libraryModules.map(module=>module.id)});
      true;
    `);
    const baseline = await window.webContents.executeJavaScript("collectionAppearance()");
    for (const theme of ["light", "dark"]) {
      await window.webContents.executeJavaScript(`document.documentElement.classList.toggle('dark-theme',${theme === "dark"});state.activeModuleId='';renderModuleBar();`);
      const before = await window.webContents.executeJavaScript("collectionAppearance()");
      for (const id of Object.keys(before)) {
        const after = await window.webContents.executeJavaScript(`document.querySelector('[data-module-filter="${id}"]').click();({appearance:collectionAppearance()[${JSON.stringify(id)}],pressed:document.querySelector('[data-module-filter="${id}"]').getAttribute('aria-pressed'),ring:getComputedStyle(document.querySelector('[data-module-filter="${id}"]')).boxShadow})`);
        assert.deepEqual(after.appearance, before[id], `${theme}: selection changed ${id}'s colors`);
        assert.equal(after.pressed, "true"); assert.notEqual(after.ring, "none");
      }
      const reordered = await window.webContents.executeJavaScript("state.libraryModules.reverse();renderModuleBar();collectionAppearance()");
      assert.deepEqual(reordered, before, `${theme}: reordering changed collection colors`);
    }
    await window.webContents.executeJavaScript("document.documentElement.classList.remove('dark-theme');state.activeModuleId='style';renderModuleBar();");
    const renameUi = await window.webContents.executeJavaScript(`(async()=>{
      document.querySelector('[data-module-filter=""]').click();
      const unavailableOnAll=$('#collection-rename-action').disabled;
      $('#collection-rename-action').click();
      const allNotRenamed=!$('#collection-rename-dialog').open;
      document.querySelector('[data-module-filter="style"]').click();
      const menuMoved=$('#collection-bulk-menu > summary').textContent.trim()==='编辑'&&!document.querySelector('.module-rename,[data-rename-module]')&&!$('#collection-rename-action').disabled;
      const openRename=()=>{$('#collection-bulk-menu > summary').click();$('#collection-rename-action').click();};
      const before={name:state.libraryModules.find(module=>module.id==='style').name,appearance:collectionAppearance().style,count:state.items.length};
      openRename();
      const opened=$('#collection-rename-dialog').open&&$('#collection-rename-name').value==='风格'&&!$('#collection-bulk-menu').open;
      $('#collection-rename-name').value='取消后的名字';
      document.querySelector('#collection-rename-dialog [data-close]').click();
      const cancelled=renameCalls.length===0&&state.libraryModules.find(module=>module.id==='style').name===before.name;
      openRename();
      $('#collection-rename-name').value='shoppinglist';$('#collection-rename-form').requestSubmit();
      await new Promise(resolve=>setTimeout(resolve,20));
      const duplicate=$('#collection-rename-dialog').open&&!$('#collection-rename-error').hidden&&$('#collection-rename-error').textContent.includes('同名')&&state.libraryModules.find(module=>module.id==='style').name===before.name;
      $('#collection-rename-name').value='设计参考';$('#collection-rename-name').dispatchEvent(new Event('input'));$('#collection-rename-form').requestSubmit();
      await new Promise(resolve=>setTimeout(resolve,20));
      const saved=!$('#collection-rename-dialog').open&&state.libraryModules.find(module=>module.id==='style').name==='设计参考'&&state.activeModuleId==='style'&&state.items.length===before.count;
      const after=collectionAppearance().style;
      openRename();$('#collection-rename-name').value='风格';$('#collection-rename-form').requestSubmit();
      await new Promise(resolve=>setTimeout(resolve,20));
      const batchActions=['delete','merge','split'].map(action=>{
        $('#collection-bulk-menu > summary').click();
        document.querySelector('[data-library-bulk-action="'+action+'"]').click();
        const entered=state.librarySelectionMode&&state.libraryBulkAction===action&&!$('#collection-bulk-menu').open&&!$('#collection-bulk-toolbar').hidden;
        $('#collection-selection-cancel').click();
        return entered&&!state.librarySelectionMode&&$('#collection-bulk-toolbar').hidden;
      }).every(Boolean);
      return {unavailableOnAll,allNotRenamed,menuMoved,batchActions,opened,cancelled,duplicate,saved,before:before.appearance,after};
    })()`);
    for (const key of ["unavailableOnAll", "allNotRenamed", "menuMoved", "batchActions", "opened", "cancelled", "duplicate", "saved"]) assert.equal(renameUi[key], true, `rename UI failed: ${key}`);
    assert.deepEqual(renameUi.after, renameUi.before, "renaming changed the collection color");
    const layouts = [];
    for (const width of [1600, 1280, 1024, 768, 390]) {
      window.setContentSize(width, 900);
      await new Promise((resolve) => setTimeout(resolve, 120));
      const layout = await window.webContents.executeJavaScript(`(()=>{const filters=[...document.querySelectorAll('.archive-filter')],host=$('#archive-media-filters');return {width:innerWidth,tops:filters.map(button=>Math.round(button.getBoundingClientRect().top)),count:filters.length,labels:filters.map(button=>button.querySelector('.archive-filter-label').textContent),pageOverflow:document.documentElement.scrollWidth-innerWidth,scrolls:host.scrollWidth>host.clientWidth+1,clipped:filters.filter(button=>button.querySelector('.archive-filter-count').getBoundingClientRect().right>button.getBoundingClientRect().right-1).length};})()`);
      assert.equal(layout.count, 5);
      assert.deepEqual(layout.labels, ["全部", "文字", "图片", "视频", "音频"]);
      assert.equal(new Set(layout.tops).size, 1, `filters wrapped at ${width}px`);
      assert.ok(layout.pageOverflow <= 1, `page overflows at ${width}px`);
      assert.equal(layout.clipped, 0, `filter content clips at ${width}px`);
      if (width >= 1024) assert.equal(layout.scrolls, false, `desktop filters require scrolling at ${width}px`);
      if ([1280, 390].includes(width)) writeFileSync(join(output, `${width}.png`), (await window.webContents.capturePage()).toPNG());
      if (width === 1280) {
        await window.webContents.executeJavaScript("$('#collection-bulk-menu > summary').click();");
        writeFileSync(join(output, "edit-menu.png"), (await window.webContents.capturePage()).toPNG());
        await window.webContents.executeJavaScript("$('#collection-bulk-menu > summary').click();");
      }
      layouts.push(layout);
    }
    const mediaUi = await window.webContents.executeJavaScript(`(()=>{try{
      state.detailEditing=false;state.detailAttachmentUndo=[];
      state.detailFrameChanges={itemId:'map-fixture',removedFrameIds:[]};
      window.updateDetailFrameSaveButtons=()=>{};
      window.openDetailFrameViewer=id=>{window.openedFrameId=id;};
      const item={id:'map-fixture',attachments:[{id:'cover',name:'封面.webp',mimeType:'image/webp'}],mediaFrames:Array.from({length:5},(_,index)=>({id:'later-'+index,name:'后续画面-'+index+'.jpg',mimeType:'image/jpeg'}))};
      renderDetailAttachments(item);
      $('#detail-dialog').showModal();
      const gallery=$('.detail-media-frames');
      const count=gallery.querySelectorAll('figure').length;
      const visible=gallery.getBoundingClientRect().height>0;
      document.querySelector('[data-open-detail-frame="later-4"]').click();
      const opensLater=openedFrameId==='later-4';
      $('#detail-dialog').close();
      state.view='inflow';state.correctionDrafts={};state.analysisJobs=[{id:'legacy-map',mode:'intake',status:'completed',scope:['text','image'],destinations:['archive'],needsVisualRecheck:true,sourceRead:{status:'ready'},uiChanges:[]}];
      window.queueFor=()=>new Set();window.inflowDestinationLabels={archive:'资料库'};
      window.inflowScopeOptions=[['text','文字'],['image','图片'],['video','视频'],['audio','音频']];
      renderAnalysisJobs();
      const legacyRetry=document.querySelector('[data-retry-job="legacy-map"]')?.textContent==='按需求补看视频画面';
      state.analysisJobs[0].needsVisualRecheck=false;renderAnalysisJobs();
      const verifiedNoRetry=!document.querySelector('[data-retry-job="legacy-map"]');
      return {count,visible,opensLater,legacyRetry,verifiedNoRetry};
      }catch(error){return {error:error.stack};}
    })()`);
    assert.ok(!mediaUi.error,mediaUi.error);
    assert.equal(mediaUi.count,5,"later frames must render below the cover in the detail dialog");
    for(const key of ['visible','opensLater','legacyRetry','verifiedNoRetry'])assert.equal(mediaUi[key],true,`media UI failed: ${key}`);
    assert.ok(Object.values(baseline).every((value) => value.color && value.background));
    console.log(JSON.stringify({ ok: true, collectionStates: 12, themes: 2, renameUi, layouts, mediaUi, screenshots: [join(output, "1280.png"), join(output, "390.png"), join(output, "edit-menu.png")] }));
    window.destroy(); app.exit(0);
  } catch (error) {
    console.error(error.stack); window.destroy(); app.exit(1);
  }
});
