import test from 'node:test';
import assert from 'node:assert/strict';
import {navigationSessionKey,readReloadNavigation,saveReloadNavigation,normalizeNavigationSession} from '../lib/navigation-session.mjs';
const storage=()=>{const values=new Map();return {getItem:key=>values.get(key),setItem:(key,value)=>values.set(key,value),removeItem:key=>values.delete(key)};};
test('only a reload resumes browsing; opening or restarting starts at the workbench',()=>{
 for(const type of ['navigate','back_forward',undefined]){
  const session=storage();saveReloadNavigation(session,{version:1,view:'archive',y:780});
  assert.equal(readReloadNavigation(session,type),null);
  assert.equal(session.getItem(navigationSessionKey),undefined);
 }
});
test('reload preserves page, filters, expanded tasks and nested reading positions',()=>{
 const session=storage();saveReloadNavigation(session,{version:1,view:'knowledge',y:330,knowledgeCategory:'workflow-main',knowledgeSearch:'偏好',currentKnowledgePath:'preferences.md',scrolls:[{id:'knowledge-reader',x:0,y:780}],expandedJobs:[['one',true]],details:[{id:'preview-style-settings',open:true}]});
 const value=readReloadNavigation(session,'reload');
 assert.equal(value.view,'knowledge');assert.equal(value.y,330);assert.equal(value.knowledgeSearch,'偏好');assert.equal(value.knowledgeCategory,'workflow-main');
 assert.equal(value.currentKnowledgePath,'preferences.md');assert.deepEqual(value.scrolls,[{id:'knowledge-reader',x:0,y:780}]);assert.deepEqual(value.expandedJobs,[['one',true]]);
 assert.equal(readReloadNavigation(session,'reload'),null);
});
test('broken or unavailable session storage does not block opening',()=>{
 const session=storage();session.setItem(navigationSessionKey,'{broken');assert.equal(readReloadNavigation(session,'reload'),null);
 const blocked={getItem(){throw Error('disabled');},setItem(){throw Error('disabled');}};
 assert.equal(readReloadNavigation(blocked,'reload'),null);assert.doesNotThrow(()=>saveReloadNavigation(blocked,{version:1,view:'home'}));
 assert.equal(normalizeNavigationSession({version:1,view:'unknown'}),null);
 const value=normalizeNavigationSession({version:1,view:'archive',y:-3,evil:'ignored',items:['do not restore domain data'],expandedJobs:[[null,3]],scrolls:[{id:'knowledge-reader',y:Infinity}]});
 assert.equal(value.y,0);assert.equal(value.evil,undefined);assert.equal(value.items,undefined);assert.deepEqual(value.expandedJobs,[]);assert.equal(value.scrolls[0].y,0);
});
