import test from 'node:test';
import assert from 'node:assert/strict';
import {applyContentReset} from '../lib/content-reset.mjs';
function storage(initial) {
  const map = new Map(Object.entries(initial));
  return {get length(){return map.size;},key:index=>[...map.keys()][index],getItem:key=>map.get(key)??null,setItem:(key,value)=>map.set(key,value),removeItem:key=>map.delete(key)};
}
test('清空内容会失效所有旧草稿、选择和预览；保留外观设置，不重复清除新内容',()=>{
  const local=storage({alchemyInflowReview:'旧正文',hanabiPreviewPresentationsV1:'旧排版',contentAlchemyTheme:'light','hanabi.rail-collapsed':'true'}),session=storage({'hanabi.chat-draft':'旧草稿','hanabi.chat-current':'old-id'});
  assert.equal(applyContentReset(local,session,''),false);
  assert.equal(applyContentReset(local,session,'reset-1'),true);
  assert.equal(local.getItem('alchemyInflowReview'),null);assert.equal(local.getItem('hanabiPreviewPresentationsV1'),null);
  assert.equal(local.getItem('contentAlchemyTheme'),'light');assert.equal(local.getItem('hanabi.rail-collapsed'),'true');
  assert.equal(session.getItem('hanabi.chat-draft'),null);assert.equal(session.getItem('hanabi.chat-current'),null);
  session.setItem('hanabi.chat-draft','新草稿');assert.equal(applyContentReset(local,session,'reset-1'),false);assert.equal(session.getItem('hanabi.chat-draft'),'新草稿');
  const anotherTab=storage({'hanabi.chat-draft':'另一个标签的旧草稿'});assert.equal(applyContentReset(local,anotherTab,'reset-1'),true);assert.equal(anotherTab.getItem('hanabi.chat-draft'),null);
});
