import test from 'node:test';
import assert from 'node:assert/strict';
import { mkdtemp,mkdir,writeFile,readFile,rm } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import { join,dirname } from 'node:path';
import { spawn } from 'node:child_process';
import { createServer } from 'node:net';
import { DatabaseSync } from 'node:sqlite';
import { KnowledgeCatalog } from '../lib/knowledge-catalog.mjs';
import { LEGACY_KNOWLEDGE_CATEGORIES } from '../lib/knowledge-taxonomy.mjs';

test('category deletion API relocates documents and children, preserves Skills and evidence, and survives restart', {timeout:20_000}, async()=>{
  const root=await mkdtemp(join(tmpdir(),'hanabi-delete-api-')),data=join(root,'data'),knowledge=join(data,'knowledge/ai-content-alchemy');
  const contents={'SKILL.md':'# 用户基础 Skill\n\n[规则](one.md)','one.md':'# 用户规则一','two.md':'# 用户规则二','references/ai-market-research/references/official/price.json':'[{"price":"1.25"}]'};
  for(const[path,content]of Object.entries(contents)){await mkdir(dirname(join(knowledge,path)),{recursive:true});await writeFile(join(knowledge,path),content);}
  const legacyDb=new DatabaseSync(join(data,'library.sqlite'));new KnowledgeCatalog(legacyDb,knowledge);
  for(const c of LEGACY_KNOWLEDGE_CATEGORIES)legacyDb.prepare('INSERT INTO knowledge_categories(id,name,parent_id) VALUES(?,?,?)').run(c.id,c.name,c.parentId);
  legacyDb.prepare("DELETE FROM knowledge_catalog_meta WHERE key='taxonomy-v2'").run();
  legacyDb.prepare('INSERT INTO knowledge_file_categories(path,category_id,manual) VALUES(?,?,0)').run('references/ai-market-research/references/official/price.json','market-official');legacyDb.close();
  const probe=createServer();await new Promise(resolve=>probe.listen(0,'127.0.0.1',resolve));const port=probe.address().port;await new Promise(resolve=>probe.close(resolve));
  const base=`http://127.0.0.1:${port}`;let child,log='';
  async function start(){
    child=spawn(process.execPath,['server.mjs'],{cwd:new URL('..',import.meta.url),env:{...process.env,CONTENT_ALCHEMY_DATA_DIR:data,CONTENT_ALCHEMY_PORT:String(port)},stdio:['ignore','ignore','pipe']});
    child.stderr.on('data',bytes=>log+=bytes);
    for(let i=0;i<100;i++){try{if((await fetch(base+'/healthz')).ok)return;}catch{}if(child.exitCode!==null)throw Error(log);await new Promise(resolve=>setTimeout(resolve,50));}throw Error('Server did not start: '+log);
  }
  async function stop(){if(child&&child.exitCode===null){child.kill('SIGTERM');await new Promise(resolve=>child.once('close',resolve));}}
  async function request(path,method='GET',body,ok=true){
    const response=await fetch(base+path,{method,headers:{Origin:base,'Content-Type':'application/json'},...(body===undefined?{}:{body:JSON.stringify(body)})});
    const result=await response.json();assert.equal(response.ok,ok,JSON.stringify(result));return result;
  }
  try{
    await start();
    const normalized=await request('/api/knowledge/index');
    assert.ok(LEGACY_KNOWLEDGE_CATEGORIES.every(old=>!normalized.categories.some(c=>c.id===old.id)));
    assert.equal(normalized.categoryRedirects['market-official'],'market-main');
    assert.equal(normalized.categories.find(c=>c.id==='market-main').count,0);
    assert.equal(normalized.categories.find(c=>c.id==='market-main').internalFileCount,1);
    const create=(name,parentId='')=>request('/api/knowledge/categories','POST',{name,parentId});
    const move=(paths,categoryId)=>request('/api/knowledge/classify','POST',{paths,categoryId});
    const remove=(id,target)=>request(`/api/knowledge/categories/${id}`,'DELETE',target?{moveToCategoryId:target}:undefined);
    const category=await create('临时分类');await move(['one.md'],category.id);
    const denied=await request(`/api/knowledge/categories/${category.id}`,'DELETE',undefined,false);assert.match(denied.error,/接收分类/);
    const removed=await remove(category.id,'workflow-main');assert.equal(removed.deletedFiles,0);assert.equal(removed.movedCount,1);
    const parent=await create('旧分类'),childCategory=await create('子分类',parent.id);await move(['two.md'],childCategory.id);
    const branch=await remove(parent.id,'creation');assert.equal(branch.reparented[0].id,childCategory.id);assert.equal(branch.reparented[0].parentId,'creation');
    await remove('market-main','creation');
    await request('/api/knowledge/categories/creation','DELETE',{moveToCategoryId:childCategory.id},false);
    await remove('workflow','creation');
    await stop();await start();
    const index=await request('/api/knowledge/index');
    assert.equal(index.files.length,Object.keys(contents).length);assert.equal(index.files.filter(file=>file.filename==='SKILL.md').length,1);
    assert.ok(!index.categories.some(c=>[category.id,parent.id,'workflow','market-main','market-official','market-reports'].includes(c.id)));
    assert.equal(index.files.find(file=>file.path==='one.md').knowledgeGroupId,'workflow-main');
    assert.equal(index.files.find(file=>file.path==='two.md').categoryId,childCategory.id);
    assert.equal(index.categories.find(c=>c.id==='workflow-main').parentId,'creation');
    assert.equal(index.files.find(file=>file.filename==='price.json').categoryAssigned,false);
    for(const[path,content]of Object.entries(contents))assert.equal(await readFile(join(knowledge,path),'utf8'),content);
  }finally{await stop();await rm(root,{recursive:true,force:true});}
});
