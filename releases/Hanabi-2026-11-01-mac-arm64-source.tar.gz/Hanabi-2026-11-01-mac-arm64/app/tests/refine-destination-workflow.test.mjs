import test from 'node:test';import assert from 'node:assert/strict';
import {mkdtemp,mkdir,writeFile,readFile,rm,stat} from 'node:fs/promises';import {join} from 'node:path';import {tmpdir} from 'node:os';import {spawn} from 'node:child_process';import {createServer} from 'node:net';
import {writeModelFixture,selectTestModel} from './model-catalog-fixture.mjs';
test('refine -> correction -> explicit approval writes the selected archive, creates Skills, detects conflicts and persists targets', {timeout:30_000},async()=>{
 const root=await mkdtemp(join(tmpdir(),'hanabi-refine-flow-')),data=join(root,'data'),knowledge=join(data,'knowledge/ai-content-alchemy');await mkdir(join(knowledge,'references'),{recursive:true});
 const before={'SKILL.md':'# 基础 Skill\n\n保留全局规则。','references/method.md':'# 目标方法\n\n原来的方法和用户编辑必须保留。','other.md':'# 其它档案\n\n不要动我。'};
 for(const[path,body]of Object.entries(before))await writeFile(join(knowledge,path),body);
 const probe=createServer();await new Promise(resolve=>probe.listen(0,'127.0.0.1',resolve));const port=probe.address().port;await new Promise(resolve=>probe.close(resolve));
 const base=`http://127.0.0.1:${port}`,cli=join(root,'codex.cjs');await writeModelFixture(root);
 await writeFile(cli,`#!${process.execPath}
let prompt='';process.stdin.on('data',bytes=>prompt+=bytes);process.stdin.on('end',async()=>{try{
 const jobId=prompt.match(/任务 ID：([^\\s]+)/)[1];const call=async(name,args)=>{const r=await fetch(${JSON.stringify(base)}+'/mcp',{method:'POST',headers:{Origin:${JSON.stringify(base)},'Content-Type':'application/json'},body:JSON.stringify({jsonrpc:'2.0',id:1,method:'tools/call',params:{name,arguments:args}})});const v=await r.json();if(v.error)throw Error(JSON.stringify(v));return v.result;};
 const info=JSON.parse((await call('alchemy_get_analysis_job',{jobId})).content[0].text);
 if(!info.knowledgeTarget?.path)throw Error('missing persisted target');
 if(info.job.mode!=='commit'){
  if(info.job.refineRecipe?.mode!=='brief')throw Error('the requirement must replace the implicit recipe');
  if(/把这份样本拆成 3 段|接着完成 5 篇/.test(prompt))throw Error('an implicit fixed recipe reached the model');
  if(!prompt.includes('统一调配要求'))throw Error('missing brief-led refinement instructions');
 }
 const args={jobId,result:'已对照目标档案核对，并仅处理选定位置。'};
 if(info.job.mode==='commit'){
  if(info.knowledgeTarget.mode==='create')args.knowledgeContent='# 新方法\\n\\n'+info.job.approvedRules;
  else args.knowledgeEdits=[{before:info.knowledgeTarget.content,after:info.knowledgeTarget.content+'\\n\\n## 已确认的方法\\n'+info.job.approvedRules}];
 }else{
  const denied=await call('alchemy_complete_analysis_job',{jobId,result:'不应提前写入',knowledgeEdits:[{before:'任意',after:'不应写入'}]});if(!denied.isError)throw Error('analysis changed knowledge');
  args.candidateRules=['先建立人物需求，再让产品参与解决问题。'];
 }
 const done=await call('alchemy_complete_analysis_job',args);if(done.isError)throw Error(JSON.stringify(done));
}catch(error){console.error(error);process.exitCode=1;}});`,{mode:0o700});
 let child,log='';
 const request=async(path,body,status=200)=>{const r=await fetch(base+path,{...(body===undefined?{}:{method:'POST',headers:{Origin:base,'Content-Type':'application/json'},body:JSON.stringify(body)})});const value=await r.json();assert.equal(r.status,status,JSON.stringify(value));return value;};
 const start=async()=>{child=spawn(process.execPath,['server.mjs'],{cwd:new URL('..',import.meta.url),env:{...process.env,CODEX_HOME:root,CONTENT_ALCHEMY_DATA_DIR:data,CONTENT_ALCHEMY_PORT:String(port),CONTENT_ALCHEMY_CODEX_BIN:cli},stdio:['ignore','ignore','pipe']});child.stderr.on('data',bytes=>log+=bytes);for(let n=0;n<150;n++){try{if((await fetch(base+'/healthz')).ok)return;}catch{}if(child.exitCode!==null)throw Error(log);await new Promise(resolve=>setTimeout(resolve,30));}throw Error(log);};
 const stop=async()=>{if(child?.exitCode===null){child.kill('SIGTERM');await new Promise(resolve=>child.once('close',resolve));}};
 const wait=async(id)=>{for(let n=0;n<200;n++){const job=(await request('/api/analysis-jobs')).jobs.find(job=>job.id===id);if(job&&!['queued','analyzing','commit_queued','committing'].includes(job.status)){assert.equal(job.status,'completed',JSON.stringify(job));return job;}await new Promise(resolve=>setTimeout(resolve,30));}throw Error('timeout '+log);};
 try{
  await start();await selectTestModel(base,'gpt-6-luna');
  const item=await request('/api/items',{type:'text',title:'软广样本',content:'先讲故事，再让产品解决角色的问题。'},201);
  const target={mode:'update',categoryId:'creation',path:'references/method.md'};
  const brief='只分析产品如何自然出现，不仿写；按故事自身的结构组织。';
  const source=(await request('/api/analysis-jobs',{itemIds:[item.id],mode:'distill',brief,knowledgeDestination:target},202)).jobs[0];await wait(source.id);
  assert.equal(source.brief,brief);assert.deepEqual(source.refineRecipe,{mode:'brief'});
  assert.equal(await readFile(join(knowledge,target.path),'utf8'),before[target.path],'analysis must not write');
  const correction=(await request(`/api/analysis-jobs/${source.id}/correct`,{correction:'聚焦人物动机'},202)).job;
  assert.deepEqual(correction.knowledgeDestination,source.knowledgeDestination);await wait(correction.id);
  assert.deepEqual(correction.refineRecipe,{mode:'brief'});
  const approved={jobIds:[correction.id],approvedRules:'先建立人物需求，再让产品参与解决问题。',knowledgeDestination:target};
  const commit=(await request(`/api/analysis-jobs/${correction.id}/approve`,approved,202)).job;const saved=await wait(commit.id);
  assert.equal(saved.uiChanges[0].path,target.path);assert.equal(saved.uiChanges[0].categoryId,'creation');
  assert.match(await readFile(join(knowledge,target.path),'utf8'),/原来的方法和用户编辑必须保留/);assert.match(await readFile(join(knowledge,target.path),'utf8'),/已确认的方法/);
  assert.equal((await request(`/api/analysis-jobs/${correction.id}/approve`,approved,202)).job.id,commit.id,'repeated confirmation must be idempotent');
  for(const path of ['SKILL.md','other.md'])assert.equal(await readFile(join(knowledge,path),'utf8'),before[path]);
  const createTarget={mode:'create',categoryId:'workflow-main',title:'剧情软广方法'};
  const create=(await request('/api/analysis-jobs',{itemIds:[item.id],mode:'distill',knowledgeDestination:createTarget},202)).jobs[0];await wait(create.id);
  await assert.rejects(stat(join(knowledge,create.knowledgeDestination.path)),{code:'ENOENT'});
  const createdCommit=(await request(`/api/analysis-jobs/${create.id}/approve`,{jobIds:[create.id],approvedRules:'让产品的作用来自已成立的人物需求。',knowledgeDestination:create.knowledgeDestination},202)).job;await wait(createdCommit.id);
  assert.match(await readFile(join(knowledge,create.knowledgeDestination.path),'utf8'),/# 剧情软广方法/);
  const index=await request('/api/knowledge/index');assert.equal(index.files.find(file=>file.path===create.knowledgeDestination.path).knowledgeGroupId,'workflow-main');
  const conflictSource=(await request('/api/analysis-jobs',{itemIds:[item.id],mode:'distill',brief:'复核新规则',knowledgeDestination:target},202)).jobs[0];await wait(conflictSource.id);
  await writeFile(join(knowledge,target.path),(await readFile(join(knowledge,target.path),'utf8'))+'\n用户刚刚新增的规则。');
  await request(`/api/analysis-jobs/${conflictSource.id}/approve`,{jobIds:[conflictSource.id],approvedRules:'不得覆盖新修改。',knowledgeDestination:target},409);
  assert.match(await readFile(join(knowledge,target.path),'utf8'),/用户刚刚新增/);
  await request('/api/analysis-jobs',{itemIds:[item.id],mode:'distill',knowledgeDestination:{...target,path:'../escape.md'}},400);
  await stop();await start();
  const persisted=(await request('/api/analysis-jobs')).jobs;
  assert.equal(persisted.find(job=>job.id===commit.id).knowledgeDestination.path,target.path);assert.equal(persisted.find(job=>job.id===createdCommit.id).knowledgeDestination.path,create.knowledgeDestination.path);
  assert.equal(await readFile(join(knowledge,'other.md'),'utf8'),before['other.md']);
 }finally{await stop();await rm(root,{recursive:true,force:true});}
});
