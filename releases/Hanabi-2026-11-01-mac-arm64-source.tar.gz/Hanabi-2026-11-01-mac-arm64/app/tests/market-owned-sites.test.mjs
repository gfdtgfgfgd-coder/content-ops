import test from 'node:test';
import assert from 'node:assert/strict';
import { mkdtemp, mkdir, readFile, writeFile, rm } from 'node:fs/promises';
import { join } from 'node:path';
import { tmpdir } from 'node:os';
import { DatabaseSync } from 'node:sqlite';
import { MARKET_PRODUCTS, ownedProduct } from '../lib/market-products.mjs';
import { OWNED_SITE_SKILLS, marketKnowledgeMetadata, ownedMarketSite } from '../lib/market-knowledge.mjs';
import { KnowledgeCatalog } from '../lib/knowledge-catalog.mjs';
import { discoveryOptions, discoveryQueries } from '../lib/market-discovery.mjs';
import { competitorUrl } from '../lib/market-search.mjs';
import { marketBaseline, validateMarketReport } from '../lib/market-research.mjs';

test('owned registry drives discovery and rejects CyAPI/subdomains as competitors', () => {
  assert.equal(MARKET_PRODUCTS.length, 6);
  assert.deepEqual(OWNED_SITE_SKILLS.map(s=>s.id), MARKET_PRODUCTS.map(p=>p.id));
  assert.deepEqual(discoveryOptions().lineIds, MARKET_PRODUCTS.map(p=>p.id));
  assert.equal(ownedProduct('https://chat.duoyuanx.com/subscribe').id, 'mirror');
  assert.equal(ownedProduct('https://docs.cyapi.ai/').id, 'cyapi');
  for (const p of MARKET_PRODUCTS) assert.throws(()=>competitorUrl(p.url), /我方/);
  assert.throws(()=>competitorUrl('https://docs.cyapi.ai/'), /我方/);
  assert.equal(ownedMarketSite('https://cyapi.ai/pricing').path,'sites/cyapi/SKILL.md');
  const options=discoveryOptions({lineIds:['cyapi']});
  assert.ok(discoveryQueries({queries:[]},options).some(q=>q.lineIds.includes('cyapi')));
});

test('CyAPI is visible in owned Skills and new sources route under that site', async () => {
  const root=await mkdtemp(join(tmpdir(),'hanabi-cyapi-chain-'));
  let db;
  try {
    const base=join(root,'references/ai-market-research'),relative='sites/cyapi/SKILL.md';
    await mkdir(join(base,'sites/cyapi'),{recursive:true});
    const body=await readFile(new URL('../knowledge/ai-content-alchemy/references/ai-market-research/sites/cyapi/SKILL.md',import.meta.url),'utf8');
    await writeFile(join(base,relative),body);
    const currentPricing={quotes:'sites/cyapi/references/prices-20261028.json'};
    await writeFile(join(base,'catalog.json'),JSON.stringify({version:1,main:'SKILL.md',sites:[{id:'cyapi',name:'CyAPI',path:relative,currentPricing}],models:[],confirmation:{cyapi:{paidCnyPerCredit:1}}}));
    const baseline=await marketBaseline(root);
    assert.ok(baseline.documents.some(d=>d.path===relative&&d.text.includes('人民币 1 元')));
    assert.equal(baseline.skillCatalogue.sites[0].currentPricing.quotes,currentPricing.quotes);
    const path='references/ai-market-research/'+relative;
    assert.equal(marketKnowledgeMetadata(path).skillKind,'site');
    db=new DatabaseSync(':memory:');const catalog=new KnowledgeCatalog(db,root);
    assert.equal((await catalog.files()).find(f=>f.path===path).categoryId,'market-sites');
    const saved=await catalog.saveArtifact({jobId:'11111111-1111-1111-1111-111111111111',role:'competitor',title:'CyAPI 新价核对',content:'# 新价\n核对来源',sourceUrl:'https://cyapi.ai/pricing'});
    assert.match(saved.path,/sites\/cyapi\/references\/updates\//);
    assert.equal(saved.categoryId,'market-sites');
    assert.ok((await readFile(join(base,relative),'utf8')).startsWith(body));
  } finally { db?.close();await rm(root,{recursive:true,force:true}); }
});

test('complete reports must address CyAPI alongside the previous five owned businesses', () => {
  const source={url:'https://example.com/prices',text:'实际读取的报价'};
  const report='C 端 API、B 端 API、镜像站、MakeNow、OctopusX、CyAPI\n'+source.url+'\n'+'具体价格与条件。'.repeat(150);
  assert.doesNotThrow(()=>validateMarketReport(report,[source]));
  assert.throws(()=>validateMarketReport(report.replace('、CyAPI',''),[source]),/CyAPI/);
});
