import test from 'node:test';
import assert from 'node:assert/strict';
import {collectedContent} from '../lib/intake-collection.mjs';
import {readableSourceText} from '../lib/readable-material.mjs';
import {appendIntakeNote} from '../lib/intake-input.mjs';

test('readable intake saves one full body instead of summary plus raw transcript, without a 6000-character truncation',()=>{
 const source={content:'标题\n来源字幕（配套）：\n1\n00:00:00,000 --> 00:00:01,000\n原始第一句。\n\n2\n00:00:01,000 --> 00:00:02,000\n原始第二句。'};
 const clean='第一段正文。\n\n第二段正文。';assert.equal(collectedContent(source,clean),clean);
 assert.equal(readableSourceText(source.content),'原始第一句。原始第二句。');
 assert.equal(collectedContent(source,''),'原始第一句。原始第二句。');
 const long='完整正文。'.repeat(2000);assert.equal(collectedContent(source,long),long);
});
test('editing timestamps and prices are preserved in a requested analysis; notes keep review requirements without workflow boilerplate',()=>{
 const body='约 00:14–00:23，进入工具演示。报价观察日 2026-10-26，¥99/月。';
 assert.equal(collectedContent({content:'原始内容'},body),body);
 assert.equal(appendIntakeNote(body,{instruction:'口播'}),body);
 const pending=appendIntakeNote(body,{instruction:'优化市场调研流程',requiresReview:true,uncertainty:'先确认是否适合'});
 assert.match(pending,/先由你审阅确认/);assert.match(pending,/先确认是否适合/);
 assert.doesNotMatch(pending,/执行范围|本条采火备注/);assert.equal(appendIntakeNote(pending,{requiresReview:true,uncertainty:'先确认是否适合'}),pending);
 assert.equal(readableSourceText('价格 ¥99/月，观察日期 2026-10-26。'),'价格 ¥99/月，观察日期 2026-10-26。');
});
