import test from 'node:test';
import assert from 'node:assert/strict';
import JSZip from 'jszip';
import { validateMarketUrl, readMarketPage, MARKET_PRODUCTS, marketReportPrompt, marketPageExcerpt, validateMarketReport } from '../lib/market-research.mjs';
import { calculateMarketCost } from '../lib/market-cost.mjs';
import { reportDocx } from '../lib/report-docx.mjs';

test('public research URLs exclude credentials, private hosts and private documents', () => {
  for (const url of ['http://localhost/a', 'https://127.0.0.1/', 'http://[::1]/', 'https://local/', 'https://a.internal/', 'https://user:pass@site.com/', 'file:///etc/passwd', 'https://a.feishu.cn/docx/secret', 'https://site.com/?api_key=abc']) assert.throws(() => validateMarketUrl(url), undefined, url);
  assert.equal(validateMarketUrl('https://example.com/pricing#plans'), 'https://example.com/pricing');
  assert.equal(MARKET_PRODUCTS.length, 6);
  assert.ok(MARKET_PRODUCTS.some(product => product.url === 'https://zx1.deepwl.net/'));
});

test('reader preserves source and hash, rejects errors rather than inventing prices', async () => {
  const page = await readMarketPage('https://example.com/pricing', { fetchImpl: async () => new Response('Title: Pricing\n\nMarkdown Content:\n' + 'Model X costs USD 1 per million input tokens. '.repeat(8)) });
  assert.equal(page.url, 'https://example.com/pricing'); assert.equal(page.sha256.length, 64); assert.match(page.text, /USD 1/);
  await assert.rejects(readMarketPage('https://example.com/', { fetchImpl: async () => new Response('denied', { status: 403 }) }), /HTTP 403/);
  await assert.rejects(readMarketPage('https://example.com/', { fetchImpl: async () => new Response('Sign in to continue'.repeat(30)) }), /登录/);
  await assert.rejects(readMarketPage('https://example.com/pricing', { fetchImpl: async () => new Response('Title: Missing\n\nMarkdown Content:\n# Page Not Found\n' + 'The page does not exist. '.repeat(10)) }), /404/);
  assert.match(marketReportPrompt('比较视频生成'), /比较视频生成/);
  assert.match(marketReportPrompt(), /CyAPI 逆向站，覆盖 我方 6 条业务线/);
});

test('Word export is editable OOXML with CJK text, tables, repeated header and valid hyperlink relationships', async () => {
  const buffer = await reportDocx({ title: 'Fallback title', markdown: '# 比价报告\n\n## 核查结果\n\n中文 **粗体**，**观察基准：**本轮参考[公开价页](https://example.com/a?x=1&y=2)。\n\n| 商品 | 人民币 | 条件 |\n| --- | --- | --- |\n| 图片 | ¥0.15 | 1 张 |\n\n- 第一条\n  - 子项目\n\n1. 有序项目\n\n<script>untrusted()</script>', sources: [{ title: '补充来源', url: 'https://example.org/' }] });
  const zip = await JSZip.loadAsync(buffer);
  for (const name of ['[Content_Types].xml', '_rels/.rels', 'word/document.xml', 'word/styles.xml', 'word/_rels/document.xml.rels', 'word/footer1.xml']) assert.ok(zip.file(name), name);
  const doc = await zip.file('word/document.xml').async('string');
  assert.match(doc, /比价报告/); assert.match(doc, /<w:tbl>/); assert.match(doc, /<w:tblHeader\/>/); assert.match(doc, /粗体/); assert.doesNotMatch(doc, /\*\*/); assert.doesNotMatch(doc, /untrusted|Fallback title/);
  assert.match(doc, /<w:cantSplit\/>/);
  const adjacentBody = [...doc.matchAll(/<w:r>([\s\S]*?)<\/w:r>/g)].find(match => match[1].includes('本轮'));
  assert.ok(adjacentBody); assert.doesNotMatch(adjacentBody[1], /<w:b\/>/);
  const rels = await zip.file('word/_rels/document.xml.rels').async('string'); assert.match(rels, /x=1&amp;y=2/); assert.match(rels, /TargetMode="External"/);
  await assert.rejects(reportDocx({ markdown: '' }), /正文/);
});

test('cost arithmetic separates FX, credits and exclusive token buckets', () => {
  const line = { rate: '3', quantity: '100000', rateUnit: 'million_tokens', quantityUnit: 'token', bucket: 'uncached_input', evidence: 'quote-1' };
  assert.equal(calculateMarketCost({ currency: 'CNY', lines: [line] }).cny, '0.3');
  assert.equal(calculateMarketCost({ currency: 'USD', usdNature: 'cash', usdEvidence: 'Official invoice settlement currency USD', lines: [line], fx: { cnyPerUsd: '6.7192', date: '2026-10-21', source: 'SAFE' } }).cny, '2.01576');
  assert.equal(calculateMarketCost({ currency: 'CREDIT', lines: [line] }).cny, null);
  assert.equal(calculateMarketCost({ currency: 'USD', lines: [line] }).usd, null);
  assert.equal(calculateMarketCost({ currency: 'CREDIT', lines: [line], creditTerms: { paidCny: '98', creditedUnits: '1226', evidence: 'MakeNow plan' } }).cny, '0.02398042');
  for (const bad of [{ ...line, rate: '-1' }, { ...line, quantityUnit: 'call' }, { ...line, evidence: '' }, { ...line, bucket: '' }]) assert.throws(() => calculateMarketCost({ currency: 'CNY', lines: [bad] }));
  assert.throws(() => calculateMarketCost({ currency: 'CNY', lines: [line, line] }), /互斥/);
  assert.throws(() => calculateMarketCost({ currency: 'USD', lines: [line], fx: { cnyPerUsd: '7' } }), /来源/);
  assert.throws(() => calculateMarketCost({ currency: 'USD', lines: [line], fx: { cnyPerUsd: '7', date: '2026-10-21', source: 'fx' } }), /现金 USD/);
  assert.throws(() => calculateMarketCost({ currency: 'CREDIT', lines: [line], creditTerms: { paidCny: '98', creditedUnits: '0', evidence: 'plan' } }), /零/);
});

test('page search and report completion require actual evidence and all owned business lines', () => {
  const page = { url: 'https://example.com/', text: 'gpt-6 input 1.2; '.repeat(2000) };
  const excerpt = marketPageExcerpt(page, { query: 'gpt-6' });
  assert.equal(excerpt.matches.length, 12);
  assert.equal(marketPageExcerpt(page).nextOffset, 16000);
  const report = 'C 端 API、B 端 API、镜像站、MakeNow、OctopusX、CyAPI https://example.com/\n' + '有来源的对照结果。'.repeat(100);
  assert.doesNotThrow(() => validateMarketReport(report, [page]));
  assert.throws(() => validateMarketReport(report, []), /来源/);
  for (const line of ['C 端 API', 'B 端 API', '镜像站', 'MakeNow', 'OctopusX', 'CyAPI']) assert.throws(() => validateMarketReport(report.replace(line, ''), [page]), /尚未覆盖/);
  assert.equal(MARKET_PRODUCTS.find(product => product.id === 'overseas').url, 'https://octopusx.ai/');
});

import {reportHtml,feishuCellText} from '../lib/report-html.mjs';
import {validateMarketAnalysis} from '../lib/market-research.mjs';
test('research writing uses original price tables without imposing a percentage or consulting template',()=>{
 const prompt=marketReportPrompt();
 assert.doesNotMatch(prompt,/结论分为来源事实|开篇用 3|至少包含三项/);
 assert.match(prompt,/原始单价|原始报价/);
 assert.doesNotThrow(()=>validateMarketAnalysis('| 型号 | 价格 |\n| a | 0.12 |\n| b | 0.1 |\n| c | 0.2 |',[{result:{cny:'0.12'}},{result:{cny:'0.1'}}]));
});
test('Feishu export preserves currency precision, ratios and token pairs as readable text',()=>{
 assert.equal(feishuCellText('¥0.816'),'人民币 ¥0.816');assert.equal(feishuCellText('+65.00%'),'高 65.00%');assert.equal(feishuCellText('−53.33%'),'低 53.33%');assert.equal(feishuCellText('1 / 5'),'输入 1；输出 5');
 assert.equal(feishuCellText('$0.149'),'页面标价 $0.149');
 const html=reportHtml('# 标题\n\n|型号|金额|价差|输入输出|\n|---|---|---|---|\n|test|¥0.816|+65.00%|1 / 5|\n\n<script>bad()</script>\n\n[不安全](javascript:alert)');
 assert.match(html,/人民币 ¥0.816/);assert.match(html,/高 65.00%/);assert.match(html,/输入 1；输出 5/);assert.match(html,/<colgroup>/);assert.doesNotMatch(html,/<script|javascript:/);
});
