import test from "node:test";
import assert from "node:assert/strict";
import { normalizePreviewLayout, PREVIEW_RATIOS, preparePreviewMarkdown, previewFilename, previewImages } from "../lib/preview-layout.mjs";

test("preview layouts normalize persisted values and constrain artwork geometry", () => {
  assert.deepEqual(PREVIEW_RATIOS["3:4"], [540,720]);
  assert.equal(normalizePreviewLayout({ theme:"foreign",ratio:"100:1",fontSize:1000 }).fontSize,32);
  assert.equal(normalizePreviewLayout({fontSize:-5}).fontSize,16);
  assert.equal(normalizePreviewLayout({theme:"foreign"}).theme,"hanabi");
  assert.equal(normalizePreviewLayout({watermark:""}).watermark,"");
  assert.equal(normalizePreviewLayout(null).theme,"hanabi");
});
test("manual page breaks preserve inline examples, fenced code, and normal horizontal rules", () => {
  const markdown='正文\n\n<!--pagebreak-->\n\n`<!--pagebreak-->`\n\n```html\n<!--pagebreak-->\n```\n\n~~~\n<!--pagebreak-->\n~~~\n\n---';
  const prepared=preparePreviewMarkdown(markdown);
  assert.equal((prepared.match(/data-hanabi-pagebreak/g)||[]).length,1);
  assert.ok(prepared.includes('`<!--pagebreak-->`'));assert.ok(prepared.endsWith('---'));
});
test("preview collects all static images and selected video frames without duplicate IDs or raw video", () => {
  const images=previewImages({attachments:[{id:'cover',mimeType:'image/webp'},{id:'raw',mimeType:'video/mp4'}],mediaFrames:[{id:'later',mimeType:'image/jpeg'},{id:'cover',mimeType:'image/webp'}]});
  assert.deepEqual(images.map(image=>image.id),['cover','later']);
});
test("download titles cannot create path segments", () => {
  assert.equal(previewFilename('../作品/标题:示例'), '..-作品-标题-示例');
  assert.equal(previewFilename('  '),'Hanabi');
});
