import test from 'node:test';
import assert from 'node:assert/strict';
import { DatabaseSync } from 'node:sqlite';
import { CollectionRedirects } from '../lib/library-collections.mjs';
import { automaticCollectionPlan, COLLECTION_CLASSIFICATION_RULES } from '../lib/intake-collection.mjs';

test('automatic classification reuses broad purposes instead of minting one collection per subject', () => {
  const modules = [
    { id: 'c', name: '内容创作', viewKey: 'archive', previousNames: ['版式', '剪辑', '文案'] },
    { id: 'b', name: '商业运营', viewKey: 'archive', previousNames: ['广告'] },
    { id: 't', name: '工具方法', viewKey: 'archive' },
    { id: 'l', name: '生活参考', viewKey: 'archive' },
  ];
  for (const [name, purpose, id] of [['手绘建筑封面','content','c'], ['宠物店会员转化','business','b'], ['数据库备份教程','tools','t'], ['阳台植物养护','life','l']]) {
    assert.equal(automaticCollectionPlan(modules, { name, purpose, reason: '按主要用途归类' }).module.id, id);
  }
  assert.equal(automaticCollectionPlan(modules, { name: '短视频剪辑参考' }).module.id, 'c');
  assert.throws(() => automaticCollectionPlan(modules, { name: '钓鱼饵料清单', reason: '集合说明没写钓鱼' }), /具体题材请放在 tags/);
  assert.equal(automaticCollectionPlan([], { purpose: 'life', name: '钓鱼饵料清单' }).name, '生活参考');
  assert.match(automaticCollectionPlan([], { purpose: 'life' }).description, /日常生活/);
  // Current explicit names take precedence over a different collection's alias.
  const custom = { id: 'manual', name: '文案', viewKey: 'archive' };
  assert.equal(automaticCollectionPlan([...modules, custom], { name: '文案' }).module.id, 'manual');
  assert.match(COLLECTION_CLASSIFICATION_RULES, /先读用户对本条资料的用途/);
});

test('consolidation preserves fields, aliases and content, and rolls back conflicting field schemas', () => {
  const db = new DatabaseSync(':memory:');
  db.exec(`CREATE TABLE library_modules(id TEXT PRIMARY KEY,name TEXT,view_key TEXT,description TEXT,fields_json TEXT,created_by_job_id TEXT,created_at TEXT,updated_at TEXT,color_tone TEXT,previous_names_json TEXT);
    CREATE TABLE items(id TEXT PRIMARY KEY,content TEXT,module_ids TEXT,module_values TEXT,archive_space TEXT);
    CREATE TABLE analysis_jobs(id TEXT PRIMARY KEY,target_module_ids TEXT);`);
  const redirects = new CollectionRedirects(db);
  const module = (id,name,fields=[]) => db.prepare("INSERT INTO library_modules VALUES(?,?,'archive','',?,'','a','a','mint','[]')").run(id,name,JSON.stringify(fields));
  module('layout','版式',[{key:'note',label:'观察',type:'text'}]); module('voice','口播',[{key:'note',label:'观察',type:'text'}]);
  db.prepare("INSERT INTO items VALUES('1','原始正文',?,?, 'library')").run('["layout","voice"]','{"layout":{"note":"版式证据"},"voice":{"note":"口播证据"}}');
  db.prepare("INSERT INTO analysis_jobs VALUES('j','[\"voice\"]')").run();
  const snapshot = db.prepare('SELECT * FROM items').get();
  redirects.consolidate([{id:'layout',name:'内容创作',ids:['layout','voice'],description:'创作参考'}]);
  assert.equal(db.prepare('SELECT count(*) n FROM library_modules').get().n,1);
  const actual = db.prepare('SELECT * FROM items').get();
  assert.equal(actual.content,snapshot.content); assert.deepEqual(JSON.parse(actual.module_ids),['layout']);
  assert.equal(JSON.parse(actual.module_values).layout.note,'版式证据；口播证据');
  assert.equal(db.prepare('SELECT target_module_ids FROM analysis_jobs').get().target_module_ids,'["layout"]');
  assert.deepEqual(redirects.row(snapshot),{...actual},'historical snapshot resolves to the same membership');
  assert.deepEqual(redirects.previousIds('layout'),['voice']);
  module('conflict','冲突',[{key:'note',label:'另一含义',type:'number'}]);
  assert.throws(() => redirects.consolidate([{id:'layout',name:'新名字',ids:['layout','conflict'],description:''}]), /字段冲突/);
  assert.equal(db.prepare("SELECT name FROM library_modules WHERE id='layout'").get().name,'内容创作');
  assert.equal(redirects.resolve('conflict'),'conflict');
  assert.equal(redirects.resolve(''),'');
  db.close();
});
