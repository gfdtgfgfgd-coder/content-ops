import test from "node:test";
import assert from "node:assert/strict";
import { readFile } from "node:fs/promises";
import vm from "node:vm";
import { needsVisualContext, frameTimes, initialVisualReview, planVisualReview, MAX_SEARCH_FRAMES } from "../lib/visual-search.mjs";

const frames = frameTimes(20, 6).map((seconds, index) => ({ id: `f${index}`, seconds }));
const images = [{ id: "cover" }];
const options = { frames, images, duration: 20, scope: ["text", "image"] };
const initial = initialVisualReview(frames, images);

test("reading visual context is independent of archiving the video", () => {
  assert.equal(needsVisualContext(["image"], "学习版式"), true);
  assert.equal(needsVisualContext(["text"], "学习版式"), true);
  assert.equal(needsVisualContext(["text"], "提取画面里的店铺名"), false);
  assert.equal(needsVisualContext(["audio"], "整理口播"), false);
});

test("initial frames cover the beginning, middle and end; focused frames stay inside bounds", () => {
  assert.equal(frames[0].seconds, 0); assert.equal(frames.at(-1).seconds, 19.96);
  const focused = frameTimes(20, 12, { start: 13, end: 14, existing: frames });
  assert.ok(focused.every((seconds) => seconds >= 13 && seconds <= 14));
  assert.ok(frameTimes(0.02, 6).every((seconds) => seconds === 0));
});

test("a cover or first frame alone cannot finish the visual review", () => {
  assert.throws(() => planVisualReview(initial, { decision: "sufficient", reason: "只看了第一帧", reviewedFrameIds: ["f0"], selectedImageIds: ["cover"] }, options), /跨时段/);
  assert.throws(() => planVisualReview(initial, { decision: "sufficient", reason: "看完了但没有选图", reviewedFrameIds: initial.overviewIds, selectedImageIds: [] }, options), /勾选了图片/);
});

test("an initial no-match automatically expands instead of rejecting the user's goal", () => {
  const plan = planVisualReview(initial, { decision: "not_found", reason: "初步画面未发现所需版式，需要继续检查", reviewedFrameIds: initial.overviewIds }, options);
  assert.equal(plan.kind, "expanded"); assert.ok(plan.times.length > 6);
  assert.ok(plan.times.some((seconds) => seconds > 12 && seconds < 18));
});

test("expanded review can request a closer time range and select a later frame", () => {
  const more = frameTimes(20, 24, { existing: frames }).map((seconds, index) => ({ id: `e${index}`, seconds }));
  const review = { ...initial, deliveredFrameIds: [...initial.deliveredFrameIds, ...more.map((frame) => frame.id)], rounds: [{ kind: "expanded", frameIds: more.map((frame) => frame.id) }] };
  const all = [...frames, ...more];
  const focus = planVisualReview(review, { decision: "need_more", reason: "需要细看13至14秒的文字布局", startSeconds: 13, endSeconds: 14 }, { ...options, frames: all });
  assert.equal(focus.kind, "focused"); assert.ok(focus.times.every((time) => time >= 13 && time <= 14));
  const result = planVisualReview(review, { decision: "sufficient", reason: "后段画面已展示所需布局", reviewedFrameIds: review.deliveredFrameIds, selectedImageIds: [more.at(-1).id] }, { ...options, frames: all });
  assert.equal(result.kind, "finish"); assert.deepEqual(result.review.selectedImageIds, [more.at(-1).id]);
  assert.throws(() => planVisualReview(review, { decision: "sufficient", reason: "传入其他任务图片", reviewedFrameIds: review.deliveredFrameIds, selectedImageIds: ["foreign"] }, { ...options, frames: all }), /不属于/);
});

test("no-match needs expanded evidence reviewed, and further searches have a hard bound", () => {
  const review = { ...initial, rounds: [{ kind: "expanded" }], deliveredFrameIds: [...initial.deliveredFrameIds, "later"] };
  assert.throws(() => planVisualReview(review, { decision: "not_found", reason: "只检查了封面", reviewedFrameIds: initial.overviewIds }, options), /跨时段/);
  const result = planVisualReview(review, { decision: "not_found", reason: "已核对提供的跨时段画面，所查取样中没有目标信息", reviewedFrameIds: review.deliveredFrameIds }, options);
  assert.equal(result.review.decision, "not_found"); assert.deepEqual(result.review.selectedImageIds, []);
  assert.throws(() => planVisualReview(review, { decision: "need_more", reason: "继续取更多画面" }, { ...options, frames: Array.from({ length: MAX_SEARCH_FRAMES }, (_, i) => ({ id: String(i), seconds: i })) }), /上限/);
});

test("a selected video frame appears as an image on the library card", async () => {
  const source = await readFile(new URL("../app.js", import.meta.url), "utf8");
  const code = source.slice(source.indexOf("function renderMedia(item)"), source.indexOf("const mediaFacetLabels"));
  const html = vm.runInNewContext(`${code};renderMedia({attachments:[],mediaFrames:[{id:'selected-frame',name:'版式图.jpg',mimeType:'image/jpeg'}]});`, { escapeHtml: (value) => value });
  assert.ok(html.includes('<img src="/api/uploads/selected-frame"')); assert.equal(html.includes("<video"), false);
});

test("a single-frame clip can report the inspected limit without an endless expansion loop", () => {
  const single = [{ id: "only", seconds: 0 }];
  const review = initialVisualReview(single);
  const result = planVisualReview(review, { decision: "not_found", reason: "唯一可用画面没有目标内容", reviewedFrameIds: ["only"] }, { frames: single, images: [], duration: 0.02, scope: ["text", "image"] });
  assert.equal(result.kind, "finish"); assert.equal(result.review.decision, "not_found");
  assert.equal(result.review.rounds[0].kind, "exhausted");
});
