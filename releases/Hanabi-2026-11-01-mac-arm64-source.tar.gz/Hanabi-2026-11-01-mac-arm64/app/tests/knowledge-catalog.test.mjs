import test from 'node:test';
import assert from 'node:assert/strict';
import { DatabaseSync } from 'node:sqlite';
import { mkdtemp,mkdir,writeFile,readFile,rm,symlink } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { KnowledgeCatalog,automaticCategory } from '../lib/knowledge-catalog.mjs';
import { historicalComparisons,tokenScenario } from '../lib/market-comparison.mjs';
import { validateMarketAnalysis } from '../lib/market-research.mjs';
import { knowledgeSections,knowledgeListFiles } from '../lib/market-knowledge.mjs';

test('reference documents can join Basic Skill; empty groups delete permanently without deleting files, and users can reparent groups',async()=>{
 const root=await mkdtemp(join(tmpdir(),'hanabi-edit-groups-')),dir=join(root,'knowledge'),db=new DatabaseSync(join(root,'db.sqlite'));
 await mkdir(join(dir,'references'),{recursive:true});
 const documents={'SKILL.md':'# 基础 Skill\n\n[偏好](references/preferences.md)','references/preferences.md':'# 集合归类偏好','references/material.md':'# 资料正文整理'};
 for(const [path,body]of Object.entries(documents))await writeFile(join(dir,path),body);
 try {
  let catalog=new KnowledgeCatalog(db,dir);
  const paths=['references/preferences.md','references/material.md'];
  await catalog.move(paths,'workflow');
  assert.equal((await catalog.files()).filter(f=>f.knowledgeGroupId==='workflow-other').length,2);
  await catalog.move(paths,'workflow-main');
  const files=await catalog.files(),sections=knowledgeSections(files);
  assert.equal(sections.find(section=>section.id==='workflow-main').files.length,3);
  assert.equal(knowledgeListFiles(files,{categoryId:'workflow-main',categories:catalog.categories()}).length,3);
  await assert.rejects(catalog.remove('workflow-main'),/还有档案/);
  assert.equal((await catalog.remove('workflow-other')).deletedFiles,0);
  catalog=new KnowledgeCatalog(db,dir);assert.ok(!catalog.categories().some(c=>c.id==='workflow-other'),'deleted default group came back after restart');
  const subgroup=catalog.create('我的方法','workflow');await catalog.move([paths[1]],subgroup.id);
  const renamed=catalog.update(subgroup.id,{name:'可复用方法',parentId:'creation'});
  assert.equal(renamed.parentId,'creation');assert.equal((await catalog.files()).find(f=>f.path===paths[1]).knowledgeGroupTitle,'可复用方法');
  assert.equal(knowledgeListFiles(await catalog.files(),{categoryId:'creation',categories:catalog.categories()}).length,1);
  assert.throws(()=>catalog.update('creation',{parentId:subgroup.id}),/自身或下级/);
  const modelCategory=catalog.categories().find(c=>c.id==='market-models');catalog.rename(modelCategory.id,'官方模型');
  assert.equal(catalog.categories().find(c=>c.id===modelCategory.id).isGroup,0,'editing a branch must preserve its child groups');
  for(const [path,body]of Object.entries(documents))assert.equal(await readFile(join(dir,path),'utf8'),body);
  assert.equal((await catalog.files()).length,3);
 } finally {db.close();await rm(root,{recursive:true,force:true});}
});

test('classifications persist, rename without changing links, support parent filters and reject invalid paths',async()=>{
 const root=await mkdtemp(join(tmpdir(),'hanabi-categories-')),db=new DatabaseSync(join(root,'db.sqlite')),dir=join(root,'knowledge');await mkdir(dir);
 try {
  await writeFile(join(dir,'example.md'),'# 原标题\n\n价格证据');
  const catalog=new KnowledgeCatalog(db,dir),category=catalog.create('我的调研','market');
  await catalog.move(['example.md'],category.id);catalog.rename(category.id,'我的报价');
  const again=new KnowledgeCatalog(db,dir),files=await again.files();assert.equal(files[0].category,'我的报价');assert.equal(files[0].name,'原标题');assert.equal(files[0].path,'example.md');assert.ok(again.descendants('market').has(category.id));
  assert.equal(await readFile(join(dir,'example.md'),'utf8'),'# 原标题\n\n价格证据');
  assert.throws(()=>again.create('我的报价','market'),/已存在/);await assert.rejects(again.move(['../db.sqlite'],category.id),/路径/);
  await symlink(join(root,'db.sqlite'),join(dir,'external.md'));assert.equal((await again.files()).length,1);await assert.rejects(again.move(['external.md'],category.id),/不存在/);
  const artifact=await again.saveArtifact({jobId:'11111111-1111-1111-1111-111111111111',role:'report',title:'比价终稿',content:'# 比价终稿\n\n三个发现'});
  assert.equal(artifact.categoryId,'market-main');assert.match(await readFile(join(dir,artifact.path),'utf8'),/三个发现/);
  assert.equal(automaticCategory('references/ai-market-research/references/official/openai.md'),'market-main');
  assert.equal(automaticCategory('references/ai-market-research/references/sources/R14.md'),'market-main');
 } finally {db.close();await rm(root,{recursive:true,force:true});}
});
test('deleting a nonempty category relocates files and children atomically without surfacing raw evidence or recreating the category',async()=>{
 const root=await mkdtemp(join(tmpdir(),'hanabi-delete-category-')),dir=join(root,'knowledge'),db=new DatabaseSync(join(root,'db.sqlite'));
 const documents={'SKILL.md':'# 基础 Skill','notes.md':'# 工作笔记','references/ai-market-research/references/official/old.json':'[{"price":"1.2"}]'};
 for(const[path,body]of Object.entries(documents)){await mkdir(join(dir,path,'..'),{recursive:true});await writeFile(join(dir,path),body);}
 try {
  let catalog=new KnowledgeCatalog(db,dir);
  await assert.rejects(catalog.remove('workflow',{moveToCategoryId:'workflow-main'}),/下级以外/);
  const moved=catalog.create('待整理'),child=catalog.create('案例',moved.id);catalog.create('案例','creation');
  await catalog.move(['notes.md'],child.id);
  const result=await catalog.remove(moved.id,{moveToCategoryId:'creation'});
  assert.equal(result.deletedFiles,0);assert.equal(result.reparented[0].name,'案例（2）');
  assert.equal((await catalog.files()).find(f=>f.path==='notes.md').categoryId,child.id);
  const rootResult=await catalog.remove('workflow',{moveToCategoryId:'creation'});
  assert.equal(rootResult.deletedFiles,0);assert.equal((await catalog.files()).find(f=>f.path==='SKILL.md').knowledgeGroupId,'workflow-main');
  const removed=await catalog.remove('market-main',{moveToCategoryId:'creation'});
  assert.equal(removed.movedCount,1);
  const evidence=(await catalog.files()).find(f=>f.filename==='old.json');
  assert.equal(evidence.categoryId,'creation');assert.equal(evidence.categoryAssigned,false);
  assert.ok(!knowledgeListFiles(await catalog.files()).some(f=>f.path===evidence.path));
  catalog=new KnowledgeCatalog(db,dir);assert.ok(!catalog.categories().some(c=>['workflow','market-main',moved.id].includes(c.id)));
  for(const[path,body]of Object.entries(documents))assert.equal(await readFile(join(dir,path),'utf8'),body);
  assert.equal((await catalog.files()).length,3);
 } finally {db.close();await rm(root,{recursive:true,force:true});}
});
test('historical analysis calculates actual directions and excludes anomalous rows',()=>{
 const data=historicalComparisons([{id:'T01',rows:[['模型','竞品','我方'],['test','输入 ¥1；输出 ¥5 /百万Token','输入 ¥1.2；输出 ¥6 /百万Token'],['anomaly','输入 ¥1；输出 ¥5 /百万Token','输入 ¥450；输出 ¥2250 /百万Token']]}]);
 assert.equal(data.rows[0].ownCost,'2.4');assert.equal(data.rows[0].competitorCost,'2');assert.equal(data.rows[0].ownMoreExpensivePercent,20);assert.equal(data.groups[0].sampleCount,1);assert.equal(data.groups[0].anomaliesExcluded,1);
 assert.throws(()=>tokenScenario({uncached_input:'1',output:'2'},{cache_read:'100'},'table'),/缺少/);
});
test('moving a structured Skill overrides its path classification across reloads without changing it or its evidence',async()=>{
 const root=await mkdtemp(join(tmpdir(),'hanabi-skill-move-')),dir=join(root,'knowledge'),db=new DatabaseSync(join(root,'db.sqlite'));
 const path='references/ai-market-research/models/gpt/SKILL.md',evidence='references/ai-market-research/models/gpt/references/prices.json';
 await mkdir(join(dir,'references/ai-market-research/models/gpt/references'),{recursive:true});
 await writeFile(join(dir,path),'---\nname: gpt-prices\ndescription: 官方价格\n---\n# GPT 官方价格\n\n[价格](references/prices.json)');
 await writeFile(join(dir,evidence),'[{"price":"2.5"}]');
 try {
  const catalog=new KnowledgeCatalog(db,dir),category=catalog.create('个人知识','creation'),before=await readFile(join(dir,path),'utf8');
  assert.equal((await catalog.files()).find(f=>f.path===path).knowledgeGroupId,'market-model-text');
  catalog.rename('market-model-text','语言模型');
  assert.equal((await catalog.files()).find(f=>f.path===path).knowledgeGroupTitle,'模型官方价格 · 语言模型');
  await catalog.move([path],category.id);
  for(let i=0;i<3;i++) {
   const current=new KnowledgeCatalog(db,dir),files=await current.files(),skill=files.find(f=>f.path===path);
   assert.equal(skill.categoryId,category.id);assert.equal(skill.categoryAssigned,true);assert.equal(skill.skillKind,'model');
   assert.equal(files.find(f=>f.path===evidence).categoryAssigned,false);
   assert.equal(await readFile(join(dir,path),'utf8'),before);assert.equal(await readFile(join(dir,evidence),'utf8'),'[{"price":"2.5"}]');
   assert.equal(files.length,2);
  }
 }finally{db.close();await rm(root,{recursive:true,force:true});}
});
test('report quality rejects wordy summaries without quantitative analysis',()=>{
 assert.throws(()=>validateMarketAnalysis('有表格有建议'.repeat(300)),/两次/);
 const calcs=[{result:{cny:'2.4'}},{result:{cny:'2'}}];
 assert.throws(()=>validateMarketAnalysis('|model|2.4|2|',calcs),/三行/);
 assert.doesNotThrow(()=>validateMarketAnalysis('|a|2.4|\n|b|2|\n|c|3|\n高20%，另有10%和30%的条件测算。',calcs));
});
