// Isolated fixture: real Hanabi HTML/CSS/modules, synthetic sources and uploads.
// It never connects to the user's Hanabi service or opens the personal database.
const {app,BrowserWindow,nativeImage}=require('electron');
const {createServer}=require('node:http');
const {readFileSync,writeFileSync,mkdtempSync,mkdirSync,existsSync}=require('node:fs');
const {resolve,join,extname}=require('node:path');
const {tmpdir}=require('node:os');
const assert=require('node:assert/strict');
const JSZip=require('jszip');
app.disableHardwareAcceleration();
const root=resolve(__dirname,'..'),output=mkdtempSync(join(tmpdir(),'hanabi-preview-'));
for(const name of ['userData','sessionData','logs']){const path=join(output,name);mkdirSync(path);app.setPath(name,path);}
const downloads=[],errors=[];
const {deflateSync}=require('node:zlib');
function crc32(bytes){let crc=0xffffffff;for(const byte of bytes){crc^=byte;for(let i=0;i<8;i++)crc=(crc>>>1)^((crc&1)?0xedb88320:0);}return (crc^0xffffffff)>>>0;}
function chunk(type,data){const t=Buffer.from(type),head=Buffer.alloc(4),tail=Buffer.alloc(4);head.writeUInt32BE(data.length);tail.writeUInt32BE(crc32(Buffer.concat([t,data])));return Buffer.concat([head,t,data,tail]);}
const ihdr=Buffer.alloc(13);ihdr.writeUInt32BE(180,0);ihdr.writeUInt32BE(240,4);ihdr[8]=8;ihdr[9]=6;
const rows=[];for(let y=0;y<240;y++){const row=Buffer.alloc(1+180*4);for(let x=0;x<180;x++){const i=1+x*4;row[i]=70+x/3;row[i+1]=170;row[i+2]=200+y/8;row[i+3]=255;}rows.push(row);}
const png=Buffer.concat([Buffer.from([137,80,78,71,13,10,26,10]),chunk('IHDR',ihdr),chunk('IDAT',deflateSync(Buffer.concat(rows))),chunk('IEND',Buffer.alloc(0))]);
const sourceText='## 内容与版式的组合\n\n'+('正文要完整保留，**重点词**和[来源链接](https://example.com)跨页也不能丢失。'.repeat(24))+'\n\n## 可组合的版式\n\n'+Array.from({length:12},(_,i)=>`${i+1}. 规则${i+1}：主张、证据与解释分别占据可调整的位置。`).join('\n')+'\n\n<!--pagebreak-->\n\n## 参数表\n\n| 参数 | 用途 |\n|---|---|\n'+Array.from({length:28},(_,i)=>`| 第${i+1}项 | 字号和图片比例是可替换参数 |`).join('\n')+'\n\n```html\n<!--pagebreak-->\n```\n\nEND完整末尾';
const item={id:'fixture-map',title:'OC 地图：把灵感变成可组合的版式',type:'image',platform:'小红书',content:sourceText,tags:[],moduleIds:[],moduleValues:{},sourceName:'隔离测试',updatedAt:'2026-10-20T00:00:00Z',attachments:[{id:'cover',name:'拼贴封面.png',mimeType:'image/png'}],mediaFrames:[{id:'later-one',name:'样式参数.jpg',mimeType:'image/png'},{id:'later-two',name:'地图结果.jpg',mimeType:'image/png'}]};
const second={...item,id:'fixture-other',platform:'',title:'另一份作品',content:'另一份独立的原文。',attachments:[],mediaFrames:[]};
const production={id:'fixture-output',itemId:item.id,title:'制花成品：版式资产库',targetPlatform:'小红书',mode:'produce',status:'completed',result:'## 成品正文\n\n内容、版式和参数可以分别组合。',brief:'制作一组知识图卡',progress:100,sourceRead:{},mediaCoverage:{},uiChanges:[],sources:[],candidateRules:[],referenceItemIds:[item.id]};
const report={...production,id:'fixture-report',marketReport:true,title:'竞品比价 · 队列标题',targetPlatform:'document',result:'# 价格调研10.22\n\n## duoyuanx与同行比价\n\n- **B 端先把报价讲清。**同一份价格表\n\n|型号|我方输入|对方输入|\n|---|---|---|\n|test|¥0.816|¥0.68|\n\n正文完整末尾'};
const fixtureHtml=readFileSync(join(root,'index.html'),'utf8').replace(/src="\/app\.js[^\"]*"/,'src="/preview-test-bootstrap.mjs"');
const bootstrap=`import {PreviewStudio} from '/lib/preview-studio.mjs';import {marked} from '/node_modules/marked/lib/marked.esm.js';import DOMPurify from '/node_modules/dompurify/dist/purify.es.mjs';
window.testItems=${JSON.stringify([item,second])};window.testItem=testItems[0];
document.querySelectorAll('.view-panel').forEach(panel=>{panel.hidden=true;panel.classList.remove('active');});document.querySelector('#view-preview').hidden=false;document.querySelector('#view-preview').classList.add('active');document.querySelector('#preview-tools-dialog').showModal();
window.studio=new PreviewStudio({getItem:()=>testItem,parseMarkdown:source=>marked.parse(source),sanitize:(html,options)=>DOMPurify.sanitize(html,options),onError:error=>{window.lastError=error;}});
window.auditPages=()=>{const plain=root=>{const copy=root.cloneNode(true);copy.querySelectorAll('thead').forEach(node=>node.remove());return copy.textContent.replace(/\\s/g,'');};const actual=studio.pages.map(page=>plain(page.firstElementChild)).join(''),expected=plain(studio.buildContent(testItem));return {complete:actual===expected,fit:studio.pages.every(page=>{const clone=page.cloneNode(true);studio.measure.append(clone);const body=clone.firstElementChild,okay=body.scrollHeight<=body.clientHeight+1;clone.remove();return okay;})};};
window.ready=studio.render({item:testItem,platform:'xiaohongshu',device:'phone'});`;
let mutations=0;
const server=createServer((request,response)=>{
  const pathname=new URL(request.url,'http://fixture').pathname;
  if(request.method!=='GET'){mutations++;response.writeHead(400);response.end('{}');return;}
  const json=value=>{response.setHeader('Content-Type','application/json');response.end(JSON.stringify(value));};
  if(pathname==='/api/state')return json({items:[item,second],counts:[]});
  if(pathname==='/api/library-modules')return json({modules:[]});
  if(pathname==='/api/analysis-jobs')return json({jobs:[production,report]});
  if(pathname.startsWith('/api/knowledge'))return json({files:[]});
  if(pathname.startsWith('/api/uploads/')){response.setHeader('Content-Type','image/png');response.end(png);return;}
  if(pathname==='/preview-test-bootstrap.mjs'){response.setHeader('Content-Type','text/javascript');response.end(bootstrap);return;}
  response.setHeader('Content-Security-Policy',"default-src 'self'; script-src 'self'; style-src 'self'; img-src 'self' data:; media-src 'self'; connect-src 'self'; object-src 'none'; base-uri 'self'; frame-ancestors 'none'");
  if(pathname==='/fixture'){response.setHeader('Content-Type','text/html');response.end(fixtureHtml);return;}
  const file=resolve(root,'.'+(pathname==='/'?'/index.html':pathname));
  if(!file.startsWith(root+'/')){response.writeHead(403);return response.end();}
  try{const data=readFileSync(file);response.setHeader('Content-Type',({'.html':'text/html','.mjs':'text/javascript','.js':'text/javascript','.css':'text/css','.woff2':'font/woff2','.svg':'image/svg+xml','.png':'image/png'})[extname(file)]||'application/octet-stream');response.end(data);}catch{response.writeHead(404);response.end();}
});
app.whenReady().then(async()=>{
  app.dock?.hide();await new Promise(resolve=>server.listen(0,'127.0.0.1',resolve));const base='http://127.0.0.1:'+server.address().port;
  const window=new BrowserWindow({show:false,width:1500,height:1050,webPreferences:{offscreen:true,contextIsolation:true}});
  window.webContents.on('console-message',event=>{if(event.message?.includes('Error')||event.message?.includes('Refused'))errors.push(event.message);});
  window.webContents.session.on('will-download',(_event,download)=>{const path=join(output,download.getFilename());download.setSavePath(path);download.once('done',(_event,state)=>downloads.push({path,state}));});
  const evalJs=async script=>{try{return await window.webContents.executeJavaScript(script);}catch(error){throw Error(error.message+'\nEvaluating: '+script.slice(0,1800));}};
  const waitFor=async(script,timeout=15000)=>{const start=Date.now();while(Date.now()-start<timeout){if(await evalJs(script))return;await new Promise(resolve=>setTimeout(resolve,80));}throw Error('Timed out: '+script+'\n'+JSON.stringify(await evalJs('({status:document.querySelector("#preview-launch-status").textContent,error:window.lastError})')));};
  try{
    await window.loadURL(base+'/fixture');await evalJs('ready');
    const initial=await evalJs(`(()=>{const texts=studio.pages.map(p=>p.firstElementChild.textContent).join('');return {count:studio.pages.length,sourceText:testItem.content,images:studio.pages.reduce((n,p)=>n+p.querySelectorAll('img').length,0),ends:texts.includes('END完整末尾'),rows:studio.pages.reduce((n,p)=>n+p.querySelectorAll('tbody tr').length,0),fits:studio.pages.every(page=>{const host=document.createElement('div');host.className='preview-measure';host.append(page.cloneNode(true));document.body.append(host);const body=host.firstElementChild.firstElementChild,okay=body.scrollHeight<=body.clientHeight+1;host.remove();return okay;}),emphasis:studio.pages.some(p=>p.querySelector('strong')),codeExample:studio.pages.some(p=>p.querySelector('pre')?.textContent.includes('<!--pagebreak-->'))};})()`);
    assert.ok(initial.count>4,JSON.stringify(initial));assert.equal(initial.images,3);assert.equal(initial.rows,28);assert.ok(initial.fits&&initial.ends&&initial.emphasis&&initial.codeExample,JSON.stringify(initial));assert.equal(initial.sourceText,sourceText);
    assert.deepEqual(await evalJs('auditPages()'),{complete:true,fit:true});
    for(const theme of ['hanabi','paper','editorial','blueprint'])for(const ratio of ['3:4','1:1','9:16']){
      const result=await evalJs(`(async()=>{studio.draft.layout.theme=${JSON.stringify(theme)};studio.draft.layout.ratio=${JSON.stringify(ratio)};await studio.render();return {count:studio.pages.length,width:parseFloat(studio.pages[0]?.style.width),height:parseFloat(studio.pages[0]?.style.height),text:studio.pages.map(page=>page.firstElementChild.textContent).join('')};})()`);
      assert.ok(result.count>0,`${theme}/${ratio} failed`);assert.equal(result.width,540);assert.equal(result.height,ratio==='3:4'?720:ratio==='1:1'?540:960);assert.ok(result.text.includes('END完整末尾'));
      assert.deepEqual(await evalJs('auditPages()'),{complete:true,fit:true},`${theme}/${ratio} lost or clipped content`);
    }
    for(const font of ['sans','serif','mono'])for(const fontSize of [16,32]){
      const audit=await evalJs(`(async()=>{studio.draft.layout.font=${JSON.stringify(font)};studio.draft.layout.fontSize=${fontSize};await studio.render();return auditPages();})()`);
      assert.deepEqual(audit,{complete:true,fit:true},`${font}/${fontSize} lost or clipped content`);
    }
    await evalJs(`studio.draft.layout.font='sans';studio.draft.layout.fontSize=23;`);
    await evalJs(`studio.draft.layout.ratio='3:4';studio.draft.layout.theme='hanabi';studio.syncControls();studio.render()`);
    const editing=await evalJs(`(async()=>{
      const field=document.querySelector('#preview-draft-content');field.value='## 修改后的正文\\n\\n本机排版草稿，END。';field.dispatchEvent(new Event('input'));clearTimeout(studio.timer);await studio.render();
      const changed=studio.draft.content.includes('本机排版草稿');studio.undo();clearTimeout(studio.timer);await studio.render();const undone=studio.draft.content===testItem.content;studio.undo(true);clearTimeout(studio.timer);await studio.render();const redone=studio.draft.content.includes('本机排版草稿');
      testItem=testItems[1];await studio.render({item:testItem,platform:'xiaohongshu',device:'phone'});const isolated=studio.draft.content==='另一份独立的原文。';testItem=testItems[0];await studio.render({item:testItem,platform:'xiaohongshu',device:'phone'});
      return {changed,undone,redone,isolated,restored:studio.draft.content.includes('本机排版草稿'),original:testItems[0].content===${JSON.stringify(sourceText)}};
    })()`);
    Object.entries(editing).forEach(([key,value])=>assert.equal(value,true,`editing ${key}`));
    const manual=await evalJs(`(async()=>{studio.draft.imageIds=[];studio.draft.content='第一页短文\\n\\n<!--pagebreak-->\\n\\n第二页短文';await studio.render();return studio.pages.length;})()`);assert.equal(manual,2);
    // Short, image-rich fixture keeps actual export tests fast.
    await evalJs(`studio.draft.content='## 可组合的作品\\n\\n文字和配图一起预览。';studio.draft.imageIds=['cover','later-one','later-two'];studio.persist();studio.render()`);
    await evalJs(`studio.export('png')`);await waitFor('document.querySelector("#preview-launch-status").textContent.includes("已生成下载")');
    for(let i=0;i<100&&downloads.length<1;i++)await new Promise(resolve=>setTimeout(resolve,50));
    assert.equal(downloads[0]?.state,'completed',JSON.stringify({downloads,errors}));const dimensions=nativeImage.createFromPath(downloads[0].path).getSize();assert.deepEqual(dimensions,{width:1080,height:1440});
    await evalJs(`studio.export('zip')`);for(let i=0;i<200&&downloads.length<2;i++)await new Promise(resolve=>setTimeout(resolve,50));
    assert.equal(downloads[1]?.state,'completed',JSON.stringify({downloads,errors}));const zip=await JSZip.loadAsync(readFileSync(downloads[1].path));const pngs=Object.keys(zip.files).filter(name=>name.endsWith('.png'));assert.ok(pngs.length>=2);assert.ok(zip.file('排版草稿.md'));assert.ok(zip.file('排版设置.json'));
    for(const path of pngs){const bytes=await zip.file(path).async('nodebuffer');assert.ok(bytes.length>2000);assert.equal(nativeImage.createFromBuffer(bytes).getSize().width,1080);}
    await evalJs(`studio.export('html')`);for(let i=0;i<100&&downloads.length<3;i++)await new Promise(resolve=>setTimeout(resolve,50));
    const html=readFileSync(downloads[2].path,'utf8');assert.ok(html.includes('data:image/png;base64,'));assert.equal(html.includes('/api/uploads/'),false);
    const article=await evalJs(`(async()=>{await studio.render({item:testItem,platform:'wechat',device:'desktop'});return {article:studio.pages[0].classList.contains('hanabi-article'),copy:!document.querySelector('#preview-copy-article').hidden,png:document.querySelector('#preview-export-png').hidden};})()`);assert.ok(article.article&&article.copy&&article.png);
    // Copy is verified against an isolated clipboard substitute, not the user's clipboard.
    const copied=await evalJs(`(async()=>{let formats=[];Object.defineProperty(navigator,'clipboard',{configurable:true,value:{write:async values=>{formats=values[0].types;}}});await studio.export('clipboard');return formats;})()`);assert.ok(copied.includes('text/html')&&copied.includes('text/plain'));
    const deselected=await evalJs(`(async()=>{studio.draft.content='![已入库图片](/api/uploads/cover)';studio.draft.imageIds=[];await studio.render({item:testItem,platform:'xiaohongshu',device:'phone'});return studio.pages.reduce((n,page)=>n+page.querySelectorAll('img').length,0);})()`);assert.equal(deselected,0);
    const sanitization=await evalJs(`(async()=>{studio.draft.content='<script>window.xss=true</script>\\n\\n<img src="https://example.com/remote.png" onerror="window.xss=true">';await studio.render({item:testItem,platform:'xiaohongshu',device:'phone'});return {safe:!window.xss&&!studio.pages.some(page=>page.querySelector('script,[onerror]')),notice:studio.pages.some(page=>page.querySelector('.preview-missing-image'))};})()`);assert.ok(sanitization.safe&&sanitization.notice);
    const failedExport=await evalJs(`(async()=>{await studio.export('html');return document.querySelector('#preview-launch-status').textContent;})()`);assert.ok(failedExport.includes('停止导出'));assert.equal(downloads.length,3);
    // Actual application navigation: no fixture renderer shortcuts.
    await window.loadURL(base+'/');await waitFor('document.querySelector("#preview-item-select").options.length>1');
    await evalJs(`document.querySelector('[data-view="preview"]').click();document.querySelector('#preview-tools-open').click();const select=document.querySelector('#preview-item-select');select.value='fixture-map';select.dispatchEvent(new Event('change'));`);
    await waitFor('document.querySelectorAll("[data-preview-page]").length>0 && !document.querySelector("#preview-stage").hasAttribute("aria-busy")');
    const layouts=[];
    for(const width of [1500,1100,768,390]){
      window.setContentSize(width,1050);await new Promise(resolve=>setTimeout(resolve,200));
      if(width===390){await window.loadURL(base+'/');await waitFor('document.querySelector("#preview-item-select").options.length>1');await evalJs(`document.querySelector('[data-view="preview"]').click();document.querySelector('#preview-tools-open').click();const select=document.querySelector('#preview-item-select');select.value='fixture-map';select.dispatchEvent(new Event('change'));`);await waitFor('document.querySelectorAll("[data-preview-page]").length>0 && !document.querySelector("#preview-stage").hasAttribute("aria-busy")');assert.equal(await evalJs('document.querySelector("#preview-style-settings").open'),false);}
      const layout=await evalJs(`({width:innerWidth,overflow:document.documentElement.scrollWidth-innerWidth,pageWidth:document.querySelector('#preview-screen .hanabi-page').getBoundingClientRect().width,screenWidth:document.querySelector('#preview-screen').clientWidth})`);assert.ok(layout.overflow<=1,JSON.stringify(layout));assert.ok(Math.abs(layout.pageWidth-layout.screenWidth)<2,JSON.stringify(layout));layouts.push(layout);
      if(width===1500||width===390)writeFileSync(join(output,'preview-'+width+'.png'),(await window.webContents.capturePage()).toPNG());
    }
    window.setContentSize(1500,1050);
    await evalJs(`document.querySelector('[data-view="outflow"]').click();document.querySelector('[data-preview-output="fixture-output"]').click();document.querySelector('#preview-tools-open').click();`);
    await waitFor('document.querySelector("#preview-item-select").value==="job:fixture-output" && document.querySelector("#preview-screen").textContent.includes("成品正文") && !document.querySelector("#preview-stage").hasAttribute("aria-busy")');
    const productionPath=await evalJs(`({selected:document.querySelector('#preview-item-select').value,pages:document.querySelectorAll('[data-preview-page]').length,pngEnabled:!document.querySelector('#preview-export-png').disabled})`);assert.ok(productionPath.pngEnabled&&productionPath.pages>0);
    await evalJs(`document.documentElement.classList.add('dark-theme');document.querySelector('[data-preview-theme="blueprint"]').click();`);
    await waitFor('document.querySelector("#preview-screen .theme-blueprint") && !document.querySelector("#preview-stage").hasAttribute("aria-busy")');
    const dark=await evalJs(`({pageBackground:getComputedStyle(document.querySelector('#preview-screen .hanabi-page')).backgroundColor,text:getComputedStyle(document.querySelector('#preview-screen .hanabi-page')).color})`);assert.equal(dark.pageBackground,'rgb(242, 248, 253)');
    writeFileSync(join(output,'preview-dark.png'),(await window.webContents.capturePage()).toPNG());
    await evalJs(`document.documentElement.classList.remove('dark-theme');document.documentElement.dataset.theme='light';document.querySelector('[data-view="outflow"]').click();document.querySelector('[data-preview-output="fixture-report"]').click();document.querySelector('#preview-tools-open').click();`);
    await waitFor('document.querySelector("#preview-screen .hanabi-report") && !document.querySelector("#preview-stage").hasAttribute("aria-busy")');
    const reportPath=await evalJs(`({scene:document.querySelector('#preview-platform').value,device:document.querySelector('#preview-device').value,pngHidden:document.querySelector('#preview-export-png').hidden,ratioHidden:document.querySelector('#preview-card-settings').hidden,thumbnails:document.querySelectorAll('[data-preview-page]').length,headings:document.querySelectorAll('#preview-screen h1').length,bold:document.querySelector('#preview-screen strong')?.textContent,word:document.querySelector('#preview-word-export').getAttribute('href'),font:getComputedStyle(document.querySelector('#preview-screen .hanabi-report')).fontSize,complete:document.querySelector('#preview-screen').textContent.includes('正文完整末尾')})`);
    assert.equal(reportPath.scene,'document');assert.equal(reportPath.device,'desktop');assert.ok(reportPath.pngHidden&&reportPath.ratioHidden&&reportPath.complete);assert.equal(reportPath.thumbnails,0);assert.equal(reportPath.headings,1);assert.equal(reportPath.font,'18px');assert.equal(reportPath.bold,'B 端先把报价讲清。');assert.match(reportPath.word,/fixture-report\/export.docx/);
    const reportCopy=await evalJs(`(async()=>{let copied=[];Object.defineProperty(navigator,'clipboard',{configurable:true,value:{write:async items=>{for(const type of items[0].types)copied.push([type,await (await items[0].getType(type)).text()]);}}});document.querySelector('#preview-copy-article').click();for(let i=0;i<80&&!copied.length;i++)await new Promise(r=>setTimeout(r,25));return copied;})()`);
    assert.match(reportCopy.find(([type])=>type==='text/html')[1],/人民币 ¥0.816/);
    await new Promise(resolve=>setTimeout(resolve,250));
    writeFileSync(join(output,'report-document.png'),(await window.webContents.capturePage()).toPNG());
    await evalJs(`document.querySelector('#preview-platform').value='custom';document.querySelector('#preview-platform').dispatchEvent(new Event('change'));`);
    await waitFor('document.querySelectorAll("[data-preview-page]").length>0 && !document.querySelector("#preview-stage").hasAttribute("aria-busy")');
    await evalJs(`{let select=document.querySelector('#preview-item-select');select.value='fixture-other';select.dispatchEvent(new Event('change'));}`);
    await waitFor('document.querySelector("#preview-screen .hanabi-report") && !document.querySelector("#preview-stage").hasAttribute("aria-busy")');
    assert.equal(await evalJs(`document.querySelector('#preview-platform').value`),'document');
    await evalJs(`{let select=document.querySelector('#preview-item-select');select.value='job:fixture-report';select.dispatchEvent(new Event('change'));}`);
    await waitFor('document.querySelectorAll("[data-preview-page]").length>0 && !document.querySelector("#preview-stage").hasAttribute("aria-busy")');
    assert.equal(await evalJs(`document.querySelector('#preview-platform').value`),'custom');
    if(process.env.HANABI_REPORT_FIXTURE){
      report.result=readFileSync(process.env.HANABI_REPORT_FIXTURE,'utf8');report.updatedAt=new Date().toISOString();
      await window.loadURL(base+'/');await waitFor('document.querySelector("#preview-item-select").options.length>1');
      await evalJs(`localStorage.removeItem('hanabiPreviewPresentationsV1');`);
      await window.loadURL(base+'/');await waitFor('document.querySelector("#preview-item-select").options.length>1');
      await evalJs(`document.querySelector('[data-view="outflow"]').click();document.querySelector('[data-preview-output="fixture-report"]').click();document.querySelector('#preview-tools-open').click();`);
      await waitFor('document.querySelector("#preview-screen .hanabi-report") && !document.querySelector("#preview-stage").hasAttribute("aria-busy")');
      await new Promise(resolve=>setTimeout(resolve,250));
      writeFileSync(join(output,'reviewed-report-preview.png'),(await window.webContents.capturePage()).toPNG());
      const actual=await evalJs(`({scene:document.querySelector('#preview-platform').value,tableCount:document.querySelectorAll('#preview-screen table').length,rawBold:document.querySelector('#preview-screen').textContent.includes('**'),transform:getComputedStyle(document.querySelector('#preview-screen .hanabi-report')).transform})`);
      assert.equal(actual.scene,'document');assert.equal(actual.rawBold,false);assert.equal(actual.transform,'none');assert.ok(actual.tableCount>=5);
      reportPath.reviewedFixture=actual;reportPath.reviewedScreenshot=join(output,'reviewed-report-preview.png');
    }
    const contentOriginal=JSON.parse(JSON.stringify(item));assert.equal(contentOriginal.content,sourceText);assert.equal(mutations,0);
    delete initial.sourceText;
    console.log(JSON.stringify({ok:true,initial,editing,manualPages:manual,exportedPng:dimensions,zipImages:pngs.length,article,copied,layouts,productionPath,reportPath,dark,downloads,screenshots:[join(output,'preview-1500.png'),join(output,'preview-390.png'),join(output,'preview-dark.png'),join(output,'report-document.png')],consoleErrors:errors}));
    window.destroy();server.close();app.exit(0);
  }catch(error){console.error(error.stack);console.error(JSON.stringify({errors,downloads,output}));window.destroy();server.close();app.exit(1);}
});
