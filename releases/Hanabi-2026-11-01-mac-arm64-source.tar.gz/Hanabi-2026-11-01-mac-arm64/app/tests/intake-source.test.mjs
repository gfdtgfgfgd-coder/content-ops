import test from "node:test";
import assert from "node:assert/strict";
import vm from "node:vm";
import { isXhsSource, isSignedXhsSource, retrySourceRead, readXhsSource, usableSourceText, hasSourceEvidence, classifySourceError, redactSourceError, XHS_METADATA_EXPRESSION, selectVisualEvidence } from "../lib/intake-source.mjs";

const signed = "https://www.xiaohongshu.com/explore/6ac9d651000000000201147c?xsec_token=test-signature";
const noDelay = async () => {};

test("extracts current EF4 video streams and source subtitles, as well as legacy h264", () => {
  for (const codec of ["EF4", "h264", "mediaV2-only", "empty-legacy-stream"]) {
    const videoUrl = "http://sns-video-v3.xhscdn.com/source.mp4";
    const subtitleUrl = "https://sns-subtitle-s1.xhscdn.com/source.srt";
    const video = { ...(codec === "mediaV2-only" ? {} : { media: { stream: codec === "empty-legacy-stream" ? {} : { [codec]: [{ masterUrl: videoUrl }] } } }), mediaV2: JSON.stringify({ stream: { EF4: [{ master_url: videoUrl }] }, video: { subtitles: { source: [{ language: "zh-CN", url: subtitleUrl }] } } }) };
    const player = { duration: 169.6, currentSrc: "blob:player" };
    const scope = { querySelector: (selector) => selector === "video" ? player : null };
    const context = { location: { pathname: "/explore/abc123", href: signed }, window: { __INITIAL_STATE__: { note: { noteDetailMap: { abc123: { note: { title: "actual video", desc: "正文", type: "video", video } } } } } }, document: { body: { innerText: "" }, querySelector: (selector) => selector === "#noteContainer" ? scope : null } };
    const metadata = JSON.parse(vm.runInNewContext(XHS_METADATA_EXPRESSION, context));
    assert.equal(metadata.media.find((entry) => entry.type === "video").url, videoUrl);
    assert.equal(metadata.media.find((entry) => entry.type === "subtitle").url, subtitleUrl);
  }
});

test("both short-link domains and all supported signed note paths are recognized", () => {
  for (const value of ["https://xhslink.cn/o/abc", "http://xhslink.com/a/abc", signed]) assert.ok(isXhsSource(value));
  for (const path of ["explore/abc123", "discovery/item/abc123", "search_result/abc123", "user/profile/u1/abc123"]) assert.ok(isSignedXhsSource(`https://www.xiaohongshu.com/${path}?xsec_token=t`));
  for (const value of ["https://evilxiaohongshu.com/explore/abc?xsec_token=t", "https://xiaohongshu.com.evil.test/explore/abc?xsec_token=t", "file:///xiaohongshu.com", "https://u:p@xiaohongshu.com/explore/abc?xsec_token=t"]) assert.equal(isXhsSource(value), false);
  assert.equal(isSignedXhsSource("https://www.xiaohongshu.com/explore/abc"), false);
});

test("a temporary navigation failure retries, a denial never does", async () => {
  let calls = 0;
  const result = await retrySourceRead(async () => { if (++calls === 1) throw new Error("Execution context destroyed while navigating"); return "ready"; }, { delay: noDelay });
  assert.equal(result, "ready"); assert.equal(calls, 2);
  calls = 0;
  await retrySourceRead(async () => { if (++calls === 1) throw new Error("Navigation rejected."); return true; }, { delay: noDelay });
  assert.equal(calls, 2);
  calls = 0;
  await assert.rejects(retrySourceRead(async () => { calls++; throw new Error("Navigation denied"); }, { delay: noDelay }), { code: "SOURCE_ACCESS_DENIED" });
  assert.equal(calls, 1);
  assert.equal(classifySourceError(new Error("来源要求登录后查看")).retryable, false);
});

test("signed inputs still read body metadata, and body survives a failed download", async () => {
  const commands = [];
  const result = await readXhsSource({ sourceUrl: signed, jobId: "job-1", profile: "p", directory: "/tmp/unused", delay: noDelay,
    execute: async (_profile, args) => {
      commands.push(args);
      if (args.includes("open")) return { page: "owned-tab" };
      if (args.includes("eval")) return JSON.stringify({ url: signed, ready: true, title: "作品标题", description: "真实的作品正文", noteType: "video" });
      if (args[0] === "xiaohongshu") throw Object.assign(new Error("No downloadable media"), { code: "EMPTY_RESULT" });
      return {};
    } });
  assert.equal(result.description, "真实的作品正文");
  assert.equal(result.downloadError.code, "EMPTY_RESULT");
  assert.ok(commands.some((args) => args.includes("eval")));
  assert.deepEqual(commands.at(-1).slice(-2), ["close", "owned-tab"]);
});

test("waits for the note itself, not just the redirect URL", async () => {
  let reads = 0;
  const result = await readXhsSource({ sourceUrl: "https://xhslink.cn/o/abc", jobId: "job-2", profile: "p", directory: "/tmp/unused", delay: noDelay,
    execute: async (_profile, args) => {
      if (args.includes("open")) return { page: "owned-tab" };
      if (args.includes("eval")) return JSON.stringify({ url: signed, ready: ++reads > 1, title: reads > 1 ? "loaded note" : "", description: reads > 1 ? "正文" : "" });
      return {};
    } });
  assert.equal(reads, 2); assert.equal(result.title, "loaded note");
});

test("media from the readable note uses that page's manifest without a second navigation", async () => {
  const commands = []; let downloads = 0;
  const result = await readXhsSource({ sourceUrl: signed, jobId: "manifest", profile: "p", directory: "/tmp/unused", delay: noDelay,
    execute: async (_profile, args) => {
      commands.push(args);
      if (args.includes("open")) return { page: "owned-tab" };
      if (args.includes("eval")) return JSON.stringify({ url: signed, ready: true, title: "video", media: [{ type: "video", url: "https://sns-video-bd.xhscdn.com/example.mp4" }] });
      return {};
    },
    download: async (media) => { downloads++; assert.equal(media[0].type, "video"); },
  });
  assert.equal(downloads, 1); assert.equal(result.downloadError, null);
  assert.equal(commands.filter((args) => args.includes("open")).length, 1);
  assert.equal(commands.some((args) => args[0] === "xiaohongshu"), false);
});

test("no download or workaround is attempted after a source access denial", async () => {
  const commands = [];
  await assert.rejects(readXhsSource({ sourceUrl: signed, jobId: "job-3", profile: "p", directory: "/tmp/unused", delay: noDelay,
    execute: async (_profile, args) => {
      commands.push(args);
      if (args.includes("open")) return { page: "owned-tab" };
      return JSON.stringify({ url: signed, accessDenied: true });
    } }), { code: "SECURITY_BLOCK" });
  assert.equal(commands.some((args) => args[0] === "xiaohongshu"), false);
  assert.deepEqual(commands.at(-1).slice(-2), ["close", "owned-tab"]);
});

test("placeholder, title, duration and old failure report are not source evidence", () => {
  const content = "待分析链接。请先打开原始页面读取内容。\n\n<!-- hanabi-intake:old -->\n\n读取失败，没有正文";
  assert.equal(usableSourceText(content), "");
  assert.equal(hasSourceEvidence({ content, title: "有标题但没有内容", attachments: "[]" }, ["text"]), false);
  assert.equal(hasSourceEvidence({ content: "视频时长：25 秒\n\n解析后的笔记链接：https://xhslink.cn/o/x" }, ["text"]), false);
  assert.equal(hasSourceEvidence({ content: "笔记简介：这是实际作品文字" }, ["text"]), true);
});

test("only real files in the selected scope qualify as evidence", () => {
  const video = { id: "v", mimeType: "video/mp4", name: "source.mp4" };
  const image = { id: "i", mimeType: "image/jpeg", name: "frame.jpg" };
  const ocr = { id: "t", mimeType: "text/plain", name: "OCR.txt" };
  assert.equal(hasSourceEvidence({ attachments: [video, image] }, ["text"]), false);
  assert.equal(hasSourceEvidence({ attachments: [ocr] }, ["text"]), true);
  assert.equal(hasSourceEvidence({ attachments: [video] }, ["video"], () => false), false);
  assert.equal(hasSourceEvidence({ media_frames: [image] }, ["video"]), true);
  assert.equal(hasSourceEvidence({ media_frames: [image] }, ["image"]), true);
  assert.equal(hasSourceEvidence({ attachments: [{ id: "audio", mimeType: "audio/wav" }] }, ["audio"]), false);
  assert.equal(hasSourceEvidence({ attachments: [{ ...ocr, sourceType: "source-subtitles" }] }, ["audio"]), true);
  assert.equal(hasSourceEvidence({ attachments: [{ ...ocr, sourceType: "transcript" }] }, ["text"]), false);
});

test("provider diagnostics never expose the signed query token", () => {
  const result = redactSourceError(`Cannot read ${signed}`);
  assert.equal(result.includes("test-signature"), false);
});

test("visual evidence reaches the native input in order and respects selected scope", () => {
  const frame = (id) => ({ id, mimeType: "image/jpeg", name: `${id}.jpg` });
  const items = [{ mediaFrames: [frame("v1"), frame("v2")], attachments: [frame("cover1")] }, { mediaFrames: [frame("v3")], attachments: [frame("cover2")] }];
  assert.deepEqual(selectVisualEvidence(items, ["text"]), []);
  assert.deepEqual(selectVisualEvidence(items, ["audio"]), []);
  assert.deepEqual(selectVisualEvidence(items, ["video"]).map((f) => f.id), ["v1", "v3", "v2"]);
  assert.deepEqual(selectVisualEvidence(items, ["image"]).map((f) => f.id), ["v1", "v3", "v2", "cover2", "cover1"]);
  assert.deepEqual(selectVisualEvidence(items, ["video"], { assetExists: (f) => f.id !== "v1", limit: 2 }).map((f) => f.id), ["v2", "v3"]);
});
