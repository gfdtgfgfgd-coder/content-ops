import test from "node:test";
import assert from "node:assert/strict";
import { collectionTone } from "../lib/collection-presentation.mjs";

test("established collections preserve their green and pink hues", () => {
  assert.equal(collectionTone({ id: "style", name: "风格" }), "mint");
  assert.equal(collectionTone({ id: "shopping", name: "shoppinglist" }), "pink");
  assert.equal(collectionTone({ id: "shopping", name: " ShoppingList " }), "pink");
});

test("new collections keep their color through selection and reordering", () => {
  const modules = Array.from({ length: 20 }, (_, index) => ({ id: `created-${index}`, name: `新集合 ${index}` }));
  const before = new Map(modules.map((module) => [module.id, collectionTone(module)]));
  for (const selected of modules) {
    for (const module of [...modules].reverse()) {
      assert.equal(collectionTone({ ...module, selected: module.id === selected.id }), before.get(module.id));
    }
  }
  assert.ok(new Set(before.values()).size > 1);
  assert.equal(collectionTone({ id: "created-1", name: "改过名字" }), before.get("created-1"));
});

test("collection themes are safe predefined tokens", () => {
  for (const module of [{}, { name: "" }, { id: '\"><script>', name: "视觉参考" }, { name: "🎆 灵感" }]) {
    assert.ok(["pink", "mint", "cyan", "lilac"].includes(collectionTone(module)));
  }
});

test("a persisted collection color survives every rename", () => {
  for (const module of [{ id: "style", name: "风格" }, { id: "shopping", name: "shoppinglist" }, { id: "custom", name: "新集合" }]) {
    const tone = collectionTone(module);
    for (const name of ["设计参考", "风格", "shoppinglist", "所有灵感"]) assert.equal(collectionTone({ ...module, name, tone }), tone);
  }
});
