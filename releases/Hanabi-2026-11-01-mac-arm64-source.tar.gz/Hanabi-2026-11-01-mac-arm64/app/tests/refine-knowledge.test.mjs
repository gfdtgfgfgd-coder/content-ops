import test from 'node:test';import assert from 'node:assert/strict';
import {DatabaseSync} from 'node:sqlite';import {mkdtemp,mkdir,readFile,writeFile,rm,symlink} from 'node:fs/promises';
import {tmpdir} from 'node:os';import {join} from 'node:path';import {randomUUID} from 'node:crypto';
import {KnowledgeCatalog} from '../lib/knowledge-catalog.mjs';import {RefineKnowledge,applyKnowledgeEdits} from '../lib/refine-knowledge.mjs';
test('confirmed refinement updates only the selected file and category, preserves versions and mirrors narrow edits',async()=>{
 const root=await mkdtemp(join(tmpdir(),'hanabi-refine-')),knowledge=join(root,'knowledge'),mirror=join(root,'mirror');await mkdir(knowledge);await mkdir(mirror);
 const original='---\nname: example\ndescription: 方法\n---\n\n# 方法\n\n保留我的原有规则。\n';
 for(const dir of [knowledge,mirror])await writeFile(join(dir,'SKILL.md'),original+(dir===mirror?'\n外部副本的独立内容。\n':''));
 await writeFile(join(knowledge,'other.md'),'# 其它\n用户编辑');
 const db=new DatabaseSync(join(root,'db.sqlite')),catalog=new KnowledgeCatalog(db,knowledge),service=new RefineKnowledge({catalog,mirrorRoot:mirror,backupRoot:join(root,'backups')});
 try{
  const target=await service.prepare({mode:'update',path:'SKILL.md',categoryId:'workflow-main'});
  assert.equal((await service.context(target)).content,original);
  const edits=[{before:'保留我的原有规则。',after:'保留我的原有规则。\n新增：开场用具体问题承接产品。'}];
  const request={jobId:randomUUID(),knowledgeEdits:edits};const [change,repeated]=await Promise.all([service.commit(target,request),service.commit(target,request)]);assert.deepEqual(repeated,change);
  assert.equal(change.path,'SKILL.md');assert.equal(change.mirror,'updated');
  assert.match(await readFile(join(mirror,'SKILL.md'),'utf8'),/外部副本的独立内容/);
  assert.match(await readFile(join(knowledge,'SKILL.md'),'utf8'),/新增：开场/);
  assert.equal(await readFile(join(knowledge,'other.md'),'utf8'),'# 其它\n用户编辑');
  assert.equal((await catalog.files()).find(f=>f.path==='SKILL.md').knowledgeGroupId,'workflow-main');
  await assert.rejects(service.commit(target,{jobId:randomUUID(),knowledgeEdits:edits}),/新修改/);
  const fresh=await service.prepare({mode:'update',path:'other.md',categoryId:'creation'});
  await writeFile(join(knowledge,'other.md'),'# 其它\n用户刚保存的新内容');
  await assert.rejects(service.context(fresh),/新修改/);assert.match(await readFile(join(knowledge,'other.md'),'utf8'),/刚保存/);
  const created=await service.prepare({mode:'create',categoryId:'creation',title:'软广方法'});
  await service.commit(created,{jobId:randomUUID(),knowledgeContent:'# 未定标题\n\n先建立故事，再让产品解决人物需求。'});
  const body=await readFile(join(knowledge,created.path),'utf8');assert.match(body,/name: hanabi-/);assert.match(body,/# 软广方法/);
  assert.equal((await catalog.files()).find(f=>f.path===created.path).categoryId,'creation');
  await assert.rejects(service.commit(created,{jobId:randomUUID(),knowledgeContent:'# 不允许覆盖'}),/新修改/);
  const invalid=await service.prepare({mode:'update',path:'other.md',categoryId:'creation'});
  await catalog.remove('creation',{moveToCategoryId:'workflow-main'});
  await assert.rejects(service.commit(invalid,{jobId:randomUUID(),knowledgeEdits:[{before:'用户刚保存的新内容',after:'不应写入'}]}),/分类已删除/);
  await assert.rejects(service.prepare({mode:'update',path:'../outside.md',categoryId:'workflow-main'}),/请选择/);
  await symlink(join(knowledge,'other.md'),join(knowledge,'alias.md'));
  await assert.rejects(service.prepare({mode:'update',path:'alias.md',categoryId:'workflow-main'}),/请选择/);
 }finally{db.close();await rm(root,{recursive:true,force:true});}
});
test('ambiguous or destructive file patches do not silently rewrite documents or Skill metadata',()=>{
 assert.throws(()=>applyKnowledgeEdits('one one',[{before:'one',after:'two'}]),/新修改/);
 assert.throws(()=>applyKnowledgeEdits('one',[{before:'',after:'two'}]),/格式/);
 assert.throws(()=>applyKnowledgeEdits('---\nname: one\n---\n正文',[{before:'name: one',after:'name: two'}]),/元信息/);
 assert.throws(()=>applyKnowledgeEdits('one',[{before:'one',after:''}]),/为空/);
});
