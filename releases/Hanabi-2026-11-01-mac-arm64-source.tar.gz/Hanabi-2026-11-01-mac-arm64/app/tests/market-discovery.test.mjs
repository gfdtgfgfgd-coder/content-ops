import test from 'node:test';
import assert from 'node:assert/strict';
import { DatabaseSync } from 'node:sqlite';
import { MarketDiscoveryService, discoveryOptions, discoveryQueries, validateDiscoveryFindings, discoveryKeywordMarkdown } from '../lib/market-discovery.mjs';
import { competitorUrl, parseSearchResults, searchCandidates } from '../lib/market-search.mjs';
import { automaticCategory } from '../lib/knowledge-catalog.mjs';
import { validateMarketReport } from '../lib/market-research.mjs';

const text = 'Unified model API with prepaid usage. Input $1 per million tokens. Multi model chat subscriptions cost $12 per month.';
const options = discoveryOptions({ count: 2, lineIds: ['c-api', 'mirror'] });
const queries = [{ query: 'model API prepaid pricing', lineIds: ['c-api'] }, { query: 'multi model chat subscription price', lineIds: ['mirror'] }];
const searches = queries.map((query, index) => ({ ...query, retrievedAt: '2026-10-26', results: [{ url: `https://${index ? 'beta.vendor.net' : 'alpha.vendor.com'}/pricing`, title: index ? 'Beta' : 'Alpha', text }] }));
const candidates = searchCandidates(searches);
const pages = candidates.map(candidate => ({ candidateId: candidate.id, url: candidate.url, text, retrievedAt: '2026-10-26' }));
const findings = {
  competitors: candidates.map(candidate => ({ candidateId: candidate.id, name: candidate.title, lineIds: candidate.lineIds, reason: '提供同类服务，可核对同规格价格', offeringQuote: 'Unified model API with prepaid usage.', priceQuote: 'Input $1 per million tokens.' })),
  keywords: [{ term: 'model API', channel: 'SEO', lineIds: ['c-api'], sourceId: candidates[0].id, evidenceQuote: 'Unified model API with prepaid usage.', intent: '比较 API 平台', contentOpportunity: '用同规格定价表承接' },
    { term: '哪个多模型聊天平台适合轻度使用？', channel: 'GEO', lineIds: ['mirror'], sourceId: candidates[1].id, evidenceQuote: 'Multi model chat subscriptions cost $12 per month.', intent: '向 AI 询问适用方案', contentOpportunity: '提供套餐限制和轻度使用示例' }], notes: [],
};
const until = async condition => { for (let n = 0; n < 200; n++) { if (condition()) return; await new Promise(resolve => setTimeout(resolve, 2)); } assert.fail('discovery did not reach expected phase'); };

test('search envelopes preserve real URLs, deduplicate hosts and exclude every owned business', () => {
  const parsed = parseSearchResults(JSON.stringify({ content: [{ type: 'text', text: 'Title: Alpha\nURL: https://alpha.vendor.com/pricing\nHighlights:\nActual public pricing.' }] }));
  assert.equal(parsed[0].url, 'https://alpha.vendor.com/pricing');
  assert.equal(parsed[0].text, 'Actual public pricing.');
  for (const url of ['https://duoyuanx.com/pricing', 'https://chat.duoyuanx.com/', 'https://zx1.deepwl.net/', 'https://www.makenow.tv/', 'https://docs.octopusx.ai/', 'https://cyapi.ai/pricing', 'https://docs.cyapi.ai/', 'http://127.0.0.1/', 'https://example.com/?token=secret', 'https://reddit.com/r/example']) assert.throws(() => competitorUrl(url));
  const combined = searchCandidates([...searches, { ...searches[0], results: [...searches[0].results, { url: 'https://duoyuanx.com/', title: 'Owned', text }] }]);
  assert.equal(combined.length, 2);
});

test('AI search planning covers the requested business lines without a fixed competitor list', () => {
  const planned = discoveryQueries({ queries: [queries[0]] }, options);
  assert.ok(planned.some(query => query.lineIds.includes('mirror')));
  assert.equal(planned[0].query, queries[0].query);
  assert.throws(() => discoveryOptions({ count: 99 }));
  assert.throws(() => discoveryOptions({ lineIds: [] }));
});

test('findings require page evidence and distinguish observed SEO terms from proposed GEO questions', () => {
  const result = validateDiscoveryFindings(findings, candidates, pages, options);
  assert.equal(result.competitors.length, 2);
  assert.equal(result.keywords[0].evidenceKind, '网页原文');
  assert.equal(result.keywords[1].evidenceKind, '建议词 / 待验证');
  assert.ok(result.keywords.every(keyword => keyword.searchVolume === null && keyword.searchRank === null && keyword.aiCitationRate === null));
  assert.throws(() => validateDiscoveryFindings({ ...findings, competitors: findings.competitors.map(entry => ({ ...entry, offeringQuote: 'invented business claim' })) }, candidates, pages, options));
  const noPrices = validateDiscoveryFindings({ ...findings, competitors: findings.competitors.map(entry => ({ ...entry, priceQuote: 'fabricated price' })) }, candidates, pages, options);
  assert.ok(noPrices.competitors.every(entry => entry.priceStatus === 'needs-check' && !entry.priceEvidence));
  assert.throws(() => validateDiscoveryFindings({ ...findings, keywords: [findings.keywords[0]] }, candidates, pages, options));
});

test('keyword archives and automatic reports both retain SEO and GEO requirements', () => {
  const result = validateDiscoveryFindings(findings, candidates, pages, options);
  const markdown = discoveryKeywordMarkdown({ options, searches, createdAt: '2026-10-26T00:00:00Z' }, result);
  assert.match(markdown, /SEO 搜索词/); assert.match(markdown, /GEO 问题/); assert.match(markdown, /alpha\.vendor/);
  assert.equal(automaticCategory('references/ai-market-research/references/keywords/example.md'), 'market-main');
  const body = 'C 端 API B 端 API 镜像站 MakeNow OctopusX CyAPI https://alpha.vendor.com/pricing\n' + '报价与差异。'.repeat(200);
  assert.throws(() => validateMarketReport(body, pages, [], result), /SEO/);
  assert.doesNotThrow(() => validateMarketReport(body + '\nSEO 关键词\nGEO 问题', pages, [], result));
});

test('zero-URL discovery automatically queues intake and report, locks its model, and survives service restart', async () => {
  const db = new DatabaseSync(':memory:'), jobs = new Map(); let reports = 0, archives = 0;
  const service = new MarketDiscoveryService(db, {
    analyze: async ({ schema }) => schema.properties.queries ? { queries, seedKeywords: ['model API'] } : findings,
    search: async query => searches.find(search => search.query === query).results,
    readPage: async url => ({ url, text, retrievedAt: '2026-10-26' }),
    saveKeywords: async () => { archives++; return { path: 'references/keywords.md' }; },
    createIntakes: data => candidates.map((_, index) => { const job = { id: `intake-${index}`, item_id: `source-${index}`, status: 'queued', analysis_model: data.model }; jobs.set(job.id, job); return job; }),
    createReport: data => { reports++; const job = { id: 'report', status: 'queued', analysis_model: data.model, keywordResearch: data.result }; jobs.set(job.id, job); return job; },
    getJob: id => jobs.get(id),
  });
  const started = service.request(options, { id: 'gpt-6-luna', effort: 'xhigh' });
  assert.equal(service.request(options, { id: 'gpt-6-luna', effort: 'xhigh' }).id, started.id, 'double click created another research batch');
  await until(() => service.get(started.id).status === 'collecting');
  assert.equal(archives, 1); assert.equal(jobs.size, 2);
  for (const job of jobs.values()) job.status = 'completed';
  service.advance(); service.advance();
  assert.equal(reports, 1); assert.equal(service.get(started.id).status, 'reporting');
  assert.equal(jobs.get('report').analysis_model, 'gpt-6-luna');
  jobs.get('report').status = 'failed'; service.advance();
  assert.equal(service.get(started.id).status, 'partial');
  jobs.get('report').status = 'queued'; service.advance();
  assert.equal(service.get(started.id).status, 'reporting');
  assert.equal(service.activeCount(), 1, 'retry stopped automatic progress tracking');
  jobs.get('report').status = 'completed'; service.advance();
  assert.equal(service.public(service.get(started.id)).reportDownloadUrl, '/api/analysis-jobs/report/export.docx');
  assert.equal(service.activeCount(), 0);
  const resumed = new MarketDiscoveryService(db, { getJob: id => jobs.get(id) });
  assert.equal(resumed.list()[0].status, 'completed'); assert.equal(resumed.list()[0].result.keywords.length, 2);
  db.close();
});

test('empty searches fail visibly and cannot invent competitors or create intake tasks', async () => {
  const db = new DatabaseSync(':memory:'); let created = false;
  const service = new MarketDiscoveryService(db, { analyze: async () => ({ queries, seedKeywords: [] }), search: async () => [], createIntakes: () => { created = true; }, getJob: () => null });
  const started = service.request(options, { id: 'gpt-6-luna', effort: 'low' });
  await until(() => service.get(started.id).status === 'failed');
  assert.equal(created, false); assert.match(service.get(started.id).error, /未返回/); db.close();
});
