import { writeFile, mkdir } from 'node:fs/promises';
import { join } from 'node:path';
import assert from 'node:assert/strict';

export async function writeModelFixture(root) {
  const connectionDir=join(root,'data','plugins','ai-connections');await mkdir(connectionDir,{recursive:true});await writeFile(join(connectionDir,'connections.json'),JSON.stringify({version:1,connections:[{id:'fixture',kind:'subscription',provider:'codex',name:'Test Codex',status:'ready',models:['gpt-6-luna','gpt-6-sol']}]}));
  await writeFile(join(root, 'models_cache.json'), JSON.stringify({ fetched_at: new Date().toISOString(), models: [
    { slug: 'gpt-6-luna', display_name: 'Luna', visibility: 'list', default_reasoning_level: 'low', supported_reasoning_levels: [{ effort: 'low' }, { effort: 'xhigh' }], input_modalities: ['text', 'image'] },
    { slug: 'gpt-6-sol', display_name: 'Sol', visibility: 'list', default_reasoning_level: 'low', supported_reasoning_levels: [{ effort: 'low' }, { effort: 'xhigh' }], input_modalities: ['text', 'image'] },
  ] }));
}

export async function selectTestModel(base, model = 'gpt-6-luna') {
  const response = await fetch(`${base}/api/ai/preferences`, { method: 'PUT', headers: { Origin: base, 'Content-Type': 'application/json' }, body: JSON.stringify({ model: model.includes('::')?model:'fixture::'+model }) });
  assert.equal(response.status, 200, await response.text());
}
