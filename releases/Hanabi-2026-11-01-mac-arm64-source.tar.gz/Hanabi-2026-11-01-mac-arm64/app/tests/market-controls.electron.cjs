// Offline UI: real markup/styles, renderers and click handler; no user profile,
// running Hanabi page, personal database or external browser is accessed.
const { app, BrowserWindow } = require('electron');
const { readFileSync, writeFileSync, mkdtempSync, mkdirSync } = require('node:fs');
const { join, resolve } = require('node:path');
const { tmpdir } = require('node:os');
const { pathToFileURL } = require('node:url');
const assert = require('node:assert/strict');
app.disableHardwareAcceleration();
const root = resolve(__dirname, '..'), output = mkdtempSync(join(tmpdir(), 'hanabi-market-ui-'));
for (const key of ['userData', 'sessionData', 'logs']) { const path = join(output, key); mkdirSync(path); app.setPath(key, path); }
const source = readFileSync(join(root, 'app.js'), 'utf8');
const fn = (name, next) => {
  const start = source.search(new RegExp(`(?:^|\\n)(?:async )?function ${name}\\(`));
  const end = source.search(new RegExp(`(?:^|\\n)(?:async )?function ${next}\\(`));
  assert.ok(start >= 0 && end > start); return source.slice(start, end);
};
const click = source.slice(source.indexOf('document.addEventListener("click", async (event) => {'), source.indexOf('document.addEventListener("input", (event) => {'));
const html = readFileSync(join(root, 'index.html'), 'utf8').replace(/<script\b[^>]*>[\s\S]*?<\/script>/g, '').replace(/(href|src)="\/([^\"]*)"/g, (_, attr, path) => `${attr}="${pathToFileURL(join(root, path.split('?')[0])).href}"`);
writeFileSync(join(output, 'fixture.html'), html);
app.whenReady().then(async () => {
  app.dock?.hide();
  const window = new BrowserWindow({ show: false, width: 1400, height: 1000, webPreferences: { offscreen: true, contextIsolation: true } });
  window.webContents.on('console-message', event => { if (/Uncaught|ReferenceError|TypeError/.test(event.message || '')) console.error(event.message); });
  try {
    await window.loadFile(join(output, 'fixture.html'));
    await window.webContents.executeJavaScript(readFileSync(join(root, 'node_modules/marked/lib/marked.umd.js'), 'utf8'));
    await window.webContents.executeJavaScript(readFileSync(join(root, 'node_modules/dompurify/dist/purify.js'), 'utf8'));
    await window.webContents.executeJavaScript(`
      ${readFileSync(join(root,'lib/workbench-presenter.mjs'),'utf8').replace(/^import .*$/gm,'').replace(/export /g,'')}
      window.requireAnalysisModel=async()=>true;
      window.MARKET_PRODUCTS=${JSON.stringify((await import('../lib/market-products.mjs')).MARKET_PRODUCTS)};
      window.$=s=>document.querySelector(s);
      window.$$=s=>[...document.querySelectorAll(s)];
      ${source.slice(source.indexOf('const marketLineLabels ='),source.indexOf('const marketDiscoveryActive ='))}
      window.state={view:'inflow',workJobFilter:'all',expandedJobs:new Map([['j1',true],['j2',true],['11111111-1111-1111-1111-111111111111',true]]),expandedJobDetails:new Map(),aiModels:[],marketDiscoveries:[],aiModel:'gpt-6-luna',items:[],libraryModules:[],correctionDrafts:{},reviewJobIds:new Set(),inflowSelected:new Set(['a','b']),refineSelected:new Set(),outflowSelected:new Set(),analysisJobs:[{id:'j1',itemId:'a',marketResearch:true,marketBatchId:'batch',mode:'intake',status:'completed',result:'公开价目',scope:['text'],destinations:['archive']},{id:'j2',itemId:'b',marketResearch:true,marketBatchId:'batch',mode:'intake',status:'queued',scope:['text'],destinations:['archive']}]};
      window.queueFor=()=>new Set();window.isPendingInflowLink=()=>false;
      window.renderFlowGuide=window.renderAiModelControls=window.renderMarketDiscoveries=window.renderWorkbenchHome=window.renderInflowScope=window.renderInflowCollections=window.renderInflowSamples=window.renderWorkflowModes=window.renderTaskReferences=()=>{};
      window.inflowDestinationLabels={archive:'资料库'};window.inflowScopeOptions=[['text','文字']];
      window.calls=[];window.api=async(path,options)=>{calls.push({path,body:JSON.parse(options.body)});return {jobs:[{id:'report'}]};};
      window.persistFlowQueues=()=>{window.persisted=true;};window.refreshAnalysisJobs=async()=>{};
      window.setView=view=>{state.view=view;renderPlanView();renderAnalysisJobs();};window.showToast=text=>{window.toast=text;};
      ${fn('escapeHtml','safeHttpUrl')}
      ${fn('safeHttpUrl','typeLabel')}
      ${fn('renderAnalysisJobs','renderCard')}
      ${fn('renderPlanView','renderInflowSamples')}
      ${fn('startMarketReport','enqueueAnalysisJobs')}
      ${click}
      document.querySelectorAll('.view-panel').forEach(panel=>{panel.hidden=true;panel.classList.remove('active');});
      $('#view-plan').hidden=false;$('#view-plan').classList.add('active','is-inflow','has-task');
      $('#market-research-preset').hidden=false;
      renderAnalysisJobs();true;
    `);
    assert.equal(await window.webContents.executeJavaScript(`document.querySelectorAll('[data-market-discovery-line]').length`),6);
    assert.equal(await window.webContents.executeJavaScript(`document.querySelector('[data-market-discovery-line=cyapi]').checked`),true);
    const waiting = await window.webContents.executeJavaScript(`(async()=>{document.querySelector('[data-market-report="j1"]').click();await new Promise(r=>setTimeout(r,20));return {blocked:calls.length===0,toast};})()`);
    assert.equal(waiting.blocked, true); assert.match(waiting.toast, /都采火完成/);
    const handoff = await window.webContents.executeJavaScript(`(async()=>{state.analysisJobs[1].status='completed';renderAnalysisJobs();document.querySelector('[data-market-report="j1"]').click();await new Promise(r=>setTimeout(r,30));return {calls,view:state.view,selected:[...state.outflowSelected],persisted};})()`);
    assert.deepEqual(handoff.calls[0].body.itemIds, ['a','b']); assert.equal(handoff.calls[0].path, '/api/market-research/reports'); assert.equal(handoff.view, 'outflow'); assert.equal(handoff.persisted, true);
    const report = await window.webContents.executeJavaScript(`(()=>{state.items=[{id:'saved'}];state.analysisJobs=[{id:'11111111-1111-1111-1111-111111111111',title:'竞品比价 · 五条业务线',mode:'produce',status:'completed',marketResearch:true,marketReport:true,result:'# 报告\\n\\n| 项目 | 价格 |\\n| --- | --- |\\n| 测试 | ¥1 |',uiChanges:[{kind:'knowledge',id:'saved',path:'report.md',title:'报告'}]}];renderPlanView();renderAnalysisJobs();const link=document.querySelector('a[download]');return {href:link.getAttribute('href'),label:link.textContent,table:!!document.querySelector('.production-result table'),pre:!!document.querySelector('.production-result pre'),saved:document.querySelector('[data-archive-output]').disabled,reportMode:$('#production-controls').hidden&&$('#market-research-preset').hidden&&$('#task-platform').closest('.field').hidden};})()`);
    assert.match(report.href, /\/api\/analysis-jobs\/.+\/export\.docx$/); assert.equal(report.label, '下载 Word'); assert.equal(report.table, true); assert.equal(report.pre, false); assert.equal(report.saved, true);
    assert.equal(report.reportMode, true);
    const clipboard = await window.webContents.executeJavaScript(`(async()=>{window.fetch=async()=>new Response('<h1>调研报告</h1><table><tr><td>输入 1；输出 5</td></tr></table>');Object.defineProperty(navigator,'clipboard',{configurable:true,value:{write:async items=>{window.clipboardTypes=items[0].types;}}});document.querySelector('[data-copy-feishu]').click();await new Promise(r=>setTimeout(r,30));return {types:clipboardTypes,toast};})()`);
    assert.deepEqual(clipboard.types,['text/html','text/plain']);assert.match(clipboard.toast,/已复制飞书排版/);
    await window.webContents.executeJavaScript(`$('#view-plan').classList.remove('is-inflow');$('#view-plan').classList.add('is-outflow');$('#analysis-queue-card').hidden=false;$('.task-preview-card').hidden=true;$('#analysis-job-list').scrollIntoView({block:'center'});`);
    const rect = await window.webContents.executeJavaScript(`(()=>{const r=$('#analysis-job-list').getBoundingClientRect();return {x:Math.ceil(r.x),y:Math.max(0,Math.ceil(r.y)),width:Math.floor(r.width),height:Math.min(850,Math.floor(r.height))};})()`);
    await window.webContents.executeJavaScript('new Promise(resolve=>requestAnimationFrame(()=>requestAnimationFrame(resolve)))');
    writeFileSync(join(output, 'report-full.png'), (await window.webContents.capturePage()).toPNG());
    writeFileSync(join(output, 'report-controls.png'), (await window.webContents.capturePage(rect)).toPNG());
    console.log(JSON.stringify({ ok: true, waiting, handoff, report, clipboard, rect, screenshot: join(output, 'report-full.png') }));
    window.destroy(); app.exit(0);
  } catch (error) { console.error(error.stack); window.destroy(); app.exit(1); }
});
