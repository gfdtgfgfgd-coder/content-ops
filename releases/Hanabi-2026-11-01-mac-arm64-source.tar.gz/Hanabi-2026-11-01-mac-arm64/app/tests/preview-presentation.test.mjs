import test from 'node:test';
import assert from 'node:assert/strict';
import { marked } from 'marked';
import { previewItemFromJob, previewPresentation, previewDraftContent } from '../lib/preview-presentation.mjs';
import { preparePreviewMarkdown } from '../lib/preview-layout.mjs';

test('a report retains its type and real title through the preview handoff', () => {
  const item = previewItemFromJob({id:'r',mode:'produce',status:'completed',marketReport:true,title:'竞品比价 · 队列标题',result:'# 价格调研10.22\n\n正文',updatedAt:'now'});
  assert.equal(item.title, '价格调研10.22'); assert.equal(item.reportJobId, 'r'); assert.equal(item.outputFormat,'report');
  assert.deepEqual(previewPresentation(item), {platform:'document',device:'desktop'});
  assert.equal(previewItemFromJob({mode:'intake',parentMode:'intake',status:'completed'}),null);
});

test('preview selection is per work and requires explicit platform metadata', () => {
  assert.deepEqual(previewPresentation({}),{platform:'document',device:'desktop'});
  assert.equal(previewPresentation({platform:'小红书'}).platform,'xiaohongshu');
  assert.equal(previewPresentation({marketReport:true,platform:'小红书'}).platform,'document');
  assert.deepEqual(previewPresentation({marketReport:true},{platform:'custom',device:'phone'}),{platform:'custom',device:'phone'});
  assert.equal(previewPresentation({marketReport:true},{platform:'invalid'}).platform,'document');
});

test('latest generated content replaces automatic old drafts but keeps deliberate edits', () => {
  const item={type:'generated',title:'新标题',content:'新正文'};
  assert.equal(previewDraftContent(item,{title:'旧标题',content:'旧正文'}).content,'新正文');
  assert.equal(previewDraftContent(item,{title:'手改',content:'手改正文',textEdited:true}).content,'手改正文');
  assert.equal(previewDraftContent({title:'资料',content:'资料正文'},{title:'排版',content:'排版正文'}).content,'排版正文');
});

test('Chinese bold delimiters render without changing fenced or inline code', () => {
  const source='- **B 端先把报价讲清。**同一份价格表\n\n`**代码。**保留`\n\n```md\n**代码。**保留\n```';
  const result=marked.parse(preparePreviewMarkdown(source));
  assert.match(result, /<strong>B 端先把报价讲清。<\/strong>/);
  assert.match(result, /<code>\*\*代码。\*\*保留<\/code>/);
  assert.match(result, /\*\*代码。\*\*保留\n<\/code>/);
});
