# Hanabi local operation

## Maintain one application

- Hanabi is intended to ship as an application. Keep its data, job state, persistence, derived lists/counts, navigation, preview and exports connected; verify a full user path when changing one part.
- The top-left Hanabi / 内容工作台 brand opens the chat workbench. Do not add a separate 花火工坊 row. Keep three peer resource entries: 采火 / 资料库, 调配 / 知识档案, 制花 / 燃放预览; each opens only its resource page. Put the model connection plugin at bottom-left. Preserve advanced workflows behind conversation/result actions, all using the original data and validators. Connect and test API or official subscription login before chat; snapshot connection/model on jobs and never silently switch providers.
- The three resource pages manage materials, knowledge and read-only batch platform previews. AI analysis and creation start from chat; bulk material actions and preview corrections compose an editable prompt with exact resource/job IDs, without sending it automatically. Keep the legacy layout/export tools behind their own dialog. Batch choices must wait for both source and production inventories before pruning; review marks are channel- and content-version-specific.
- New windows and application restarts open 内容工作台. A browser refresh resumes the same view, filters, selected document and scroll positions, including nested readers/lists. Use `lib/navigation-session.mjs` and reload-only session state; do not persist a last-active page across new launches. Test a real reload separately from a new navigation.
- Use `lib/resource-inventory.mjs` for archived materials, Skill inventory and preview choices/counts, and `lib/workbench-presenter.mjs` for job stages/statuses. Do not calculate a separate home-page count. Pending links are not archived materials, internal evidence files are not Skills, and preview choices include both completed productions and archived references. Label distinct counts explicitly.
- When changing shared resource/state behavior, run the focused unit checks and `npm run test:application-ui`; exercise intake completion, resource removal, new Skills, completed productions and navigation at desktop/narrow widths.
- Every change to AI behavior must also update the relevant Skill in the same task: model choice/calls, intent understanding, source reading/visual expansion, scope, analysis/prompting, categorization, distillation, research/pricing, report generation and quality/failure rules. Update shared protocols/tools when affected and test the complete path. A frontend toggle that changes AI behavior counts as an AI change.
- Pure typography, colors, spacing, layout or menu changes do not require unrelated Skill edits. Runtime source analyses still need the existing user review/confirmation before distilling new rules; application maintenance authorization does not turn every source or report into a Skill.
- Knowledge filters, move targets, rename/delete dialogs and archive routing must use the same persisted catalog. Retire unchanged legacy storage categories through `lib/knowledge-taxonomy.mjs` redirects; never just hide them in one menu. Preserve customized categories, manual filing, evidence paths and user-edited Skills. Keep internal source-file counts separate from visible documents/Skills; test migration and new archive writes across restart.
- Open knowledge readers revalidate current content without a full page reload. Preserve reading/selection state, leave unchanged DOM intact, and ignore slower responses for documents the user has already left. Shared file responses use conditional requests, not a fixed one-hour stale cache.
- Refinement binds a category and a new/existing archive destination to each job. Corrections/retries preserve that destination; explicit review confirmation can change it. Models are read-only: they propose literal patches or a new body, and `lib/refine-knowledge.mjs` validates versions/paths, backs up and saves only that destination. Read the application's current Skill first; mirror only compatible local patches without replacing independent Codex edits. Run `tests/refine-destination-workflow.test.mjs`, `npm run test:refine-ui` and focused archive-write checks when changing this chain.
- New refinement tasks take their method, scope and optional counts from the single task brief. Do not restore a separate recipe form or silently apply old browser defaults (three sections/five imitations/Xiaohongshu). Keep historical job recipe snapshots intact for compatibility, and test that only the current brief reaches new tasks.
- Preserve user edits while synchronizing the bundled `knowledge/ai-content-alchemy`, installed app knowledge and Codex Skill. The application-maintenance section in the base Skill records this policy. Do not replace entire archives or overwrite unrelated site/model Skills.

- Chat must use real provider text events and native tool calls, followed by a substantive answer after tools settle. Keep one cancellation scope across model, browser/source reads and chat-owned jobs; preserve delivered text, catch create/stop races, and reconnect via SSE without resending messages. Never expose private reasoning or credentials.

## Opening Hanabi

- First run `node scripts/ensure-server.mjs` from this directory. It immediately reuses a healthy service, starts the registered macOS service when needed, and returns the ready URL. Do not navigate to an unavailable URL first.
- Then reuse the existing Hanabi tab and make the browser visible using the supported browser API. Create a tab only when none exists. Do not repeatedly call `open_in_codex` when it returns `queued`; inspect the existing in-app tabs instead.
- Do not open external pricing sites or run research when the user only asks to open Hanabi.

## Deploying local fixes

- The installed background server runs from `~/Library/Application Support/Content Alchemy/runtime/`, not this development checkout. After changing server or frontend files, use `node scripts/install-background-service.mjs` to deploy them. It refuses to interrupt queued or active analysis jobs.
- Preserve the existing library, uploads, Skill archives, and user edits. Do not substitute a temporary database for the live product.
- The service only listens on `127.0.0.1:6187`. Keep that binding and the existing local request checks.
- Use the Node.js 22.13+ runtime already installed on this machine. If `node` is absent from PATH, the Codex bundled runtime is at `~/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/bin/node`.

- Native Feishu document reads use the explicitly authorized, fixed-bundle helper through `feishu_read_current`; never substitute public web scraping or arbitrary application access. Preserve table empty columns and stable pagination snapshots; label loaded content as partial. Keep connector enablement, permission state, UI test and chat tools on the same service.

- Message branches copy a settled prefix and its evidence atomically with new IDs and explicit parent provenance. Do not invoke models or replay tools when branching. Inherited artifact references must never grant cancellation ownership over source-chat jobs; preserve source history and archived state, and test continuation/reload/origin navigation.

- Conversation production must not require capture as a prerequisite. Publish existing content unchanged without another model call; create from scoped conversation context when no library references are selected. Keep internal context out of library/counts, preserve message ownership and job provenance, and test chat → production → platform preview → Word export.

- Repeated effects within a chat turn execute once. All chat production uses content/version identity plus explicit existing-job reuse; reads remain fresh, different inputs/requirements remain distinct, and explicit new versions bypass work deduplication but not request idempotence. Reusing another turn’s job must not transfer cancellation ownership.
