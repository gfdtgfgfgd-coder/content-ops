import AppKit

let size: CGFloat = 1024
let image = NSImage(size: NSSize(width: size, height: size))
image.lockFocus()
NSColor(calibratedRed: 1.0, green: 0.89, blue: 0.94, alpha: 1).setFill()
NSBezierPath(roundedRect: NSRect(x: 12, y: 12, width: size - 24, height: size - 24), xRadius: 208, yRadius: 208).fill()

let window = NSBezierPath(roundedRect: NSRect(x: 116, y: 112, width: 792, height: 794), xRadius: 86, yRadius: 86)
let windowShadow = NSShadow()
windowShadow.shadowColor = NSColor(calibratedRed: 0.56, green: 0.19, blue: 0.39, alpha: 0.22)
windowShadow.shadowBlurRadius = 30
windowShadow.shadowOffset = NSSize(width: 0, height: -14)
windowShadow.set()
NSColor.white.setFill()
window.fill()
NSShadow().set()
NSColor(calibratedRed: 0.64, green: 0.27, blue: 0.44, alpha: 1).setStroke()
window.lineWidth = 18
window.stroke()

let titleBar = NSBezierPath(roundedRect: NSRect(x: 116, y: 738, width: 792, height: 168), xRadius: 82, yRadius: 82)
NSGradient(starting: NSColor(calibratedRed: 1, green: 0.47, blue: 0.68, alpha: 1), ending: NSColor(calibratedRed: 0.94, green: 0.27, blue: 0.55, alpha: 1))!.draw(in: titleBar, angle: 90)
NSColor(calibratedRed: 0.64, green: 0.27, blue: 0.44, alpha: 1).setStroke()
titleBar.lineWidth = 18
titleBar.stroke()
NSColor(calibratedRed: 1, green: 0.89, blue: 0.94, alpha: 1).setFill()
for x in [204.0, 256.0, 308.0] {
    NSBezierPath(ovalIn: NSRect(x: x, y: 796, width: 25, height: 25)).fill()
}

let label = "炼" as NSString
let font = NSFont(name: "PingFangSC-Semibold", size: 358) ?? NSFont.systemFont(ofSize: 358, weight: .bold)
let attributes: [NSAttributedString.Key: Any] = [
    .font: font,
    .foregroundColor: NSColor(calibratedRed: 0.76, green: 0.23, blue: 0.46, alpha: 1),
]
let textSize = label.size(withAttributes: attributes)
label.draw(at: NSPoint(x: (size - textSize.width) / 2, y: 254), withAttributes: attributes)

let sparkle = NSBezierPath()
sparkle.move(to: NSPoint(x: 744, y: 322))
sparkle.line(to: NSPoint(x: 744, y: 398))
sparkle.move(to: NSPoint(x: 706, y: 360))
sparkle.line(to: NSPoint(x: 782, y: 360))
sparkle.move(to: NSPoint(x: 718, y: 334))
sparkle.line(to: NSPoint(x: 770, y: 386))
sparkle.move(to: NSPoint(x: 770, y: 334))
sparkle.line(to: NSPoint(x: 718, y: 386))
NSColor(calibratedRed: 1, green: 0.56, blue: 0.73, alpha: 1).setStroke()
sparkle.lineWidth = 10
sparkle.lineCapStyle = .round
sparkle.stroke()
image.unlockFocus()

guard let tiff = image.tiffRepresentation,
      let bitmap = NSBitmapImageRep(data: tiff),
      let png = bitmap.representation(using: .png, properties: [:]) else {
    fatalError("Could not render icon PNG")
}
try png.write(to: URL(fileURLWithPath: CommandLine.arguments[1]))
