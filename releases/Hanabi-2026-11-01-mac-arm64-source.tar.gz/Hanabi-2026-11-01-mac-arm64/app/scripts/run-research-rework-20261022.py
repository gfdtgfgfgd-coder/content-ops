import urllib.request,json,pathlib
base='http://127.0.0.1:6187'
def call(path,body=None):
 data=None if body is None else json.dumps(body).encode(); req=urllib.request.Request(base+path,data=data,headers={'Content-Type':'application/json','Origin':base});return json.load(urllib.request.urlopen(req,timeout=40))
items=[]
for title,url in [('灵眸 AI · 10.22 复核','https://api.lmuai.ai/models/openai/gpt-6-1-sol'),('PackyAPI · 10.22 复核','https://www.packyapi.com/pricing')]:
 items.append(call('/api/items',{'title':title,'type':'text','sourceUrl':url,'content':'','sourceName':title}))
x=call('/api/analysis-jobs',{'mode':'intake','marketResearch':True,'itemIds':[i['id'] for i in items],'scope':['text'],'moduleIds':[],'brief':'提取模型具体报价、计费分组、充值与套餐条件；结果归档知识档案市场调研分类，供五条业务线量化比价。先看现价，再核对可见说明，不写无关功能。'})
pathlib.Path('../outputs/hanabi-rework-20261022/live-run.json').write_text(json.dumps({'items':items,'intakeJobs':x['jobs']},ensure_ascii=False,indent=2));print(json.dumps({'items':[i['id'] for i in items],'jobs':[(j['id'],j['status']) for j in x['jobs']]}))
