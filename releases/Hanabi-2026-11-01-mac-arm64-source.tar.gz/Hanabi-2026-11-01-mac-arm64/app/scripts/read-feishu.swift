import AppKit
import ApplicationServices
import Foundation

// Deliberately no app argument, AX actions, clipboard, browser profile or disk discovery.
// This process only reads the front document in the running Feishu application.
final class DocumentReader: NSObject, NSApplicationDelegate {
  var output: URL?
  var nodes = 0
  var limited = false
  var deadline = Date()
  func attr(_ el: AXUIElement, _ key: String) -> CFTypeRef? {
    var value: CFTypeRef?
    return AXUIElementCopyAttributeValue(el, key as CFString, &value) == .success ? value : nil
  }
  func string(_ el: AXUIElement, _ key: String) -> String { attr(el, key) as? String ?? "" }
  func children(_ el: AXUIElement) -> [AXUIElement] { attr(el, kAXChildrenAttribute) as? [AXUIElement] ?? [] }
  func visit(_ el: AXUIElement, depth: Int = 0, _ body: (AXUIElement) -> Bool) {
    if depth > 45 || nodes >= 30000 || Date() > deadline { limited = true; return }
    nodes += 1
    if body(el) { return }
    for child in children(el) { visit(child, depth: depth + 1, body) }
  }
  func position(_ el: AXUIElement) -> Double? {
    guard let raw = attr(el, kAXPositionAttribute), CFGetTypeID(raw) == AXValueGetTypeID() else { return nil }
    var point = CGPoint.zero
    guard AXValueGetValue(unsafeBitCast(raw, to: AXValue.self), .cgPoint, &point) else { return nil }
    return Double(point.x)
  }
  func value(_ el: AXUIElement) -> String {
    let own = string(el, kAXValueAttribute)
    if !own.isEmpty { return own }
    var parts: [String] = []
    for child in children(el) { let text = value(child); if !text.isEmpty { parts.append(text) } }
    return parts.joined(separator: "\n")
  }
  func finish(_ data: [String: Any]) {
    if let output, let bytes = try? JSONSerialization.data(withJSONObject: data) { try? bytes.write(to: output, options: .atomic) }
    NSApp.terminate(nil)
  }
  func applicationDidFinishLaunching(_ notification: Notification) {
    let args = Array(CommandLine.arguments.dropFirst())
    guard args.count == 2, ["status", "authorize", "read"].contains(args[0]) else { NSApp.terminate(nil); return }
    output = URL(fileURLWithPath: args[1])
    let mode = args[0]
    let trusted = mode == "authorize"
      ? AXIsProcessTrustedWithOptions([kAXTrustedCheckOptionPrompt.takeUnretainedValue() as String: true] as CFDictionary)
      : AXIsProcessTrusted()
    guard trusted else { finish(["status":"permission-required", "message":"请在系统设置 → 隐私与安全性 → 辅助功能中，开启 Hanabi 文档读取。"]); return }
    if mode != "read" { finish(["status":"ready", "message":"已获授权；只读取飞书当前文档。"]); return }
    guard let app = NSRunningApplication.runningApplications(withBundleIdentifier: "com.bytedance.macos.feishu").first else {
      finish(["status":"app-not-running", "message":"请先在这台电脑打开飞书和要读取的文档。"]); return
    }
    deadline = Date().addingTimeInterval(18)
    let application = AXUIElementCreateApplication(app.processIdentifier)
    AXUIElementSetMessagingTimeout(application, 1)
    // Enable the application's accessibility tree, without navigating or editing it.
    AXUIElementSetAttributeValue(application, "AXManualAccessibility" as CFString, kCFBooleanTrue)
    let windows = attr(application, kAXWindowsAttribute) as? [AXUIElement] ?? []
    let focused = attr(application, kAXFocusedWindowAttribute)
    let window = focused.flatMap { CFGetTypeID($0) == AXUIElementGetTypeID() ? unsafeBitCast($0, to: AXUIElement.self) : nil } ?? windows.first
    guard let window else { finish(["status":"no-document", "message":"飞书没有可读取的文档窗口。"]); return }
    var web: AXUIElement?
    var documentURL = ""
    visit(window) { el in
      if self.string(el, kAXRoleAttribute) == "AXWebArea" {
        let raw = self.attr(el, kAXURLAttribute)
        let url = (raw as? URL)?.absoluteString ?? (raw as? String ?? "")
        if let parsed = URL(string: url), let host = parsed.host,
          (host.hasSuffix(".feishu.cn") || host.hasSuffix(".larksuite.com")),
          (parsed.path.hasPrefix("/wiki/") || parsed.path.hasPrefix("/docx/") || parsed.path.hasPrefix("/docs/")), web == nil {
          web = el; documentURL = url
        }
        return true
      }
      return web != nil
    }
    guard let web else { finish(["status":"no-document", "message":"请把要读的飞书云文档显示在当前窗口，再重试读取。"]); return }
    // The document editor exposes a large AXTextArea. Navigation and account UI stay outside it.
    var body: AXUIElement?
    var bodyText = ""
    visit(web) { el in
      if self.string(el, kAXRoleAttribute) == "AXTextArea" {
        let text = self.string(el, kAXValueAttribute)
        if text.count > bodyText.count { body = el; bodyText = text }
      }
      return false
    }
    guard let body, !bodyText.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty else {
      finish(["status":"no-content", "message":"当前文档尚未暴露正文。请在飞书中点一下正文，等待加载后重试。"]); return
    }
    var tables: [[String: Any]] = []
    visit(body) { el in
      guard self.string(el, kAXRoleAttribute) == "AXTable" else { return false }
      var rows: [[String: Any]] = []
      self.visit(el) { row in
        guard self.string(row, kAXRoleAttribute) == "AXRow" else { return false }
        var cells: [[String: Any]] = []
        // Feishu exposes cells as direct AXTextAreas, including multi-line cell values.
        for cell in self.children(row) {
          let text = self.value(cell)
          var record: [String: Any] = ["text":text]
          if let x = self.position(cell) { record["x"] = x }
          cells.append(record)
        }
        if !cells.isEmpty { rows.append(["cells":cells]) }
        return true
      }
      if !rows.isEmpty { tables.append(["rows":rows]) }
      return true
    }
    let title = string(web, kAXTitleAttribute).replacingOccurrences(of: " - 飞书云文档", with: "")
    finish(["status":"ready", "title":title, "url":documentURL, "text":String(bodyText.prefix(500000)),
      "tables":tables, "coverage":["scope":"current-loaded-document", "complete":false,
      "limited":limited || bodyText.count > 500000,
      "note":"仅包含飞书当前文档已加载的可访问正文；不代表整份文档或嵌套文档已读完。"]])
  }
}

@main struct HanabiDocumentReader {
  static func main() {
    let app = NSApplication.shared
    app.setActivationPolicy(.accessory)
    let delegate = DocumentReader()
    app.delegate = delegate
    app.run()
  }
}
