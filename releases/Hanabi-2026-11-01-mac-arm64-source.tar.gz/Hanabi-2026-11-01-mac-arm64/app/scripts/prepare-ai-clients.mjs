import {readdir,chmod,access}from'node:fs/promises';
import {join,dirname}from'node:path';import{fileURLToPath}from'node:url';
const root=dirname(dirname(fileURLToPath(import.meta.url))),pty=join(root,'node_modules/node-pty');
// node-pty's registry tarball can lose the executable bit on spawn-helper.
// Preserve it before packaging/copying; no login or network calls at install.
for(const directory of [join(pty,'build/Release'),...(await readdir(join(pty,'prebuilds')).catch(()=>[])).map(name=>join(pty,'prebuilds',name))]){
  const helper=join(directory,'spawn-helper');try{await access(helper);await chmod(helper,0o755);}catch(error){if(error.code!=='ENOENT')throw error;}
}
