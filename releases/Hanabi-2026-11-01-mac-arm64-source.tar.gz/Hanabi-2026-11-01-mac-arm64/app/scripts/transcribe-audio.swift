import AppKit
import Foundation
import Speech

struct TranscriptionResult: Codable {
  let status: String
  let transcript: String?
  let error: String?
}

final class TranscriptionAppDelegate: NSObject, NSApplicationDelegate {
  private var outputURL: URL?
  private var recognitionTask: SFSpeechRecognitionTask?
  private var finished = false

  func applicationDidFinishLaunching(_ notification: Notification) {
    NSApp.activate(ignoringOtherApps: true)
    let arguments = Array(CommandLine.arguments.dropFirst())
    guard arguments.count >= 2 else {
      finish(TranscriptionResult(status: "failed", transcript: nil, error: "需要音频路径和结果文件路径"))
      return
    }
    let audioURL = URL(fileURLWithPath: arguments[0])
    outputURL = URL(fileURLWithPath: arguments[1])

    SFSpeechRecognizer.requestAuthorization { status in
      DispatchQueue.main.async {
        guard status == .authorized else {
          self.finish(TranscriptionResult(status: "not-authorized", transcript: nil, error: "macOS 未授权语音识别"))
          return
        }
        self.startTranscription(audioURL)
      }
    }
  }

  private func startTranscription(_ audioURL: URL) {
    guard let recognizer = SFSpeechRecognizer(locale: Locale(identifier: "zh-CN")), recognizer.isAvailable else {
      finish(TranscriptionResult(status: "unavailable", transcript: nil, error: "系统中文语音识别器当前不可用"))
      return
    }
    guard recognizer.supportsOnDeviceRecognition else {
      finish(TranscriptionResult(status: "unavailable", transcript: nil, error: "系统中文语音识别器不支持本机离线识别"))
      return
    }

    let request = SFSpeechURLRecognitionRequest(url: audioURL)
    request.requiresOnDeviceRecognition = true
    request.shouldReportPartialResults = false
    recognitionTask = recognizer.recognitionTask(with: request) { result, error in
      if let error {
        self.finish(TranscriptionResult(status: "failed", transcript: nil, error: error.localizedDescription))
        return
      }
      guard let result, result.isFinal else { return }
      let text = result.bestTranscription.formattedString.trimmingCharacters(in: .whitespacesAndNewlines)
      self.finish(TranscriptionResult(status: "transcribed", transcript: text, error: nil))
    }
    DispatchQueue.main.asyncAfter(deadline: .now() + 240) {
      self.finish(TranscriptionResult(status: "transcription-timeout", transcript: nil, error: "本机语音转写超时"))
    }
  }

  private func finish(_ result: TranscriptionResult) {
    guard !finished else { return }
    finished = true
    if let outputURL, let data = try? JSONEncoder().encode(result) {
      try? data.write(to: outputURL, options: .atomic)
    }
    DispatchQueue.main.async { NSApp.terminate(nil) }
  }
}

@main
struct ContentAlchemySpeechHelper {
  static func main() {
    let application = NSApplication.shared
    application.setActivationPolicy(.accessory)
    let delegate = TranscriptionAppDelegate()
    application.delegate = delegate
    application.run()
  }
}
