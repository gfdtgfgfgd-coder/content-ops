import pathlib,sqlite3,subprocess,os,signal,time,json
root=pathlib.Path('/Users/lilith/Library/Application Support/Content Alchemy')
repo=pathlib.Path.cwd();knowledge=root/'knowledge/ai-content-alchemy/references/ai-market-research'
backup=root/'backups/research-rework-20261022';backup.mkdir(parents=True,exist_ok=True)
src=sqlite3.connect(root/'library.sqlite')
if not (backup/'library-before.sqlite').exists():
 dest=sqlite3.connect(backup/'library-before.sqlite');src.backup(dest);dest.close()
active=src.execute("SELECT id,status FROM analysis_jobs WHERE status IN ('queued','analyzing','committing','commit_queued')").fetchall();src.close()
if active:raise SystemExit('Active jobs; deploy postponed: '+str(active))
for name in ['SKILL.md','references/调研报告写作风格.md']:
 p=knowledge/name
 if p.exists() and not (backup/p.name).exists():(backup/p.name).write_bytes(p.read_bytes())
(knowledge/'references/调研报告写作风格.md').write_text((repo/'docs/market-research-writing.md').read_text())
p=knowledge/'SKILL.md';text=p.read_text();note='''\n## 用户报告风格与归档（2026-10-22修订）\n\n输出内部市场调研时先读[调研报告写作风格](references/调研报告写作风格.md)，以原报告的业务线/站点表格为骨架，补充场景成本、百分比和经营判断。至少三项可复算发现；不要用数据缺口说明替代分析。历史原表与现价分开，缓存占比和额度利用率需要时给临界点。竞品事实、报告成品直接归知识档案市场调研分类；资料库保留普通创作素材。\n'''
if '用户报告风格与归档（2026-10-22修订）' not in text:p.write_text(text+note)
# Stop only the verified existing Hanabi listener, not a general Node process.
result=subprocess.run(['/usr/sbin/lsof','-tiTCP:6187','-sTCP:LISTEN'],capture_output=True,text=True)
for raw in result.stdout.split():
 pid=int(raw);cmd=subprocess.run(['/bin/ps','-p',str(pid),'-o','command='],capture_output=True,text=True).stdout
 if 'node' not in cmd or 'server.mjs' not in cmd:raise SystemExit('Unexpected listener: '+cmd)
 os.kill(pid,signal.SIGTERM)
time.sleep(0.5)
node='/Users/lilith/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/bin/node'
log=open(root/'hanabi-server.log','ab',buffering=0)
child=subprocess.Popen([node,'server.mjs'],cwd=repo,stdin=subprocess.DEVNULL,stdout=log,stderr=log,start_new_session=True,close_fds=True)
print(json.dumps({'pid':child.pid,'databaseBackup':str(backup/'library-before.sqlite'),'guide':str(knowledge/'references/调研报告写作风格.md')}))
