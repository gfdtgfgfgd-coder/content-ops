// Synchronize only the user-confirmed application-maintenance section.
// Other facts, examples and Skills remain owned by their existing archives.
import {readFile,writeFile,mkdir,copyFile} from 'node:fs/promises';
import {join,resolve} from 'node:path';
import {fileURLToPath} from 'node:url';
import {createHash} from 'node:crypto';

const args=process.argv.slice(2),values=key=>args.flatMap((value,index)=>value===key?[args[index+1]]:[]);
const backup=values('--backup')[0],roots=values('--root');
if(!backup||!roots.length)throw Error('Provide --backup and one or more --root paths.');
const repository=resolve(fileURLToPath(new URL('..',import.meta.url)));
const source=await readFile(join(repository,'knowledge/ai-content-alchemy/SKILL.md'),'utf8');
const heading='## Hanabi 应用维护与 AI 规则同步（用户确认）';
const sectionPattern=/^## Hanabi 应用维护与 AI 规则同步（用户确认）\n[\s\S]*?(?=^## |$(?![\s\S]))/m;
const section=source.match(sectionPattern)?.[0]?.trimEnd();
if(!section)throw Error('Source Skill is missing the maintenance contract.');
const plans=[];
for(const root of roots){
 const path=join(root,'SKILL.md'),before=await readFile(path,'utf8'),existing=before.match(sectionPattern)?.[0]?.trimEnd();
 if(existing&&existing!==section)throw Error('维护规则已有独立修改，请先合并用户修改：'+path);
 const index=before.search(/^## /m);
 const after=existing?before:before.slice(0,index<0?before.length:index)+section+'\n\n'+before.slice(index<0?before.length:index);
 if(!after.includes(heading))throw Error('Skill section insertion failed.');
 plans.push({root,path,before,after});
}
await mkdir(backup,{recursive:true});
const hash=text=>createHash('sha256').update(text).digest('hex');
for(const[index,plan]of plans.entries()){
 await copyFile(plan.path,join(backup,`skill-${index}-before.md`));
 if(plan.after!==plan.before)await writeFile(plan.path,plan.after);
}
const result={section:heading,roots:plans.map(plan=>({root:plan.root,changed:plan.after!==plan.before,beforeSha256:hash(plan.before),afterSha256:hash(plan.after)}))};
await writeFile(join(backup,'skill-sync.json'),JSON.stringify(result,null,2));
console.log(JSON.stringify(result,null,2));
