import Foundation
import Vision
import ImageIO

struct ImageText: Codable { let text: String }
var output: [ImageText] = []
do {
  for path in CommandLine.arguments.dropFirst() {
    let url = URL(fileURLWithPath: path)
    guard let source = CGImageSourceCreateWithURL(url as CFURL, nil), let image = CGImageSourceCreateImageAtIndex(source, 0, nil) else {
      throw NSError(domain: "HanabiImageOCR", code: 1, userInfo: [NSLocalizedDescriptionKey: "图片无法解码：\(url.lastPathComponent)"])
    }
    let request = VNRecognizeTextRequest()
    request.recognitionLevel = .accurate
    request.recognitionLanguages = ["zh-Hans", "en-US"]
    request.usesLanguageCorrection = false
    try VNImageRequestHandler(cgImage: image).perform([request])
    output.append(ImageText(text: (request.results ?? []).compactMap { $0.topCandidates(1).first?.string }.joined(separator: "\n")))
  }
  FileHandle.standardOutput.write(try JSONEncoder().encode(output))
} catch {
  FileHandle.standardError.write(Data(error.localizedDescription.utf8))
  exit(1)
}
