import { DatabaseSync } from "node:sqlite";
import { copyFile, mkdir, rm, writeFile, cp } from "node:fs/promises";
import { existsSync } from "node:fs";
import { homedir } from "node:os";
import { dirname, extname, join } from "node:path";
import { fileURLToPath } from "node:url";

const root = dirname(dirname(fileURLToPath(import.meta.url)));
const sourceDirectory = process.env.CONTENT_ALCHEMY_DATA_DIR || join(homedir(), "Library", "Application Support", "Content Alchemy");
const sourceDatabase = join(sourceDirectory, "library.sqlite");
const seedDirectory = join(root, ".transfer-seed");
const seedUploads = join(seedDirectory, "uploads");
const seedKnowledge = join(seedDirectory, "knowledge", "ai-content-alchemy");
const extensionByMime = new Map([
  ["image/jpeg", ".jpg"], ["image/png", ".png"], ["image/webp", ".webp"], ["image/gif", ".gif"], ["image/avif", ".avif"],
  ["video/mp4", ".mp4"], ["video/quicktime", ".mov"], ["video/webm", ".webm"],
  ["audio/mpeg", ".mp3"], ["audio/mp4", ".m4a"], ["audio/wav", ".wav"], ["audio/x-wav", ".wav"], ["audio/ogg", ".ogg"],
  ["text/plain", ".txt"], ["text/markdown", ".md"], ["application/pdf", ".pdf"],
  ["application/vnd.openxmlformats-officedocument.wordprocessingml.document", ".docx"],
]);

await rm(seedDirectory, { recursive: true, force: true });
await mkdir(seedUploads, { recursive: true });
const savedKnowledge = join(sourceDirectory, "knowledge", "ai-content-alchemy");
const bundledKnowledge = join(root, "knowledge", "ai-content-alchemy");
await cp(existsSync(savedKnowledge) ? savedKnowledge : bundledKnowledge, seedKnowledge, {
  recursive: true,
  filter: (path) => !["node_modules", ".git", ".DS_Store"].includes(path.split(/[\\/]/).at(-1)),
});

let itemCount = 0;
let attachmentCount = 0;
if (existsSync(sourceDatabase)) {
  const source = new DatabaseSync(sourceDatabase);
  const rows = source.prepare("SELECT * FROM items ORDER BY created_at").all();
  const snapshotPath = join(seedDirectory, "library.sqlite");
  source.exec(`VACUUM INTO '${snapshotPath.replaceAll("'", "''")}'`);
  source.close();
  itemCount = rows.length;

  for (const row of rows) {
    let attachments = [];
    let mediaFrames = [];
    try { attachments = JSON.parse(row.attachments || "[]"); } catch { /* Keep the database row; malformed attachment metadata is ignored. */ }
    try { mediaFrames = JSON.parse(row.media_frames || "[]"); } catch { /* Keep the database row; malformed frame metadata is ignored. */ }
    for (const attachment of [...attachments, ...mediaFrames]) {
      const extension = extensionByMime.get(attachment.mimeType) || extname(attachment.name || "") || ".bin";
      const sourcePath = join(sourceDirectory, "uploads", `${attachment.id}${extension}`);
      if (!existsSync(sourcePath)) continue;
      await copyFile(sourcePath, join(seedUploads, `${attachment.id}${extension}`));
      attachmentCount += 1;
    }
  }
}

const manifest = {
  format: "content-alchemy-transfer-seed",
  version: 1,
  packedAt: new Date().toISOString(),
  itemCount,
  attachmentCount,
};
await writeFile(join(seedDirectory, "manifest.json"), `${JSON.stringify(manifest, null, 2)}\n`, { mode: 0o600 });
console.log(`Prepared automatic transfer: ${itemCount} library items, ${attachmentCount} attachments.`);
