"""Apply an explicitly reviewed plan with optimistic checks and a full backup."""
import sqlite3,json,hashlib,datetime,shutil,re
from pathlib import Path
import argparse
p=argparse.ArgumentParser();p.add_argument('--data',required=True);p.add_argument('--plan',required=True);p.add_argument('--style',required=True);p.add_argument('--skill-root',action='append',default=[]);a=p.parse_args()
root=Path(a.data);plan=json.loads(Path(a.plan).read_text());db=sqlite3.connect(root/'library.sqlite');db.row_factory=sqlite3.Row
if db.execute("select count(*) from analysis_jobs where status in ('queued','analyzing','commit_queued','committing')").fetchone()[0]:raise SystemExit('有任务正在运行，未修改资料。')
rows={x['id']:dict(x) for x in db.execute('select * from items')}
for x in plan['changes']:
 if x['id'] not in rows or rows[x['id']]['archive_space']!='library' or rows[x['id']]['content']!=x['before']:raise SystemExit('资料已被编辑，未覆盖：'+x['title'])
if rows[plan['referenceId']]['content']!=plan['referenceContent']:raise SystemExit('用户范例发生变化，未执行旧修改稿。')
stamp=datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%dT%H%M%SZ');backup=root/'backups'/('readable-material-'+stamp);backup.mkdir(parents=True)
with sqlite3.connect(backup/'library.sqlite') as copy:db.backup(copy)
shutil.copyfile(a.plan,backup/'reviewed-plan.json')
style=Path(a.style).read_text();section='''## 资料正文整理偏好（用户确认）

用户指定《拥有这四类爱好，让人生游刃有余》的手改版为采火资料范例。普通口播、观点和文案直接整理为按意思分段的正文，保留原文信息与语气，不先写摘要再重复贴字幕；去掉 SRT 序号、无用时码和处理日志。剪辑、广告切入、起承转合、操作或待核对证据才保留关键时间点；价格日期、版本和原始证据不因此删除。具体学习任务仍须回答其要求，不把分析一律变成转录。保存正文前按[资料正文整理规则](references/readable-material.md)执行。

'''
written=[]
for index,raw in enumerate(a.skill_root):
 sr=Path(raw);main=sr/'SKILL.md'
 if not main.is_file():continue
 body=main.read_text();saved=backup/('skill-'+str(index));saved.mkdir();shutil.copyfile(main,saved/'SKILL.md')
 ref=sr/'references/readable-material.md';ref.parent.mkdir(parents=True,exist_ok=True)
 if ref.exists():shutil.copyfile(ref,saved/'readable-material.md')
 ref.write_text(style)
 if '## 资料正文整理偏好（用户确认）' not in body:
  boundary=re.search(r'^## (?:在|基本质量|不变的质量)',body,re.M)
  pos=boundary.start() if boundary else len(body);body=body[:pos]+section+body[pos:];main.write_text(body)
 written.append(str(main))
now=datetime.datetime.now(datetime.timezone.utc).isoformat(timespec='milliseconds').replace('+00:00','Z')
try:
 db.execute('BEGIN IMMEDIATE')
 for x in plan['changes']:
  cur=db.execute('update items set content=?,updated_at=? where id=? and content=?',(x['content'],now,x['id'],x['before']))
  if cur.rowcount!=1:raise RuntimeError('资料在应用时被编辑，全部回滚：'+x['title'])
 db.commit()
except:db.rollback();raise
# Check every protected field, including all media, collections, names and URLs.
after={x['id']:dict(x) for x in db.execute('select * from items')};changed={x['id'] for x in plan['changes']}
assert set(rows)==set(after)
for key,old in rows.items():
 for field,value in old.items():
  if key in changed and field in ('content','updated_at'):continue
  assert after[key][field]==value,(key,field)
assert after[plan['referenceId']]['content']==plan['referenceContent']
result={'reviewed':plan['reviewed'],'changed':len(changed),'referencePreserved':True,'allMediaAndCollectionsPreserved':True,'otherArchivesUnchanged':True,'backup':str(backup),'skills':written,'updatedAt':now}
(backup/'validation.json').write_text(json.dumps(result,ensure_ascii=False,indent=2));Path('/tmp/hanabi-readable-applied.json').write_text(json.dumps(result,ensure_ascii=False,indent=2));print(json.dumps(result,ensure_ascii=False,indent=2))
