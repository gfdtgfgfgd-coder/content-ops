import { DatabaseSync, backup } from 'node:sqlite';
import { readFile, writeFile, mkdir, copyFile } from 'node:fs/promises';
import { join } from 'node:path';
import { CollectionRedirects } from '../../lib/library-collections.mjs';

const args = process.argv.slice(2);
const values = key => args.flatMap((value,index) => value === key ? [args[index+1]] : []);
const data = values('--data')[0], planPath = values('--plan')[0];
if (!data || !planPath) throw Error('Provide --data and --plan; --skill-root can be repeated.');
const liveUrl = values('--live-url')[0];
if (liveUrl) {
  for (const [path,key] of [['/api/analysis-jobs','jobs'],['/api/intake/interpretations','activeCount'],['/api/market-research/discoveries','activeCount']]) {
    const response = await fetch(liveUrl+path);
    if (!response.ok) throw Error('无法核对运行状态，未修改集合。');
    const payload = await response.json();
    if (key === 'jobs' ? payload.jobs.some(job=>['queued','analyzing','commit_queued','committing'].includes(job.status)) : payload[key] > 0) throw Error('还有任务运行中，未修改集合。');
  }
}
const plan = JSON.parse(await readFile(planPath,'utf8'));
const db = new DatabaseSync(join(data,'library.sqlite'));
if (db.prepare("SELECT count(*) n FROM analysis_jobs WHERE status IN ('queued','analyzing','commit_queued','committing')").get().n) throw Error('有分析任务运行中。');
const before = db.prepare('SELECT * FROM items ORDER BY id').all();
const modules = db.prepare('SELECT * FROM library_modules ORDER BY id').all();
if (JSON.stringify(modules.map(row=>row.id)) !== JSON.stringify(plan.expectedModules.map(row=>row.id).sort())) throw Error('集合清单变化，需重新检查。');
for (const expected of plan.expectedModules) {
  const row = modules.find(row=>row.id===expected.id);
  for (const key of ['name','view_key','description','fields_json','previous_names_json']) if(row[key]!==expected[key]) throw Error('集合已被编辑：'+expected.name);
}
for(const expected of plan.expectedMemberships) {
  const row=before.find(row=>row.id===expected.id);
  if(!row || row.module_ids!==expected.module_ids || row.module_values!==expected.module_values) throw Error('资料归类已变化：'+expected.id);
}
const stamp=new Date().toISOString().replace(/[-:.]/g,'');
const backupPath=join(data,'backups','broad-collections-'+stamp);
await mkdir(backupPath,{recursive:true}); await backup(db,join(backupPath,'library.sqlite'));
await copyFile(planPath,join(backupPath,'reviewed-plan.json'));
const sourceMain=await readFile(new URL('../../knowledge/ai-content-alchemy/SKILL.md',import.meta.url),'utf8');
const section=sourceMain.match(/## 集合归类偏好（用户确认）[\s\S]*?(?=\n## )/)?.[0];
if(!section) throw Error('缺少归类 Skill 规则。');
const reference=await readFile(new URL('../../docs/material-style/collection-classification.md',import.meta.url),'utf8');
const skillChanges=[];
for (const [index,root] of values('--skill-root').entries()) {
  const main=join(root,'SKILL.md'), old=await readFile(main,'utf8');
  await copyFile(main,join(backupPath,`skill-${index}-before.md`));
  const next=old.includes('## 集合归类偏好（用户确认）') ? old.replace(/## 集合归类偏好（用户确认）[\s\S]*?(?=\n## |$)/,section+'\n') : old.replace(/(?=## 在工作台中操作|## 不变的质量|## 基本质量规则)/,section+'\n\n');
  if(!next.includes(section)) throw Error('Skill 没有找到插入位置：'+root);
  skillChanges.push({main,next,ref:join(root,'references','collection-classification.md')});
}
new CollectionRedirects(db).consolidate(plan.groups,plan.assignments);
const after=db.prepare('SELECT * FROM items ORDER BY id').all();
if(before.length!==after.length)throw Error('资料数量异常。');
for(let i=0;i<before.length;i++) for(const key of Object.keys(before[i])) {
  if(['module_ids','module_values'].includes(key))continue;
  if(before[i][key]!==after[i][key])throw Error('资料被意外修改：'+key);
}
const active=db.prepare('SELECT id,name FROM library_modules').all();
const counts=Object.fromEntries(active.map(module=>[module.name,after.filter(row=>row.archive_space==='library' && JSON.parse(row.module_ids).includes(module.id)).length]));
if(JSON.stringify(Object.entries(counts).sort())!==JSON.stringify(Object.entries(plan.counts).sort()))throw Error('分类数量与审核方案不符。');
for(const change of skillChanges) {
  await writeFile(change.main,change.next); await writeFile(change.ref,reference);
}
const result={beforeCollections:modules.length,afterCollections:active.length,libraryItems:after.filter(row=>row.archive_space==='library').length,counts,allBodiesSourcesTagsAndMediaUnchanged:true,knowledgeItemsUnchanged:true,backup:backupPath,skills:skillChanges.map(change=>change.main)};
await writeFile(join(backupPath,'validation.json'),JSON.stringify(result,null,2));
console.log(JSON.stringify(result,null,2));db.close();
