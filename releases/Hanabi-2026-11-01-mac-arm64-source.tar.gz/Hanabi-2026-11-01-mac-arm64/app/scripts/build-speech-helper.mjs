import { execFileSync } from "node:child_process";
import { chmod, copyFile, mkdir, rm } from "node:fs/promises";
import { dirname, join } from "node:path";
import { fileURLToPath } from "node:url";

const root = dirname(dirname(fileURLToPath(import.meta.url)));
const app = join(root, ".build", "ContentAlchemySpeech.app");
const contents = join(app, "Contents");
const executable = join(contents, "MacOS", "ContentAlchemySpeech");

if (process.platform !== "darwin") {
  console.log("Skipping the macOS speech helper on this platform.");
  process.exit(0);
}

await rm(app, { recursive: true, force: true });
await mkdir(join(contents, "MacOS"), { recursive: true });
execFileSync("/usr/bin/swiftc", [
  "-O",
  "-parse-as-library",
  "-framework", "AppKit",
  "-framework", "Speech",
  join(root, "scripts", "transcribe-audio.swift"),
  "-o", executable,
], { stdio: "inherit" });
await chmod(executable, 0o755);
await copyFile(join(root, "scripts", "speech-helper-Info.plist"), join(contents, "Info.plist"));
execFileSync("/usr/bin/codesign", ["--force", "--sign", "-", app], { stdio: "inherit" });
console.log(`Built ${app}`);
