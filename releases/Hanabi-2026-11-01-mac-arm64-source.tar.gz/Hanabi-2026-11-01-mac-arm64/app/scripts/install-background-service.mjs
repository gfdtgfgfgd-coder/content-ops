import { execFile } from 'node:child_process';
import { promisify } from 'node:util';
import { mkdir, writeFile, readFile, cp, rename } from 'node:fs/promises';
import { existsSync } from 'node:fs';
import { homedir } from 'node:os';
import { dirname, join } from 'node:path';
import { fileURLToPath } from 'node:url';
import { isReady, waitUntilReady, localUrl } from './ensure-server.mjs';

const exec = promisify(execFile);
const root = dirname(dirname(fileURLToPath(import.meta.url)));
const label = 'com.lilith.hanabi.server';
const domain = `gui/${process.getuid()}`;
const agentPath = join(homedir(), 'Library', 'LaunchAgents', `${label}.plist`);
const data = join(homedir(), 'Library', 'Application Support', 'Content Alchemy');
const logs = join(data, 'logs');
const runtime = join(data, 'runtime');
const xml = value => String(value).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&apos;' }[c]));

if (process.platform !== 'darwin') throw new Error('后台服务安装仅适用于 macOS。');
if (await isReady()) {
  const chatResponse=await fetch(`${localUrl}/api/chats`);
  if(chatResponse.ok&&(await chatResponse.json()).activeCount>0)throw new Error('对话仍在运行，请完成或停止后再部署。');
  const response = await fetch(`${localUrl}/api/analysis-jobs`);
  if (!response.ok) throw new Error('无法确认任务状态，未重启后台服务。');
  const { jobs } = await response.json();
  if (jobs.some(job => ['queued', 'analyzing', 'commit_queued', 'committing'].includes(job.status))) throw new Error('还有任务正在运行，未中断任务；请完成后再安装后台服务。');
  const interpretationResponse = await fetch(`${localUrl}/api/intake/interpretations`);
  if (interpretationResponse.ok && (await interpretationResponse.json()).activeCount > 0) throw new Error('正在理解采火输入，未中断任务；请完成后再部署。');
  if (!interpretationResponse.ok && interpretationResponse.status !== 404) throw new Error('无法确认采火输入状态，未重启后台服务。');
  const discoveryResponse = await fetch(`${localUrl}/api/market-research/discoveries`);
  if (discoveryResponse.ok && (await discoveryResponse.json()).activeCount > 0) throw new Error('正在自动调研竞品与关键词，未中断任务；请完成后再部署。');
  if (!discoveryResponse.ok && discoveryResponse.status !== 404) throw new Error('无法确认自动调研状态，未重启后台服务。');
}
// Only replace this project's listener. Never terminate another app on the port.
let oldPid = 0;
try {
  const { stdout } = await exec('/usr/sbin/lsof', ['-t', '-iTCP:6187', '-sTCP:LISTEN']);
  const pids = [...new Set(stdout.trim().split(/\s+/).filter(Boolean))];
  if (pids.length !== 1) throw new Error('6187 端口存在多个进程，未自动重启。');
  oldPid = Number(pids[0]);
  const [{ stdout: command }, { stdout: cwd }] = await Promise.all([
    exec('/bin/ps', ['-p', String(oldPid), '-o', 'command=']),
    exec('/usr/sbin/lsof', ['-a', '-p', String(oldPid), '-d', 'cwd', '-Fn']),
  ]);
  if (!command.includes('node') || !command.includes('server.mjs') || ![root, runtime].some(directory => cwd.split('\n').includes(`n${directory}`))) throw new Error('6187 端口不是当前 Hanabi 服务，未自动重启。');
} catch (error) {
  if (error.code !== 1) throw error;
}
await mkdir(dirname(agentPath), { recursive: true });
await mkdir(logs, { recursive: true, mode: 0o700 });
// launchd must not depend on Documents access or the development terminal.
// Stage only the runtime and production packages, never copy personal archives.
const staged = join(data, `runtime-staged-${Date.now()}`);
await mkdir(staged, { mode: 0o700 });
for (const entry of ['server.mjs', 'app.js', 'index.html', 'styles.css', 'package.json', 'lib', 'assets', 'knowledge', 'docs/market-research-writing.md', 'scripts/extract-video-assets.swift', 'scripts/extract-image-text.swift', '.build/ContentAlchemySpeech.app', '.build/HanabiDocuments.app']) {
  if (!existsSync(join(root, entry))) continue;
  await mkdir(dirname(join(staged, entry)), { recursive: true });
  await cp(join(root, entry), join(staged, entry), { recursive: true, dereference: true });
}
const packages = new Set();
const copyPackage = async name => {
  if (packages.has(name)) return;
  packages.add(name);
  const source = join(root, 'node_modules', name);
  const manifest = JSON.parse(await readFile(join(source, 'package.json'), 'utf8'));
  await mkdir(dirname(join(staged, 'node_modules', name)), { recursive: true });
  await cp(source, join(staged, 'node_modules', name), { recursive: true, dereference: true });
  for (const dependency of Object.keys(manifest.dependencies || {})) await copyPackage(dependency);
};
const manifest = JSON.parse(await readFile(join(root, 'package.json'), 'utf8'));
for (const name of Object.keys(manifest.dependencies || {})) await copyPackage(name);
const environment = { PATH: process.env.PATH, CONTENT_ALCHEMY_PORT: '6187', CONTENT_ALCHEMY_DATA_DIR: data };
for (const key of ['HTTPS_PROXY', 'HTTP_PROXY', 'ALL_PROXY', 'NO_PROXY', 'https_proxy', 'http_proxy', 'all_proxy', 'no_proxy']) if (process.env[key]) environment[key] = process.env[key];
await writeFile(agentPath, `<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0"><dict>
<key>Label</key><string>${label}</string>
<key>ProgramArguments</key><array><string>${xml(process.execPath)}</string><string>${xml(join(runtime, 'server.mjs'))}</string></array>
<key>WorkingDirectory</key><string>${xml(runtime)}</string>
<key>RunAtLoad</key><true/><key>KeepAlive</key><true/>
<key>ThrottleInterval</key><integer>3</integer>
<key>EnvironmentVariables</key><dict>${Object.entries(environment).filter(([, value]) => value).map(([key, value]) => `<key>${xml(key)}</key><string>${xml(value)}</string>`).join('')}</dict>
<key>StandardOutPath</key><string>${xml(join(logs, 'server.log'))}</string>
<key>StandardErrorPath</key><string>${xml(join(logs, 'server-error.log'))}</string>
</dict></plist>\n`, { mode: 0o600 });
try { await exec('/bin/launchctl', ['bootout', `${domain}/${label}`]); } catch { /* first installation */ }
if (oldPid) {
  try { process.kill(oldPid, 'SIGTERM'); } catch (error) { if (error.code !== 'ESRCH') throw error; }
  for (let n = 0; n < 40; n++) {
    try { process.kill(oldPid, 0); } catch { break; }
    await new Promise(resolve => setTimeout(resolve, 50));
  }
}
if (existsSync(runtime)) await rename(runtime, join(data, `runtime-previous-${Date.now()}`));
await rename(staged, runtime);
// bootout can finish asynchronously. Retry only launchd's transient I/O result;
// do not start a second server while the registered service is coming up.
for (let attempt = 0; ; attempt++) {
  try { await exec('/bin/launchctl', ['bootstrap', domain, agentPath]); break; }
  catch (error) {
    if (error.code !== 5 || attempt >= 3) throw error;
    await new Promise(resolve => setTimeout(resolve, 250));
  }
}
await waitUntilReady();
console.log(JSON.stringify({ installed: true, label, url: localUrl, agentPath }));
