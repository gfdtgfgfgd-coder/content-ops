import { readFile, writeFile } from 'node:fs/promises';
import { reportDocx } from '../lib/report-docx.mjs';
const markdown=await readFile('../outputs/hanabi-rework-20261022/report-reviewed.md','utf8');
await writeFile('../outputs/hanabi-rework-20261022/价格调研10.22-五业务线.docx',await reportDocx({title:'价格调研10.22',markdown,createdAt:new Date().toISOString()}));
