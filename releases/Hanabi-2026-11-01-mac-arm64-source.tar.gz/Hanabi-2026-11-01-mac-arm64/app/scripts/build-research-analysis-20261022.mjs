import {readFile,writeFile} from 'node:fs/promises';
import {historicalComparisons,tokenScenario} from '../lib/market-comparison.mjs';
const base='/Users/lilith/Library/Application Support/Content Alchemy/knowledge/ai-content-alchemy/references/ai-market-research/references';
const data=historicalComparisons(JSON.parse(await readFile(base+'/十月嵌入表格.json','utf8')));
await writeFile('../outputs/hanabi-rework-20261022/historical-analysis.json',JSON.stringify(data,null,2));
console.log(JSON.stringify({groups:data.groups,rows:data.rows.length,anomalies:data.rows.filter(r=>r.anomaly).map(r=>({model:r.model,table:r.tableId}))},null,2));
for(const r of data.rows.filter(r=>['gpt-6.1-sol','gpt-6-1-sol','gpt-5.6-sol','gpt-5-6-sol','deepseek-flash','deepseek-v4-pro','gemini-3.8-flash','gemini-3-8-flash','glm-5.3-flash','glm-5-3-flash'].includes(r.model)))console.log(JSON.stringify(r));
