import { readFile, readdir, mkdir, writeFile, rename, cp, stat } from 'node:fs/promises';
import { join, dirname, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
import { createHash } from 'node:crypto';
import { MARKET_PRODUCTS } from '../lib/market-products.mjs';
import { MODEL_FAMILIES, OWNED_SITE_SKILLS, modelFamilyForRecord } from '../lib/market-knowledge.mjs';

const DATE='2026-10-26';
const md = value => String(value ?? '原页未提供').replace(/\|/g,'\\|').replace(/\r?\n/g,'<br>') || '原页未提供';
const front=(name,description,title)=>`---\nname: ${name}\ndescription: ${description}\n---\n\n# ${title}\n\n`;
const readJson=async path=>JSON.parse(await readFile(path,'utf8'));
const atomic=async(path,text)=>{await mkdir(dirname(path),{recursive:true});await writeFile(path+'.tmp',text,{mode:0o600});await rename(path+'.tmp',path);};
const hasFile=async path=>{try{return (await stat(path)).isFile();}catch(e){if(e.code==='ENOENT')return false;throw e;}};

export async function restructureMarketKnowledge({knowledgeRoot,snapshotRoot,backupRoot, codexMultiplier=null}) {
 const base=join(knowledgeRoot,'references/ai-market-research');
 if(await hasFile(join(base,'catalog.json'))) { const previous=await readJson(join(base,'catalog.json')); if(previous.version===1) return {alreadyApplied:true,sites:previous.sites.length,modelFamilies:previous.models.length,originalRecords:previous.recordCount}; }
 const oldMain=await readFile(join(base,'SKILL.md'),'utf8');
 if(backupRoot) {await mkdir(backupRoot,{recursive:true});await cp(base,join(backupRoot,'ai-market-research'),{recursive:true});}
 const manifest={version:1,organizedAt:DATE,main:'SKILL.md',sites:[],models:[],recordCount:0,supportingRecordCount:0,confirmation:{bApiCnyPerCredit:1,codingPlanCnyPerCredit:1,codexMultiplier:1,mirrorRawConsumptionMultiplier:codexMultiplier ?? 2,mirrorDiscountIncludesConsumptionMultiplier:true,mirrorStoreOverridesTutorial:true,source:'用户于2026-10-27确认：镜像站最终折扣已含消耗倍率，不再追加；商店优先，未列折扣则按教程与商店同规格售价/额度换算。B端与Coding Plan的1:1另行保留；后续内部政策按用户补料。'}};
 let originals=[];
 const official=join(base,'references/official');
 for(const filename of await readdir(official)) {
  if(!filename.endsWith('.json'))continue;
  const data=await readJson(join(official,filename));
  for(const record of data.records||[])originals.push({...record,originalPath:`references/official/${filename}`,fx_date:data.fx_date,fx_source:data.fx_source,fx_cny_per_usd:data.fx_cny_per_usd});
 }
 const seen=new Map();for(const r of originals){if(!r.id)throw Error('报价记录缺少来源 ID');const previous=seen.get(r.id);if(previous&&JSON.stringify({...previous,originalPath:''})!==JSON.stringify({...r,originalPath:''}))throw Error(`冲突报价 ID ${r.id}`);seen.set(r.id,r);}
 originals=[...seen.values()]; manifest.recordCount=originals.length;
 const assignments=new Map(),support=[];
 for(const record of originals){const family=modelFamilyForRecord(record);if(!family){support.push(record);continue;}if(!assignments.has(family.id))assignments.set(family.id,[]);assignments.get(family.id).push(record);}
 const priceRows=records=>records.flatMap(r=>(r.price_fields?.length?r.price_fields:[{label:'计费规则',value:r.note||'原页未提供数值报价',amounts:[]}]).map(field=>{
  const amounts=field.amounts||[];
  const cny=amounts.map(a=>a.cny_reference).filter(x=>x!=null).join(' / ')||'无适用换算；保留原价';
  const usd=amounts.map(a=>a.usd_reference).filter(x=>x!=null).join(' / ')||'无适用换算；保留原价';
  return `| ${md(r.subject)} | ${md(Object.entries(r.specification||{}).map(([k,v])=>`${k}: ${v}`).join('；'))} | ${md(field.label)} | ${md(field.value)} | ${md(r.unit_text)} | ${md(cny)} | ${md(usd)} | ${md(r.observed_at)} | [${md(r.id)}](${r.source_url}) |`;
 })).join('\n');
 for(const family of MODEL_FAMILIES){const records=assignments.get(family.id);if(!records?.length)continue;
  const directory=dirname(join(base,family.path));const dates=[...new Set(records.map(r=>r.observed_at).filter(Boolean))].sort();
  const info={...family,recordCount:records.length,modelNames:[...new Set(records.map(r=>r.subject))],observedAt:dates.at(-1),prices:`models/${family.id}/references/prices.json`};manifest.models.push(info);
  const examples=[...new Map(records.map(r=>[r.subject,r])).values()].slice(0,4);
  let skill=front(`market-official-${family.id}`,`核对 ${family.name} 系列原厂按量、按次价格和规格，保留币种、缓存、地区、模式与有效时间；与我方站点报价比较时使用。`,`${family.name} · 官方价格 Skill`);
  skill+=`覆盖 ${records.length} 条规格与计费记录，原始采集日期 ${dates.join('、')}。${DATE} 仅重新归类，不把旧快照改写成今日现价。不同地区、Batch、缓存、模态和生命周期属于不同记录。\n\n`;
  skill+=`## 使用方法\n\n按精确型号、规格、地区和计费方式读取[完整价目](references/prices.md)或[结构化报价](references/prices.json)。每个数值都保留来源 ID、原价、原字段与采集日期；人民币/美元参考采用记录所附汇率日期，不是当前成交汇率。\n\n做当前比价时重新访问记录里的原厂链接；停服、预览、未来生效、促销价单列。第三方云转售放在主 Skill 的支撑资料，不作为本系列原厂价。若数值未公开，保留实际原因并向用户确认需要的版本或可用内部材料，不套相近型号、不填写空白占位。\n\n`;
  skill+=`## 已归档的报价示例\n\n以下只展示入口样例，完整型号和规格见完整价目。\n\n| 型号 / 项目 | 原页规格 | 原始报价 | 来源日期 |\n| --- | --- | --- | --- |\n`;
  skill+=examples.map(r=>`| ${md(r.subject)} | ${md(Object.values(r.specification||{}).join('；'))} | ${md((r.price_fields||[]).map(f=>`${f.label}: ${f.value}`).join('；'))} | ${md(r.observed_at)} |`).join('\n');
  skill+=`\n\n## 组合与更新\n\n与[市场调研主 Skill](../../SKILL.md)组合；我方渠道价格读取对应网站 Skill。新报价保留旧记录并记录新生效时间；用户提供的业务口径与原厂网页价格分开存放。本系列入口只保留本系列规则，报告成品留在主 Skill 的报告归档。\n`;
  await atomic(join(directory,'SKILL.md'),skill);
  await atomic(join(directory,'references/prices.json'),JSON.stringify({family:family.id,organizedAt:DATE,refreshRequiredForCurrentPrice:true,records},null,2)+'\n');
  await atomic(join(directory,'references/prices.md'),`# ${family.name} · 完整官方价目\n\n这是有日期的原厂价格快照，不是今日实付证明。金额参考换算沿用每条 JSON 中的 fx_date / fx_source。原页无值时明确说明，不推测数值。\n\n| 型号 / 项目 | 规格与条件 | 计费字段 | 原价原币 | 单位 | 人民币参考 | 美元参考 | 采集日期 | 来源 ID / 原页 |\n| --- | --- | --- | --- | --- | --- | --- | --- | --- |\n${priceRows(records)}\n`);
 }
 manifest.supportingRecordCount=support.length;
 await atomic(join(base,'references/cloud-and-support-prices.json'),JSON.stringify({organizedAt:DATE,note:'第三方托管、转售及未能明确归属的通用费用；不是模型原厂价。原路径和记录完整保留。',records:support},null,2)+'\n');
 const tableData=await readJson(join(base,'references/十月嵌入表格.json'));
 const latest=async name=>snapshotRoot&&await hasFile(join(snapshotRoot,name))?await readFile(join(snapshotRoot,name),'utf8'):null;
 const siteConfig={
  'c-api':{url:'https://duoyuanx.com/',files:['c-home.md','c-price.md','c-catalogue.md'],customer:'个人开发者、创作者和需要自行接入 API 的用户',features:'公开首页提供令牌管理、使用日志、绘图/任务日志、钱包、返利、消费清单、工单；链接 API 文档、教程、绘影工坊、MakeNow 画布与社区。支持文本、图片、视频和音频模型；当日模型广场类别计数只表示该页展示，不当作稳定可用率。',mode:'已确认采用先充值、后按调用量计费。模型聚合与接入是主产品；教程、社区、创作工具和代理入口承担学习、转化与分发。成本研究拆开上游调用、失败重试、运维和支持成本，不从售价推定毛利。',pricing:'当前公开页明确显示 GPT Image 2 为 ¥0.100/次，gpt-image-2-all 为 ¥0.050/次；后者描述仅支持 1K，不能当同规格。价格页直接展示人民币。按量、按次和动态分档分开；同名模型不同分组不视为同一供给。API 目录中的 model_ratio、completion_ratio 和 group_ratio 是原始参数，缺展示基价及实际分组时不当成人民币单价。',tableHeader:'多元探索C端人民币价'},
  'b-api':{url:'https://zx1.deepwl.net/',files:['b-home.md','b-price.md','b-catalogue.md'],customer:'有批量、持续调用需求的企业、开发团队与集成方',features:'公开站点提供模型广场、控制台、API 接入文档与账户功能。目录保留模型支持的模态、接口、上下文、缓存、结构化输出、工具等字段；这些是目录声明，实际可用性需按任务核对。',mode:'充值后按量调用；企业另有合同的，按有效合同单列，不能默认 B 端比 C 端便宜。面向生产集成，比较模型、渠道分组、限流并发、交付支持、发票和售后；没有合同或实测就不宣称 SLA、实际成功率和企业优惠。',pricing:'2026-10-26 公开价目页显示 GPT-4o 输入 $10、输出 $40、缓存读 $5 /百万 Token，GPT-4o mini 输入 $0.6、输出 $2.4、缓存读 $0.3 /百万 Token。用户于 2026-10-26 确认：人民币 1 元到账 1 美元额度，即 ¥1 = $1 站内额度。页面的 $ 不是现金美元，不按外汇折成人民币；在相应充值与分组条件下，扣 $2 额度的标价可按 ¥2 参考计算。分组倍率必须以该 SKU 价格是否已含倍率为准，不能重复乘。',tableHeader:'多元探索B端人民币价'},
  'mirror':{url:'https://chat.duoyuanx.com/',files:['mirror.md','mirror-docs.md','mirror-proxy.md','mirror-codex.md','mirror-claude.md','mirror-codingplan.md'],customer:'网页使用者，以及购买 Codex / Claude / 国产 Coding Plan 外接套餐的开发者',features:'网页版用于网页聊天、内容生成和在线工具；外接 API 套餐用于代码编辑器、CLI、插件和自动化，公开说明写明不可在网页调用。Codex 仅 GPT，Claude 套餐仅 Claude，Coding Plan 仅国产模型。',mode:'以预付费订阅、周期额度和加量包销售访问权限。网页版按积分或时间窗口次数限制，外接套餐按套餐额度及对应模型单价扣减；两种商品分开，不能用任意 Token 量摊月费。续费与到期、窗口刷新、加量包叠加和未用额度处理按对应条款核对。',pricing:`2026-10-26 读取的公开套餐：网页版日卡 ¥1.99、月卡 ¥39、季卡 ¥109、年卡 ¥399；Codex 体验卡 ¥1.99、月卡 ¥99、加量包 Standard ¥69 / Max ¥149 / Ultra ¥599；Claude Code ¥59、加量包 ¥129、官 Standard ¥199 / Ultra ¥499；Coding Plan Lite ¥69 / Pro ¥119 / Ultra ¥299。\n\n用户确认 Coding Plan 的 ¥ 额度与表内 $ 单价按 1:1 扣减，不能按美元外汇换算。用户于2026-10-27确认镜像站最终折扣已经包含消耗倍率2，使用最终折扣后不再乘2。商店与教程冲突以商店为准；商店没有折扣时，以教程最终折扣×商店售价/教程售价×教程同口径额度/商店同口径额度计算，条件不一致就分开记录。网页版积分是站长估计，不用来推算API单价。网页写“无需积分”也仍可能有时间窗口次数限制，不能改写为无条件无限。`},
  'makenow':{url:'https://www.makenow.tv/',files:['makenow.md'],customer:'图片、视频、漫剧和营销内容生产者及创作团队',features:'2026-10-26 公开首页展示无限画布、Agent 多模态创作、漫剧批量制作、从剧本到视频的链路与作品案例；展示 Seedance、MiniMax 等上新。页面宣传的产出质量与效率不是实测结论。',mode:'按量消耗积分，用户充值后用于内容生产。比较对象除模型调用，还包括剧本、分镜、生成、编辑、导出和人工操作步骤；每步是否收费、失败退分及重试以该步规则为准。旧内部手册的套餐/卡密描述是历史，不覆盖现用站积分规则。',pricing:'已归档 2026-10-21 登录页四档：¥98→1226 积分、¥298→3776、¥698→8976、¥1980→25760，含赠送；基础兑换 12 积分/元。全部可用时每积分约 ¥0.079935 / ¥0.078919 / ¥0.077763 / ¥0.076863。2026-10-26 首页可见 Seedance 2.0 为 12 积分/秒；公开首页不能再次证明登录后四档套餐仍有效，正式当日报价前刷新购买页。现用域名由用户确认；dream.ai666.net 已停用，禁止回退为现用产品。'},
  'overseas':{url:'https://octopusx.ai/',files:['overseas.md','overseas-plans.md'],customer:'海外个人开发者、生产项目、初创团队和企业 API 客户',features:'公开站点提供统一 API、OpenAI 兼容端点、模型目录、Playground、用量日志与 API Key 预算控制。Pro 宣传优先路由、较低延迟、模型抢先与人工支持；Business 宣传并发、客户经理、SLA、发票及日志留存，均为页面权益说明，非实测保证。',mode:'我方第五条业务线，不能当竞品。Free 采用按量付费；Pro 月费与对应 API 折扣组合；Business 定制容量及合同价格。免费注册/社群额度单列，不作为常规成交折扣；支付方式和发票受地区影响。',pricing:'2026-10-26 套餐页显示 Free $0；Pro $19.9/月，附 $19.9 Bonus Credit 和 API Usage 15% Off；Business 为 Custom。页面另写 pay-as-you-go from $9.90；该起点不等于 Pro 月费。标准价示例：gpt-6-astra 输出 $50/1M、deepseek-v4-pro 输出 $3.96/1M、glm-5.3 输出 $4.40/1M。页面只给输出价时不补输入价；货币结算性质未确认时保留原标价，不套 B 端的 1:1 规则。'}
 };
 for(const site of OWNED_SITE_SKILLS){const config=siteConfig[site.id],directory=dirname(join(base,site.path));let sources=[];
  if(!config){
   const bundled=new URL('../knowledge/ai-content-alchemy/references/ai-market-research/'+site.path,import.meta.url);
   if(!await hasFile(fileURLToPath(bundled))) throw new Error('缺少网站 Skill 种子：'+site.id);
   await mkdir(dirname(directory),{recursive:true});
   await cp(dirname(fileURLToPath(bundled)),directory,{recursive:true,force:false,errorOnExist:true});
   manifest.sites.push({...site,url:MARKET_PRODUCTS.find(product=>product.id===site.id).url,observedAt:'2026-10-28',currentPricing:{observedAt:'2026-10-28',rules:site.path.replace('SKILL.md','references/pricing-rules-20261028.json'),quotes:site.path.replace('SKILL.md','references/prices-20261028.json'),catalogue:site.path.replace('SKILL.md','references/catalogue-20261028.json')}});
   continue;
  }
  let historicalSample='';
  for(const file of config.files){const content=await latest(file);if(!content)continue;const name=file.replace(/\.md$/,'.md');const target=join(directory,'references',name);await atomic(target,content);sources.push({path:`references/${name}`,url:content.match(/URL Source:\s*(\S+)/)?.[1],sha256:createHash('sha256').update(content).digest('hex'),retrievedAt:DATE});}
  if(config.tableHeader){const quotes=[];for(const table of tableData){const index=table.rows?.[0]?.indexOf(config.tableHeader);if(index<0||index==null)continue;for(const row of table.rows.slice(1))if(row[index])quotes.push({model:row[0],quote:row[index],sourceTable:table.id,observedAt:'2026-10-16',status:'historical'});}
   historicalSample = `历史价样例（2026-10-16，完整原表见链接）：\n\n| 型号 | 当时我方人民币价 | 原表 |\n| --- | --- | --- |\n` + [...new Map(quotes.map(q=>[q.model,q])).values()].slice(0,4).map(q=>`| ${md(q.model)} | ${md(q.quote)} | ${md(q.sourceTable)} |`).join('\n')+'\n\n';
   await atomic(join(directory,'references/historical-prices.json'),JSON.stringify(quotes,null,2)+'\n');
   await atomic(join(directory,'references/historical-prices.md'),`# ${site.name} · 历史报价\n\n来源：用户 2026-10-16 原稿 R14 的原始嵌入表格；同名重复行保留各表来源，不静默合并冲突。今日价另查现用站。\n\n| 型号 | 当时我方人民币价 | 原表 |\n| --- | --- | --- |\n${quotes.map(q=>`| ${md(q.model)} | ${md(q.quote)} | ${md(q.sourceTable)} |`).join('\n')}\n`);
  }
  if(site.id==='makenow'){await cp(join(base,'references/MakeNow现用站快照.json'),join(directory,'references/points-snapshot-20261021.json'));}
  const skill=front(`market-site-${site.id}`,`研究我方 ${site.name} 的价格、功能、运营与收费模式，按该站口径与竞品或原厂比较；不用于其他业务线定价。`,`${site.name} · 网站 Skill`)
   +`现用入口：[${config.url}](${config.url})。整理日期 ${DATE}。价格与功能分别保留实际取证时间。\n\n## 服务与功能\n\n目标用户：${config.customer}。\n\n${config.features}\n\n## 价格与计费\n\n${config.pricing}\n\n`
   +historicalSample
   +(config.tableHeader?'[完整历史报价](references/historical-prices.md) · [结构化历史记录](references/historical-prices.json)。新的公开目录含所有返回的 SKU 与原始字段，见下方来源；参数倍率未经基价核对不冒充成交价。\n\n':'')
   +`## 运营模式\n\n${config.mode}\n\n最新内部代理政策、退款规则及合同优惠：用户在 ${DATE} 表示暂时没有新增资料，后续按其提供内容补充。当前不推定统一政策、私有采购渠道、真实毛利或可承诺的服务水平。\n\n## 调研与更新\n\n与[市场调研主 Skill](../../SKILL.md)组合。查本次目标模型的官方价格时按主 Skill 的模型系列目录读取；本站价格不得写进原厂 Skill。每次补料将事实放入本站对应参考文件，标来源、日期、生效条件；保留旧快照和冲突，不另建同站重复 Skill。报告成品和竞品原始材料继续归主 Skill 的支撑归档。新数据缺关键条件时先问用户，不以空白表格交付。\n\n## 来源与证据\n\n`
   +sources.map(s=>`- [${s.path.replace('references/','')}](${s.path})：${s.url}，读取 ${DATE}。`).join('\n')
   +(site.id==='makenow'?'\n- [2026-10-21 积分购买页快照](references/points-snapshot-20261021.json)：保留套餐、赠送、模型列表与原始定位。':'')
   +'\n- 内部运营事实摘自公司业务手册；其旧域名和旧收费描述不覆盖用户后续确认与现用页面。\n';
  await atomic(join(directory,'SKILL.md'),skill);manifest.sites.push({...site,url:config.url,sources});
 }
 const modelIndex=`# 模型官方价格 · 系列目录\n\n按系列选 Skill，版本与规格在其价目里。共 ${manifest.models.length} 个系列，${originals.length-support.length} 条原厂规格与计费记录；另外 ${support.length} 条第三方托管或通用费用在[支撑价格](cloud-and-support-prices.json)。归类完成不等于已核齐每个历史别名现价，旧缺口继续见[覆盖清单](官方覆盖清单.json)。\n\n`+manifest.models.map(f=>`- [${f.name}](../${f.path}) · ${f.group} · ${f.recordCount} 条 · 采集 ${f.observedAt}`).join('\n')+'\n';
 await atomic(join(base,'references/model-skills.md'),modelIndex);
 let main=front('ai-market-research','为我方各网站进行竞品、模型官方价格、渠道与运营研究；按网站与模型系列调用子 Skill，形成有来源、可复算、符合用户原稿风格的报告。','市场调研基础 Skill');
 main+=`这是市场调研的唯一主入口。本站点事实、模型官方价格、报告成品分工明确：主 Skill 管方法，网站 Skill 管我方业务，模型系列 Skill 管原厂价目。\n\n## 我方网站\n\n${manifest.sites.map(s=>`- [${s.name}](${s.path})：价格、功能、运营模式。`).join('\n')}\n\n## 模型官方价格\n\n按[模型系列目录](references/model-skills.md)定位 ${manifest.models.length} 份独立 Skill。每个系列内部保留版本、规格、币种、缓存、批量/峰谷和按次条件；原厂价与第三方云托管分开。\n\n## 调研流程\n\n1. 明确这次要做价格比较、功能运营研究还是周监控；按业务线加载网站 Skill，再按目标型号加载模型系列 Skill，不把所有历史材料一次塞进分析。\n2. 自动找竞品与 SEO 关键词、GEO 问题时保留实际搜索与来源；建议词标为建议，不伪造搜索量、CPC、排名或引用率。\n3. 当前比价重新读公开价格页、计费页和充值条件，记录精确型号、分组、规格、日期、币种和来源。缺失条件先查关联页面，仍无证据就问用户。历史有值也不能充当今日现价。\n4. 统一可比条件后调用成本计算器：未缓存输入、命中、写缓存、输出不得重复计；按次核对张数、分辨率、时长、音轨；已经包含的折扣不再重复乘。\n5. 保留各站原价，再解释数值差异、运营条件与我方影响。真实数据不支持的毛利、模型真实性、可用率、销量和服务优势不补造。\n6. 成品直接进入知识档案的报告归档，并在制花提供文档预览与 Word，沿用同一终稿。网页、历史表和新报告作为支撑资料，不再平铺冒充新 Skill。\n\n## 已确认的关键口径\n\n- 我方是 C 端 API、B 端 API、镜像站、MakeNow、OctopusX、CyAPI 六条线。OctopusX 是我方海外站，不是竞品。\n- B 端：用户 ${DATE} 确认 ¥1 充值到账 $1 站内额度；不使用美元外汇。Coding Plan 套餐额度与模型单价按 1:1 扣减。该规则不自动外推到其他站。\n- 镜像站的网页版与外接 API 是不同商品；套餐额度、积分、现金 USD 分开。MakeNow 需计算积分兑换及实际工作流步骤。\n- 新内部政策暂未提供，用户后续喂入的资料更新到对应网站 Skill。遇冲突优先确认生效时间，不因资料新就删除旧证据。\n\n## 写作与支撑资料\n\n先读[用户报告写作风格](references/调研报告写作风格.md)，再对照 R04 / R06 / R10 的原句。价格调研以 R14 原始价目对照为主；周监控按站点写价格、变化和找不同。短标题、真实表格，表后直接判断，不固定套咨询式摘要和任务篮子。\n\n- [比价口径](references/比价口径.md)：币种、积分和成本计算。\n- [历期归纳](references/历期归纳.md)、[来源目录](references/来源目录.md)：历史报告和用户原文。\n- [官方覆盖清单](references/官方覆盖清单.json)：历史型号别名、已核规格与尚需核对的版本，不将登记数量当查齐数量。\n- 报告成品放 references/reports/，竞品事实放 references/competitors/，SEO/GEO 证据放 references/keywords/。\n- 原始 official/ JSON、原表、快照与工具全部保留，作为下层证据搜索和引用。\n\n## 新资料维护\n\n先判断归属：我方网站事实进该站；原厂价格进该模型系列；研究方法进本主 Skill 或其方法参考；单次报告和竞品进支撑档案。相同站点或系列不重复建 Skill。每条数值标实际观察日期，用户口径标确认日期。不能确认的重要内容直接问用户并保留具体问题，不能无说明留空。\n`;
 main+='\n\n'+await readFile(new URL('../docs/market-package-pricing.md',import.meta.url),'utf8');
 await atomic(join(base,'SKILL.md'),main);
 await atomic(join(base,'catalog.json'),JSON.stringify(manifest,null,2)+'\n');
 const beforeHash=createHash('sha256').update(oldMain).digest('hex');
 return {main:manifest.main,sites:manifest.sites.length,modelFamilies:manifest.models.length,originalRecords:originals.length,familyRecords:originals.length-support.length,supportingRecords:support.length,previousMainSha256:beforeHash,backupRoot};
}
if(process.argv[1]&&resolve(process.argv[1])===fileURLToPath(import.meta.url)){
 const option=name=>{const index=process.argv.indexOf(name);return index>=0?process.argv[index+1]:null;};
 const root=option('--root');if(!root)throw Error('--root 知识档案目录必填');
 const result=await restructureMarketKnowledge({knowledgeRoot:resolve(root),snapshotRoot:option('--snapshots'),backupRoot:option('--backup'),codexMultiplier:option('--codex-multiplier')?Number(option('--codex-multiplier')):null});
 console.log(JSON.stringify(result,null,2));
}
