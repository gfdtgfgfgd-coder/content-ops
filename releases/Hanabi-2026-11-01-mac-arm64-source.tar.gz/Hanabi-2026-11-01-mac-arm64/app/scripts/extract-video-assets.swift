import AVFoundation
import CoreGraphics
import Foundation
import ImageIO
import UniformTypeIdentifiers
import Vision

struct FrameRecord: Codable {
  let path: String
  let seconds: Double
}

struct OCRRecord: Codable {
  let startSeconds: Double
  var endSeconds: Double
  let text: String
  let confidence: Float
}

struct ExtractionResult: Codable {
  let durationSeconds: Double
  let hasAudio: Bool
  let frames: [FrameRecord]
  let audioPath: String?
  let audioBytes: Int
  let onScreenText: [OCRRecord]
  let ocrSampleCount: Int
  let ocrExpectedSampleCount: Int
  let ocrSampleIntervalSeconds: Double
}

func writePCM16Wav(_ pcm: Data, to url: URL, sampleRate: UInt32, channels: UInt16) throws {
  var data = Data()
  func append<T: FixedWidthInteger>(_ value: T) {
    var littleEndian = value.littleEndian
    withUnsafeBytes(of: &littleEndian) { data.append(contentsOf: $0) }
  }
  data.append(contentsOf: Array("RIFF".utf8))
  append(UInt32(36 + pcm.count))
  data.append(contentsOf: Array("WAVEfmt ".utf8))
  append(UInt32(16))
  append(UInt16(1))
  append(channels)
  append(sampleRate)
  append(sampleRate * UInt32(channels) * 2)
  append(UInt16(channels * 2))
  append(UInt16(16))
  data.append(contentsOf: Array("data".utf8))
  append(UInt32(pcm.count))
  data.append(pcm)
  try data.write(to: url, options: .atomic)
}

func extractAudio(_ track: AVAssetTrack, from asset: AVAsset, to outputURL: URL) throws -> Int {
  let reader = try AVAssetReader(asset: asset)
  let settings: [String: Any] = [
    AVFormatIDKey: kAudioFormatLinearPCM,
    AVSampleRateKey: 16_000,
    AVNumberOfChannelsKey: 1,
    AVLinearPCMBitDepthKey: 16,
    AVLinearPCMIsFloatKey: false,
    AVLinearPCMIsBigEndianKey: false,
    AVLinearPCMIsNonInterleaved: false,
  ]
  let output = AVAssetReaderTrackOutput(track: track, outputSettings: settings)
  output.alwaysCopiesSampleData = false
  guard reader.canAdd(output) else { throw NSError(domain: "ContentAlchemyVideo", code: 1, userInfo: [NSLocalizedDescriptionKey: "Cannot read audio track"]) }
  reader.add(output)
  guard reader.startReading() else { throw reader.error ?? NSError(domain: "ContentAlchemyVideo", code: 2, userInfo: [NSLocalizedDescriptionKey: "Cannot start reading audio"]) }

  var pcm = Data()
  while let sample = output.copyNextSampleBuffer() {
    guard let block = CMSampleBufferGetDataBuffer(sample) else { continue }
    let length = CMBlockBufferGetDataLength(block)
    var bytes = [UInt8](repeating: 0, count: length)
    let status = CMBlockBufferCopyDataBytes(block, atOffset: 0, dataLength: length, destination: &bytes)
    guard status == kCMBlockBufferNoErr else { throw NSError(domain: "ContentAlchemyVideo", code: 3, userInfo: [NSLocalizedDescriptionKey: "Cannot copy audio samples"]) }
    pcm.append(contentsOf: bytes)
    if pcm.count > 200 * 1024 * 1024 { throw NSError(domain: "ContentAlchemyVideo", code: 4, userInfo: [NSLocalizedDescriptionKey: "Extracted audio is too large to attach safely"]) }
  }
  guard reader.status == .completed else { throw reader.error ?? NSError(domain: "ContentAlchemyVideo", code: 5, userInfo: [NSLocalizedDescriptionKey: "Audio extraction did not finish"]) }
  try writePCM16Wav(pcm, to: outputURL, sampleRate: 16_000, channels: 1)
  return pcm.count + 44
}

func main() throws {
  guard CommandLine.arguments.count >= 3 else {
    throw NSError(domain: "ContentAlchemyVideo", code: 10, userInfo: [NSLocalizedDescriptionKey: "Usage: extract-video-assets.swift <input> <output-directory> [max-frames]"])
  }
  let inputURL = URL(fileURLWithPath: CommandLine.arguments[1])
  let outputDirectory = URL(fileURLWithPath: CommandLine.arguments[2], isDirectory: true)
  let maxFrames = CommandLine.arguments.count > 3 ? (Int(CommandLine.arguments[3]) ?? 24) : 24
  let ocrOnly = CommandLine.arguments.contains("--ocr-only")
  let skipOCR = CommandLine.arguments.contains("--skip-ocr")
  let framesOnly = CommandLine.arguments.contains("--frames-only")
  let skipAudio = framesOnly || CommandLine.arguments.contains("--skip-audio")
  let overview = CommandLine.arguments.contains("--overview")
  var requestedTimes: [Double]? = nil
  if let index = CommandLine.arguments.firstIndex(of: "--times"), index + 1 < CommandLine.arguments.count {
    let values = CommandLine.arguments[index + 1].split(separator: ",").compactMap { Double($0) }
    guard !values.isEmpty, values.count <= 48, values.allSatisfy({ $0.isFinite && $0 >= 0 }) else {
      throw NSError(domain: "ContentAlchemyVideo", code: 14, userInfo: [NSLocalizedDescriptionKey: "Invalid frame timestamps"])
    }
    requestedTimes = values
  }
  try FileManager.default.createDirectory(at: outputDirectory, withIntermediateDirectories: true)

  let asset = AVURLAsset(url: inputURL)
  let duration = CMTimeGetSeconds(asset.duration)
  guard duration.isFinite, duration > 0 else { throw NSError(domain: "ContentAlchemyVideo", code: 11, userInfo: [NSLocalizedDescriptionKey: "Video duration is unavailable"]) }

  let generator = AVAssetImageGenerator(asset: asset)
  generator.appliesPreferredTrackTransform = true
  generator.maximumSize = CGSize(width: 1280, height: 1280)
  generator.requestedTimeToleranceBefore = .zero
  generator.requestedTimeToleranceAfter = CMTime(seconds: 0.35, preferredTimescale: 600)
  var frames: [FrameRecord] = []
  if !ocrOnly {
    let frameCount = min(max(1, maxFrames), max(1, Int(ceil(duration))))
    var times: [Double] = []
    if let requestedTimes {
      times = requestedTimes
    } else {
      let lastTime: Double = max(0, duration - 0.04)
      let divisions: Double = Double(max(1, frameCount - 1))
      for index in 0..<frameCount {
        let position: Double = Double(index)
        if overview { times.append(lastTime * position / divisions) }
        else { times.append(duration * (position + 0.5) / Double(frameCount)) }
      }
    }
    for (index, requested) in times.enumerated() {
      let seconds = min(max(0, duration - 0.04), max(0, requested))
      var actualTime = CMTime.zero
      let image = try generator.copyCGImage(at: CMTime(seconds: seconds, preferredTimescale: 600), actualTime: &actualTime)
      let frameURL = outputDirectory.appendingPathComponent(String(format: "frame-%03d-%05.1fs.jpg", index + 1, seconds))
      guard let destination = CGImageDestinationCreateWithURL(frameURL as CFURL, UTType.jpeg.identifier as CFString, 1, nil) else {
        throw NSError(domain: "ContentAlchemyVideo", code: 12, userInfo: [NSLocalizedDescriptionKey: "Cannot create frame image"])
      }
      CGImageDestinationAddImage(destination, image, [kCGImageDestinationLossyCompressionQuality: 0.78] as CFDictionary)
      guard CGImageDestinationFinalize(destination) else { throw NSError(domain: "ContentAlchemyVideo", code: 13, userInfo: [NSLocalizedDescriptionKey: "Cannot write frame image"]) }
      frames.append(FrameRecord(path: frameURL.path, seconds: CMTimeGetSeconds(actualTime)))
    }
  }

  var onScreenText: [OCRRecord] = []
  let ocrSampleIntervalSeconds = 0.5
  let ocrExpectedSampleCount = skipOCR || framesOnly ? 0 : max(1, Int(ceil(duration * 2)))
  var ocrSamplesRead = 0
  for index in 0..<ocrExpectedSampleCount {
    let seconds = min(duration - 0.04, (Double(index) + 0.5) / 2)
    var actualTime = CMTime.zero
    guard let image = try? generator.copyCGImage(at: CMTime(seconds: seconds, preferredTimescale: 600), actualTime: &actualTime) else { continue }
    do {
      let textRequest = VNRecognizeTextRequest()
      textRequest.recognitionLevel = .accurate
      textRequest.usesLanguageCorrection = false
      textRequest.recognitionLanguages = ["zh-Hans", "en-US"]
      textRequest.minimumTextHeight = 0.008
      try VNImageRequestHandler(cgImage: image).perform([textRequest])
      ocrSamplesRead += 1
      let candidates = (textRequest.results ?? []).compactMap { observation -> (String, Float)? in
        guard let candidate = observation.topCandidates(1).first else { return nil }
        let text = candidate.string.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !text.isEmpty, candidate.confidence >= 0.20 else { return nil }
        return (text, candidate.confidence)
      }
      let text = candidates.map(\.0).joined(separator: " | ")
      guard !text.isEmpty else { continue }
      let confidence = candidates.map(\.1).reduce(0, +) / Float(candidates.count)
      if let lastIndex = onScreenText.indices.last, onScreenText[lastIndex].text == text {
        onScreenText[lastIndex].endSeconds = CMTimeGetSeconds(actualTime)
      } else {
        onScreenText.append(OCRRecord(startSeconds: CMTimeGetSeconds(actualTime), endSeconds: CMTimeGetSeconds(actualTime), text: text, confidence: confidence))
      }
    } catch {
      continue
    }
  }

  let audioTrack = asset.tracks(withMediaType: .audio).first
  var audioPath: String? = nil
  var audioBytes = 0
  if let audioTrack, !ocrOnly && !skipAudio {
    let audioURL = outputDirectory.appendingPathComponent("audio-16khz-mono.wav")
    audioBytes = try extractAudio(audioTrack, from: asset, to: audioURL)
    audioPath = audioURL.path
  }

  let result = ExtractionResult(durationSeconds: duration, hasAudio: audioTrack != nil, frames: frames, audioPath: audioPath, audioBytes: audioBytes, onScreenText: onScreenText, ocrSampleCount: ocrSamplesRead, ocrExpectedSampleCount: ocrExpectedSampleCount, ocrSampleIntervalSeconds: ocrSampleIntervalSeconds)
  let encoder = JSONEncoder()
  encoder.outputFormatting = [.sortedKeys]
  FileHandle.standardOutput.write(try encoder.encode(result))
  FileHandle.standardOutput.write(Data("\n".utf8))
}

do {
  try main()
} catch {
  FileHandle.standardError.write(Data("\(error.localizedDescription)\n".utf8))
  exit(1)
}
