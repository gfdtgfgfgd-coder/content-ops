import { spawn, execFile } from 'node:child_process';
import { mkdir, open } from 'node:fs/promises';
import { existsSync } from 'node:fs';
import { promisify } from 'node:util';
import { homedir } from 'node:os';
import { dirname, join, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';

const root = dirname(dirname(fileURLToPath(import.meta.url)));
export const localUrl = `http://127.0.0.1:${Number(process.env.CONTENT_ALCHEMY_PORT || 6187)}`;
export async function isReady() {
  try {
    const response = await fetch(`${localUrl}/healthz`, { signal: AbortSignal.timeout(500) });
    return response.ok && (await response.json()).ok === true;
  } catch { return false; }
}
export async function waitUntilReady(timeout = 6000) {
  const end = Date.now() + timeout;
  while (Date.now() < end) {
    if (await isReady()) return;
    await new Promise(resolve => setTimeout(resolve, 50));
  }
  throw new Error('Hanabi 启动失败，请查看本机 logs/server.log。');
}
export async function ensureServer() {
  const started = performance.now();
  if (await isReady()) return { url: localUrl, reused: true, readyMs: Math.round(performance.now() - started) };
  const servicePath = join(homedir(), 'Library', 'LaunchAgents', 'com.lilith.hanabi.server.plist');
  if (process.platform === 'darwin' && localUrl.endsWith(':6187') && !process.env.CONTENT_ALCHEMY_DATA_DIR && existsSync(servicePath)) {
    let registered = false;
    try { await promisify(execFile)('/bin/launchctl', ['kickstart', `gui/${process.getuid()}/com.lilith.hanabi.server`]); registered = true; }
    catch { /* A removed/unregistered service can still use the standalone path. */ }
    if (registered) {
      await waitUntilReady();
      return { url: localUrl, reused: false, managed: true, readyMs: Math.round(performance.now() - started) };
    }
  }
  const data = process.env.CONTENT_ALCHEMY_DATA_DIR || join(homedir(), 'Library', 'Application Support', 'Content Alchemy');
  const logs = join(data, 'logs');
  await mkdir(logs, { recursive: true, mode: 0o700 });
  const log = await open(join(logs, 'server.log'), 'a', 0o600);
  try {
    const child = spawn(process.execPath, ['server.mjs'], { cwd: root, detached: true, stdio: ['ignore', log.fd, log.fd], env: process.env });
    let failure;
    child.on('error', error => { failure = error; });
    child.unref();
    await waitUntilReady();
    if (failure) throw failure;
    return { url: localUrl, reused: false, readyMs: Math.round(performance.now() - started) };
  } finally { await log.close(); }
}
if (process.argv[1] && resolve(process.argv[1]) === fileURLToPath(import.meta.url)) {
  try { console.log(JSON.stringify(await ensureServer())); }
  catch (error) { console.error(error.message); process.exitCode = 1; }
}
