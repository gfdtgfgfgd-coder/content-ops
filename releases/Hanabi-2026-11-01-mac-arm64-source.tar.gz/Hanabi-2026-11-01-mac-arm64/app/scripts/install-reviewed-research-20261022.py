import json,pathlib,urllib.request,re,hashlib,zipfile,io
from decimal import Decimal as D
b='http://127.0.0.1:6187';out=pathlib.Path('../outputs/hanabi-rework-20261022');run=json.loads((out/'live-run.json').read_text());jid=run['reportJob']['id']
def get(path):return urllib.request.urlopen(b+path,timeout=40)
def call(path,body):return json.load(urllib.request.urlopen(urllib.request.Request(b+path,data=json.dumps(body,ensure_ascii=False).encode(),headers={'Content-Type':'application/json','Origin':b}),timeout=40))
j=next(j for j in json.load(get('/api/analysis-jobs'))['jobs'] if j['id']==jid);assert j['status']=='completed'
markdown=(out/'report-reviewed.md').read_text().strip();fresh=json.loads((out/'fresh-pages.json').read_text());fresh_urls={p['url'] for p in fresh if p.get('text')};sources=[]
for title,url in re.findall(r'\[([^\]]+)\]\((https?://[^)]+)\)',markdown):
 if title.startswith('S'):assert url in fresh_urls,(title,url)
 sources.append({'title':title,'url':url,'evidence':'2026-10-22 公开页复核' if title.startswith('S') else '2026-10-16 历史原表，非今日报价'})
checks={'C-GPT5.6':str(D(3)+D(18)*D('.2')),'C-GPT6.1':str(D('1.2')+D(6)*D('.2')),'Packy-historical-GPT5.6':str(D(2)+D(10)*D('.2')),'cache-break-even':str(D('.456')/D('.5')),'cache-95-C':str(D('.6')*D('.05')+D('.12')*D('.95')+D('1.2')*D('.02')),'cache-95-Packy':str(D(1)*D('.05')+D('.02')*D('.95')+D(4)*D('.02')),'mirror-break-even':str(D(99)/D('2.4')),'makenow-11s':str((D(110)*D(98)/D(1226)).quantize(D('.00000001')))}
assert checks['cache-break-even']=='0.912';assert checks['mirror-break-even']=='41.25';assert checks['makenow-11s']=='8.79282219'
r=call('/api/market-research/reports/'+jid+'/revision',{'markdown':markdown,'expectedUpdatedAt':j['updatedAt'],'sources':sources});assert r['job']['result']==markdown
html=get('/api/analysis-jobs/'+jid+'/export.html').read().decode();assert '输入 1；输出 5' in html and '高 65.00%' in html and '人民币 ¥0.816' in html
(out/'report-feishu.html').write_text(html)
word=get('/api/analysis-jobs/'+jid+'/export.docx').read();xml=zipfile.ZipFile(io.BytesIO(word)).read('word/document.xml').decode();assert '91.2%' in xml and '8.79282219' in xml and 'Hanabi 任务' not in xml and '账单单位' in xml
(out/'价格调研10.22-五业务线.docx').write_bytes(word)
items=json.load(get('/api/items'))['items'];assert not any(i['id'] in [x['id'] for x in run['items']] for i in items);assert not any('市场调研' in i.get('tags',[]) for i in items)
# Preserve public page text/hash/date and all deterministic calculations together.
root=pathlib.Path('/Users/lilith/Library/Application Support/Content Alchemy/knowledge/ai-content-alchemy/references/ai-market-research/references/price-checks');root.mkdir(parents=True,exist_ok=True)
evidence={'reportJob':jid,'reviewedAt':'2026-10-22','sources':sources,'pages':fresh,'historicalAnalysis':json.loads((out/'historical-analysis.json').read_text()),'checks':checks,'modelEvidence':json.loads((out/'report-job-evidence.json').read_text()),'reportSha256':hashlib.sha256(markdown.encode()).hexdigest(),'scope':'公开报价核对＋历史/条件测算；未充值或付费调用'}
(root/(jid+'.json')).write_text(json.dumps(evidence,ensure_ascii=False,indent=2))
verification={'job':r['job'],'artifact':r['artifact'],'ordinaryLibraryCount':len(items),'marketItemsInLibrary':0,'checks':checks,'wordSha256':hashlib.sha256(word).hexdigest(),'feishuUrl':'https://wcnoyames7gq.feishu.cn/wiki/VJCPwOkkOiolHdkBY84chh1Rnaf'};(out/'final-verification.json').write_text(json.dumps(verification,ensure_ascii=False,indent=2));print(json.dumps({'job':jid,'artifact':r['artifact'],'libraryCount':len(items),'checks':checks},ensure_ascii=False))
